<?php
defined('ZOTOP') OR die('No direct access allowed.');
/*
* 地区 首页控制器
*
* @package		area
* @version		1.0
* @author		
* @copyright	
* @license		
*/
class area_controller_index extends site_controller
{
	/**
	 * 重载__init函数
	 */
	public function __init()
	{
		parent::__init();

	}

	/**
	 * index 动作
	 *
	 */
	public function action_index()
    {

		$this->assign('title',t('地区'));
		$this->assign('data',$data);
		$this->display('area/index.php');
	}
}
?>