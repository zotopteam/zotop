<?php
return array (
  0 => 
  array (
    'id' => '110000',
    'parentid' => '0',
    'parentids' => '110000',
    'level' => '1',
    'name' => '北京市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  1 => 
  array (
    'id' => '110101',
    'parentid' => '110000',
    'parentids' => '110000,110101',
    'level' => '2',
    'name' => '东城区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2 => 
  array (
    'id' => '110102',
    'parentid' => '110000',
    'parentids' => '110000,110102',
    'level' => '2',
    'name' => '西城区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3 => 
  array (
    'id' => '110103',
    'parentid' => '110000',
    'parentids' => '110000,110103',
    'level' => '2',
    'name' => '崇文区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  4 => 
  array (
    'id' => '110104',
    'parentid' => '110000',
    'parentids' => '110000,110104',
    'level' => '2',
    'name' => '宣武区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  5 => 
  array (
    'id' => '110105',
    'parentid' => '110000',
    'parentids' => '110000,110105',
    'level' => '2',
    'name' => '朝阳区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  6 => 
  array (
    'id' => '110106',
    'parentid' => '110000',
    'parentids' => '110000,110106',
    'level' => '2',
    'name' => '丰台区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  7 => 
  array (
    'id' => '110107',
    'parentid' => '110000',
    'parentids' => '110000,110107',
    'level' => '2',
    'name' => '石景山区',
    'letter' => 's',
    'listorder' => '0',
  ),
  8 => 
  array (
    'id' => '110108',
    'parentid' => '110000',
    'parentids' => '110000,110108',
    'level' => '2',
    'name' => '海淀区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  9 => 
  array (
    'id' => '110109',
    'parentid' => '110000',
    'parentids' => '110000,110109',
    'level' => '2',
    'name' => '门头沟区',
    'letter' => 'm',
    'listorder' => '0',
  ),
  10 => 
  array (
    'id' => '110111',
    'parentid' => '110000',
    'parentids' => '110000,110111',
    'level' => '2',
    'name' => '房山区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  11 => 
  array (
    'id' => '110112',
    'parentid' => '110000',
    'parentids' => '110000,110112',
    'level' => '2',
    'name' => '通州区',
    'letter' => 't',
    'listorder' => '0',
  ),
  12 => 
  array (
    'id' => '110113',
    'parentid' => '110000',
    'parentids' => '110000,110113',
    'level' => '2',
    'name' => '顺义区',
    'letter' => 's',
    'listorder' => '0',
  ),
  13 => 
  array (
    'id' => '110114',
    'parentid' => '110000',
    'parentids' => '110000,110114',
    'level' => '2',
    'name' => '昌平区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  14 => 
  array (
    'id' => '110115',
    'parentid' => '110000',
    'parentids' => '110000,110115',
    'level' => '2',
    'name' => '大兴区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  15 => 
  array (
    'id' => '110116',
    'parentid' => '110000',
    'parentids' => '110000,110116',
    'level' => '2',
    'name' => '怀柔区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  16 => 
  array (
    'id' => '110117',
    'parentid' => '110000',
    'parentids' => '110000,110117',
    'level' => '2',
    'name' => '平谷区',
    'letter' => 'p',
    'listorder' => '0',
  ),
  17 => 
  array (
    'id' => '110228',
    'parentid' => '110000',
    'parentids' => '110000,110228',
    'level' => '2',
    'name' => '密云县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  18 => 
  array (
    'id' => '110229',
    'parentid' => '110000',
    'parentids' => '110000,110229',
    'level' => '2',
    'name' => '延庆县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  19 => 
  array (
    'id' => '120000',
    'parentid' => '0',
    'parentids' => '120000',
    'level' => '1',
    'name' => '天津市',
    'letter' => 't',
    'listorder' => '0',
  ),
  20 => 
  array (
    'id' => '120101',
    'parentid' => '120000',
    'parentids' => '120000,120101',
    'level' => '2',
    'name' => '和平区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  21 => 
  array (
    'id' => '120102',
    'parentid' => '120000',
    'parentids' => '120000,120102',
    'level' => '2',
    'name' => '河东区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  22 => 
  array (
    'id' => '120103',
    'parentid' => '120000',
    'parentids' => '120000,120103',
    'level' => '2',
    'name' => '河西区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  23 => 
  array (
    'id' => '120104',
    'parentid' => '120000',
    'parentids' => '120000,120104',
    'level' => '2',
    'name' => '南开区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  24 => 
  array (
    'id' => '120105',
    'parentid' => '120000',
    'parentids' => '120000,120105',
    'level' => '2',
    'name' => '河北区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  25 => 
  array (
    'id' => '120106',
    'parentid' => '120000',
    'parentids' => '120000,120106',
    'level' => '2',
    'name' => '红桥区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  26 => 
  array (
    'id' => '120107',
    'parentid' => '120000',
    'parentids' => '120000,120107',
    'level' => '2',
    'name' => '塘沽区',
    'letter' => 't',
    'listorder' => '0',
  ),
  27 => 
  array (
    'id' => '120108',
    'parentid' => '120000',
    'parentids' => '120000,120108',
    'level' => '2',
    'name' => '汉沽区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  28 => 
  array (
    'id' => '120109',
    'parentid' => '120000',
    'parentids' => '120000,120109',
    'level' => '2',
    'name' => '大港区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  29 => 
  array (
    'id' => '120110',
    'parentid' => '120000',
    'parentids' => '120000,120110',
    'level' => '2',
    'name' => '东丽区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  30 => 
  array (
    'id' => '120111',
    'parentid' => '120000',
    'parentids' => '120000,120111',
    'level' => '2',
    'name' => '西青区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  31 => 
  array (
    'id' => '120112',
    'parentid' => '120000',
    'parentids' => '120000,120112',
    'level' => '2',
    'name' => '津南区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  32 => 
  array (
    'id' => '120113',
    'parentid' => '120000',
    'parentids' => '120000,120113',
    'level' => '2',
    'name' => '北辰区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  33 => 
  array (
    'id' => '120114',
    'parentid' => '120000',
    'parentids' => '120000,120114',
    'level' => '2',
    'name' => '武清区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  34 => 
  array (
    'id' => '120115',
    'parentid' => '120000',
    'parentids' => '120000,120115',
    'level' => '2',
    'name' => '宝坻区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  35 => 
  array (
    'id' => '120221',
    'parentid' => '120000',
    'parentids' => '120000,120221',
    'level' => '2',
    'name' => '宁河县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  36 => 
  array (
    'id' => '120223',
    'parentid' => '120000',
    'parentids' => '120000,120223',
    'level' => '2',
    'name' => '静海县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  37 => 
  array (
    'id' => '120225',
    'parentid' => '120000',
    'parentids' => '120000,120225',
    'level' => '2',
    'name' => '蓟　县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  38 => 
  array (
    'id' => '130000',
    'parentid' => '0',
    'parentids' => '130000',
    'level' => '1',
    'name' => '河北省',
    'letter' => 'h',
    'listorder' => '0',
  ),
  39 => 
  array (
    'id' => '130100',
    'parentid' => '130000',
    'parentids' => '130000,130100',
    'level' => '2',
    'name' => '石家庄市',
    'letter' => 's',
    'listorder' => '0',
  ),
  40 => 
  array (
    'id' => '130101',
    'parentid' => '130100',
    'parentids' => '130000,130100,130101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  41 => 
  array (
    'id' => '130102',
    'parentid' => '130100',
    'parentids' => '130000,130100,130102',
    'level' => '3',
    'name' => '长安区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  42 => 
  array (
    'id' => '130103',
    'parentid' => '130100',
    'parentids' => '130000,130100,130103',
    'level' => '3',
    'name' => '桥东区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  43 => 
  array (
    'id' => '130104',
    'parentid' => '130100',
    'parentids' => '130000,130100,130104',
    'level' => '3',
    'name' => '桥西区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  44 => 
  array (
    'id' => '130105',
    'parentid' => '130100',
    'parentids' => '130000,130100,130105',
    'level' => '3',
    'name' => '新华区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  45 => 
  array (
    'id' => '130107',
    'parentid' => '130100',
    'parentids' => '130000,130100,130107',
    'level' => '3',
    'name' => '井陉矿区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  46 => 
  array (
    'id' => '130108',
    'parentid' => '130100',
    'parentids' => '130000,130100,130108',
    'level' => '3',
    'name' => '裕华区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  47 => 
  array (
    'id' => '130121',
    'parentid' => '130100',
    'parentids' => '130000,130100,130121',
    'level' => '3',
    'name' => '井陉县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  48 => 
  array (
    'id' => '130123',
    'parentid' => '130100',
    'parentids' => '130000,130100,130123',
    'level' => '3',
    'name' => '正定县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  49 => 
  array (
    'id' => '130124',
    'parentid' => '130100',
    'parentids' => '130000,130100,130124',
    'level' => '3',
    'name' => '栾城县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  50 => 
  array (
    'id' => '130125',
    'parentid' => '130100',
    'parentids' => '130000,130100,130125',
    'level' => '3',
    'name' => '行唐县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  51 => 
  array (
    'id' => '130126',
    'parentid' => '130100',
    'parentids' => '130000,130100,130126',
    'level' => '3',
    'name' => '灵寿县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  52 => 
  array (
    'id' => '130127',
    'parentid' => '130100',
    'parentids' => '130000,130100,130127',
    'level' => '3',
    'name' => '高邑县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  53 => 
  array (
    'id' => '130128',
    'parentid' => '130100',
    'parentids' => '130000,130100,130128',
    'level' => '3',
    'name' => '深泽县',
    'letter' => 's',
    'listorder' => '0',
  ),
  54 => 
  array (
    'id' => '130129',
    'parentid' => '130100',
    'parentids' => '130000,130100,130129',
    'level' => '3',
    'name' => '赞皇县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  55 => 
  array (
    'id' => '130130',
    'parentid' => '130100',
    'parentids' => '130000,130100,130130',
    'level' => '3',
    'name' => '无极县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  56 => 
  array (
    'id' => '130131',
    'parentid' => '130100',
    'parentids' => '130000,130100,130131',
    'level' => '3',
    'name' => '平山县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  57 => 
  array (
    'id' => '130132',
    'parentid' => '130100',
    'parentids' => '130000,130100,130132',
    'level' => '3',
    'name' => '元氏县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  58 => 
  array (
    'id' => '130133',
    'parentid' => '130100',
    'parentids' => '130000,130100,130133',
    'level' => '3',
    'name' => '赵　县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  59 => 
  array (
    'id' => '130181',
    'parentid' => '130100',
    'parentids' => '130000,130100,130181',
    'level' => '3',
    'name' => '辛集市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  60 => 
  array (
    'id' => '130182',
    'parentid' => '130100',
    'parentids' => '130000,130100,130182',
    'level' => '3',
    'name' => '藁城市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  61 => 
  array (
    'id' => '130183',
    'parentid' => '130100',
    'parentids' => '130000,130100,130183',
    'level' => '3',
    'name' => '晋州市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  62 => 
  array (
    'id' => '130184',
    'parentid' => '130100',
    'parentids' => '130000,130100,130184',
    'level' => '3',
    'name' => '新乐市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  63 => 
  array (
    'id' => '130185',
    'parentid' => '130100',
    'parentids' => '130000,130100,130185',
    'level' => '3',
    'name' => '鹿泉市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  64 => 
  array (
    'id' => '130200',
    'parentid' => '130000',
    'parentids' => '130000,130200',
    'level' => '2',
    'name' => '唐山市',
    'letter' => 't',
    'listorder' => '0',
  ),
  65 => 
  array (
    'id' => '130201',
    'parentid' => '130200',
    'parentids' => '130000,130200,130201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  66 => 
  array (
    'id' => '130202',
    'parentid' => '130200',
    'parentids' => '130000,130200,130202',
    'level' => '3',
    'name' => '路南区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  67 => 
  array (
    'id' => '130203',
    'parentid' => '130200',
    'parentids' => '130000,130200,130203',
    'level' => '3',
    'name' => '路北区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  68 => 
  array (
    'id' => '130204',
    'parentid' => '130200',
    'parentids' => '130000,130200,130204',
    'level' => '3',
    'name' => '古冶区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  69 => 
  array (
    'id' => '130205',
    'parentid' => '130200',
    'parentids' => '130000,130200,130205',
    'level' => '3',
    'name' => '开平区',
    'letter' => 'k',
    'listorder' => '0',
  ),
  70 => 
  array (
    'id' => '130207',
    'parentid' => '130200',
    'parentids' => '130000,130200,130207',
    'level' => '3',
    'name' => '丰南区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  71 => 
  array (
    'id' => '130208',
    'parentid' => '130200',
    'parentids' => '130000,130200,130208',
    'level' => '3',
    'name' => '丰润区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  72 => 
  array (
    'id' => '130223',
    'parentid' => '130200',
    'parentids' => '130000,130200,130223',
    'level' => '3',
    'name' => '滦　县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  73 => 
  array (
    'id' => '130224',
    'parentid' => '130200',
    'parentids' => '130000,130200,130224',
    'level' => '3',
    'name' => '滦南县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  74 => 
  array (
    'id' => '130225',
    'parentid' => '130200',
    'parentids' => '130000,130200,130225',
    'level' => '3',
    'name' => '乐亭县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  75 => 
  array (
    'id' => '130227',
    'parentid' => '130200',
    'parentids' => '130000,130200,130227',
    'level' => '3',
    'name' => '迁西县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  76 => 
  array (
    'id' => '130229',
    'parentid' => '130200',
    'parentids' => '130000,130200,130229',
    'level' => '3',
    'name' => '玉田县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  77 => 
  array (
    'id' => '130230',
    'parentid' => '130200',
    'parentids' => '130000,130200,130230',
    'level' => '3',
    'name' => '唐海县',
    'letter' => 't',
    'listorder' => '0',
  ),
  78 => 
  array (
    'id' => '130281',
    'parentid' => '130200',
    'parentids' => '130000,130200,130281',
    'level' => '3',
    'name' => '遵化市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  79 => 
  array (
    'id' => '130283',
    'parentid' => '130200',
    'parentids' => '130000,130200,130283',
    'level' => '3',
    'name' => '迁安市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  80 => 
  array (
    'id' => '130300',
    'parentid' => '130000',
    'parentids' => '130000,130300',
    'level' => '2',
    'name' => '秦皇岛市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  81 => 
  array (
    'id' => '130301',
    'parentid' => '130300',
    'parentids' => '130000,130300,130301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  82 => 
  array (
    'id' => '130302',
    'parentid' => '130300',
    'parentids' => '130000,130300,130302',
    'level' => '3',
    'name' => '海港区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  83 => 
  array (
    'id' => '130303',
    'parentid' => '130300',
    'parentids' => '130000,130300,130303',
    'level' => '3',
    'name' => '山海关区',
    'letter' => 's',
    'listorder' => '0',
  ),
  84 => 
  array (
    'id' => '130304',
    'parentid' => '130300',
    'parentids' => '130000,130300,130304',
    'level' => '3',
    'name' => '北戴河区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  85 => 
  array (
    'id' => '130321',
    'parentid' => '130300',
    'parentids' => '130000,130300,130321',
    'level' => '3',
    'name' => '青龙满族自治县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  86 => 
  array (
    'id' => '130322',
    'parentid' => '130300',
    'parentids' => '130000,130300,130322',
    'level' => '3',
    'name' => '昌黎县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  87 => 
  array (
    'id' => '130323',
    'parentid' => '130300',
    'parentids' => '130000,130300,130323',
    'level' => '3',
    'name' => '抚宁县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  88 => 
  array (
    'id' => '130324',
    'parentid' => '130300',
    'parentids' => '130000,130300,130324',
    'level' => '3',
    'name' => '卢龙县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  89 => 
  array (
    'id' => '130400',
    'parentid' => '130000',
    'parentids' => '130000,130400',
    'level' => '2',
    'name' => '邯郸市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  90 => 
  array (
    'id' => '130401',
    'parentid' => '130400',
    'parentids' => '130000,130400,130401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  91 => 
  array (
    'id' => '130402',
    'parentid' => '130400',
    'parentids' => '130000,130400,130402',
    'level' => '3',
    'name' => '邯山区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  92 => 
  array (
    'id' => '130403',
    'parentid' => '130400',
    'parentids' => '130000,130400,130403',
    'level' => '3',
    'name' => '丛台区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  93 => 
  array (
    'id' => '130404',
    'parentid' => '130400',
    'parentids' => '130000,130400,130404',
    'level' => '3',
    'name' => '复兴区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  94 => 
  array (
    'id' => '130406',
    'parentid' => '130400',
    'parentids' => '130000,130400,130406',
    'level' => '3',
    'name' => '峰峰矿区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  95 => 
  array (
    'id' => '130421',
    'parentid' => '130400',
    'parentids' => '130000,130400,130421',
    'level' => '3',
    'name' => '邯郸县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  96 => 
  array (
    'id' => '130423',
    'parentid' => '130400',
    'parentids' => '130000,130400,130423',
    'level' => '3',
    'name' => '临漳县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  97 => 
  array (
    'id' => '130424',
    'parentid' => '130400',
    'parentids' => '130000,130400,130424',
    'level' => '3',
    'name' => '成安县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  98 => 
  array (
    'id' => '130425',
    'parentid' => '130400',
    'parentids' => '130000,130400,130425',
    'level' => '3',
    'name' => '大名县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  99 => 
  array (
    'id' => '130426',
    'parentid' => '130400',
    'parentids' => '130000,130400,130426',
    'level' => '3',
    'name' => '涉　县',
    'letter' => 's',
    'listorder' => '0',
  ),
  100 => 
  array (
    'id' => '130427',
    'parentid' => '130400',
    'parentids' => '130000,130400,130427',
    'level' => '3',
    'name' => '磁　县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  101 => 
  array (
    'id' => '130428',
    'parentid' => '130400',
    'parentids' => '130000,130400,130428',
    'level' => '3',
    'name' => '肥乡县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  102 => 
  array (
    'id' => '130429',
    'parentid' => '130400',
    'parentids' => '130000,130400,130429',
    'level' => '3',
    'name' => '永年县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  103 => 
  array (
    'id' => '130430',
    'parentid' => '130400',
    'parentids' => '130000,130400,130430',
    'level' => '3',
    'name' => '邱　县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  104 => 
  array (
    'id' => '130431',
    'parentid' => '130400',
    'parentids' => '130000,130400,130431',
    'level' => '3',
    'name' => '鸡泽县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  105 => 
  array (
    'id' => '130432',
    'parentid' => '130400',
    'parentids' => '130000,130400,130432',
    'level' => '3',
    'name' => '广平县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  106 => 
  array (
    'id' => '130433',
    'parentid' => '130400',
    'parentids' => '130000,130400,130433',
    'level' => '3',
    'name' => '馆陶县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  107 => 
  array (
    'id' => '130434',
    'parentid' => '130400',
    'parentids' => '130000,130400,130434',
    'level' => '3',
    'name' => '魏　县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  108 => 
  array (
    'id' => '130435',
    'parentid' => '130400',
    'parentids' => '130000,130400,130435',
    'level' => '3',
    'name' => '曲周县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  109 => 
  array (
    'id' => '130481',
    'parentid' => '130400',
    'parentids' => '130000,130400,130481',
    'level' => '3',
    'name' => '武安市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  110 => 
  array (
    'id' => '130500',
    'parentid' => '130000',
    'parentids' => '130000,130500',
    'level' => '2',
    'name' => '邢台市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  111 => 
  array (
    'id' => '130501',
    'parentid' => '130500',
    'parentids' => '130000,130500,130501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  112 => 
  array (
    'id' => '130502',
    'parentid' => '130500',
    'parentids' => '130000,130500,130502',
    'level' => '3',
    'name' => '桥东区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  113 => 
  array (
    'id' => '130503',
    'parentid' => '130500',
    'parentids' => '130000,130500,130503',
    'level' => '3',
    'name' => '桥西区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  114 => 
  array (
    'id' => '130521',
    'parentid' => '130500',
    'parentids' => '130000,130500,130521',
    'level' => '3',
    'name' => '邢台县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  115 => 
  array (
    'id' => '130522',
    'parentid' => '130500',
    'parentids' => '130000,130500,130522',
    'level' => '3',
    'name' => '临城县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  116 => 
  array (
    'id' => '130523',
    'parentid' => '130500',
    'parentids' => '130000,130500,130523',
    'level' => '3',
    'name' => '内丘县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  117 => 
  array (
    'id' => '130524',
    'parentid' => '130500',
    'parentids' => '130000,130500,130524',
    'level' => '3',
    'name' => '柏乡县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  118 => 
  array (
    'id' => '130525',
    'parentid' => '130500',
    'parentids' => '130000,130500,130525',
    'level' => '3',
    'name' => '隆尧县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  119 => 
  array (
    'id' => '130526',
    'parentid' => '130500',
    'parentids' => '130000,130500,130526',
    'level' => '3',
    'name' => '任　县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  120 => 
  array (
    'id' => '130527',
    'parentid' => '130500',
    'parentids' => '130000,130500,130527',
    'level' => '3',
    'name' => '南和县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  121 => 
  array (
    'id' => '130528',
    'parentid' => '130500',
    'parentids' => '130000,130500,130528',
    'level' => '3',
    'name' => '宁晋县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  122 => 
  array (
    'id' => '130529',
    'parentid' => '130500',
    'parentids' => '130000,130500,130529',
    'level' => '3',
    'name' => '巨鹿县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  123 => 
  array (
    'id' => '130530',
    'parentid' => '130500',
    'parentids' => '130000,130500,130530',
    'level' => '3',
    'name' => '新河县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  124 => 
  array (
    'id' => '130531',
    'parentid' => '130500',
    'parentids' => '130000,130500,130531',
    'level' => '3',
    'name' => '广宗县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  125 => 
  array (
    'id' => '130532',
    'parentid' => '130500',
    'parentids' => '130000,130500,130532',
    'level' => '3',
    'name' => '平乡县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  126 => 
  array (
    'id' => '130533',
    'parentid' => '130500',
    'parentids' => '130000,130500,130533',
    'level' => '3',
    'name' => '威　县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  127 => 
  array (
    'id' => '130534',
    'parentid' => '130500',
    'parentids' => '130000,130500,130534',
    'level' => '3',
    'name' => '清河县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  128 => 
  array (
    'id' => '130535',
    'parentid' => '130500',
    'parentids' => '130000,130500,130535',
    'level' => '3',
    'name' => '临西县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  129 => 
  array (
    'id' => '130581',
    'parentid' => '130500',
    'parentids' => '130000,130500,130581',
    'level' => '3',
    'name' => '南宫市',
    'letter' => 'n',
    'listorder' => '0',
  ),
  130 => 
  array (
    'id' => '130582',
    'parentid' => '130500',
    'parentids' => '130000,130500,130582',
    'level' => '3',
    'name' => '沙河市',
    'letter' => 's',
    'listorder' => '0',
  ),
  131 => 
  array (
    'id' => '130600',
    'parentid' => '130000',
    'parentids' => '130000,130600',
    'level' => '2',
    'name' => '保定市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  132 => 
  array (
    'id' => '130601',
    'parentid' => '130600',
    'parentids' => '130000,130600,130601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  133 => 
  array (
    'id' => '130602',
    'parentid' => '130600',
    'parentids' => '130000,130600,130602',
    'level' => '3',
    'name' => '新市区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  134 => 
  array (
    'id' => '130603',
    'parentid' => '130600',
    'parentids' => '130000,130600,130603',
    'level' => '3',
    'name' => '北市区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  135 => 
  array (
    'id' => '130604',
    'parentid' => '130600',
    'parentids' => '130000,130600,130604',
    'level' => '3',
    'name' => '南市区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  136 => 
  array (
    'id' => '130621',
    'parentid' => '130600',
    'parentids' => '130000,130600,130621',
    'level' => '3',
    'name' => '满城县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  137 => 
  array (
    'id' => '130622',
    'parentid' => '130600',
    'parentids' => '130000,130600,130622',
    'level' => '3',
    'name' => '清苑县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  138 => 
  array (
    'id' => '130623',
    'parentid' => '130600',
    'parentids' => '130000,130600,130623',
    'level' => '3',
    'name' => '涞水县',
    'letter' => 's',
    'listorder' => '0',
  ),
  139 => 
  array (
    'id' => '130624',
    'parentid' => '130600',
    'parentids' => '130000,130600,130624',
    'level' => '3',
    'name' => '阜平县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  140 => 
  array (
    'id' => '130625',
    'parentid' => '130600',
    'parentids' => '130000,130600,130625',
    'level' => '3',
    'name' => '徐水县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  141 => 
  array (
    'id' => '130626',
    'parentid' => '130600',
    'parentids' => '130000,130600,130626',
    'level' => '3',
    'name' => '定兴县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  142 => 
  array (
    'id' => '130627',
    'parentid' => '130600',
    'parentids' => '130000,130600,130627',
    'level' => '3',
    'name' => '唐　县',
    'letter' => 't',
    'listorder' => '0',
  ),
  143 => 
  array (
    'id' => '130628',
    'parentid' => '130600',
    'parentids' => '130000,130600,130628',
    'level' => '3',
    'name' => '高阳县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  144 => 
  array (
    'id' => '130629',
    'parentid' => '130600',
    'parentids' => '130000,130600,130629',
    'level' => '3',
    'name' => '容城县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  145 => 
  array (
    'id' => '130630',
    'parentid' => '130600',
    'parentids' => '130000,130600,130630',
    'level' => '3',
    'name' => '涞源县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  146 => 
  array (
    'id' => '130631',
    'parentid' => '130600',
    'parentids' => '130000,130600,130631',
    'level' => '3',
    'name' => '望都县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  147 => 
  array (
    'id' => '130632',
    'parentid' => '130600',
    'parentids' => '130000,130600,130632',
    'level' => '3',
    'name' => '安新县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  148 => 
  array (
    'id' => '130633',
    'parentid' => '130600',
    'parentids' => '130000,130600,130633',
    'level' => '3',
    'name' => '易　县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  149 => 
  array (
    'id' => '130634',
    'parentid' => '130600',
    'parentids' => '130000,130600,130634',
    'level' => '3',
    'name' => '曲阳县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  150 => 
  array (
    'id' => '130635',
    'parentid' => '130600',
    'parentids' => '130000,130600,130635',
    'level' => '3',
    'name' => '蠡　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  151 => 
  array (
    'id' => '130636',
    'parentid' => '130600',
    'parentids' => '130000,130600,130636',
    'level' => '3',
    'name' => '顺平县',
    'letter' => 's',
    'listorder' => '0',
  ),
  152 => 
  array (
    'id' => '130637',
    'parentid' => '130600',
    'parentids' => '130000,130600,130637',
    'level' => '3',
    'name' => '博野县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  153 => 
  array (
    'id' => '130638',
    'parentid' => '130600',
    'parentids' => '130000,130600,130638',
    'level' => '3',
    'name' => '雄　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  154 => 
  array (
    'id' => '130681',
    'parentid' => '130600',
    'parentids' => '130000,130600,130681',
    'level' => '3',
    'name' => '涿州市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  155 => 
  array (
    'id' => '130682',
    'parentid' => '130600',
    'parentids' => '130000,130600,130682',
    'level' => '3',
    'name' => '定州市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  156 => 
  array (
    'id' => '130683',
    'parentid' => '130600',
    'parentids' => '130000,130600,130683',
    'level' => '3',
    'name' => '安国市',
    'letter' => 'a',
    'listorder' => '0',
  ),
  157 => 
  array (
    'id' => '130684',
    'parentid' => '130600',
    'parentids' => '130000,130600,130684',
    'level' => '3',
    'name' => '高碑店市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  158 => 
  array (
    'id' => '130700',
    'parentid' => '130000',
    'parentids' => '130000,130700',
    'level' => '2',
    'name' => '张家口市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  159 => 
  array (
    'id' => '130701',
    'parentid' => '130700',
    'parentids' => '130000,130700,130701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  160 => 
  array (
    'id' => '130702',
    'parentid' => '130700',
    'parentids' => '130000,130700,130702',
    'level' => '3',
    'name' => '桥东区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  161 => 
  array (
    'id' => '130703',
    'parentid' => '130700',
    'parentids' => '130000,130700,130703',
    'level' => '3',
    'name' => '桥西区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  162 => 
  array (
    'id' => '130705',
    'parentid' => '130700',
    'parentids' => '130000,130700,130705',
    'level' => '3',
    'name' => '宣化区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  163 => 
  array (
    'id' => '130706',
    'parentid' => '130700',
    'parentids' => '130000,130700,130706',
    'level' => '3',
    'name' => '下花园区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  164 => 
  array (
    'id' => '130721',
    'parentid' => '130700',
    'parentids' => '130000,130700,130721',
    'level' => '3',
    'name' => '宣化县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  165 => 
  array (
    'id' => '130722',
    'parentid' => '130700',
    'parentids' => '130000,130700,130722',
    'level' => '3',
    'name' => '张北县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  166 => 
  array (
    'id' => '130723',
    'parentid' => '130700',
    'parentids' => '130000,130700,130723',
    'level' => '3',
    'name' => '康保县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  167 => 
  array (
    'id' => '130724',
    'parentid' => '130700',
    'parentids' => '130000,130700,130724',
    'level' => '3',
    'name' => '沽源县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  168 => 
  array (
    'id' => '130725',
    'parentid' => '130700',
    'parentids' => '130000,130700,130725',
    'level' => '3',
    'name' => '尚义县',
    'letter' => 's',
    'listorder' => '0',
  ),
  169 => 
  array (
    'id' => '130726',
    'parentid' => '130700',
    'parentids' => '130000,130700,130726',
    'level' => '3',
    'name' => '蔚　县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  170 => 
  array (
    'id' => '130727',
    'parentid' => '130700',
    'parentids' => '130000,130700,130727',
    'level' => '3',
    'name' => '阳原县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  171 => 
  array (
    'id' => '130728',
    'parentid' => '130700',
    'parentids' => '130000,130700,130728',
    'level' => '3',
    'name' => '怀安县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  172 => 
  array (
    'id' => '130729',
    'parentid' => '130700',
    'parentids' => '130000,130700,130729',
    'level' => '3',
    'name' => '万全县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  173 => 
  array (
    'id' => '130730',
    'parentid' => '130700',
    'parentids' => '130000,130700,130730',
    'level' => '3',
    'name' => '怀来县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  174 => 
  array (
    'id' => '130731',
    'parentid' => '130700',
    'parentids' => '130000,130700,130731',
    'level' => '3',
    'name' => '涿鹿县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  175 => 
  array (
    'id' => '130732',
    'parentid' => '130700',
    'parentids' => '130000,130700,130732',
    'level' => '3',
    'name' => '赤城县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  176 => 
  array (
    'id' => '130733',
    'parentid' => '130700',
    'parentids' => '130000,130700,130733',
    'level' => '3',
    'name' => '崇礼县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  177 => 
  array (
    'id' => '130800',
    'parentid' => '130000',
    'parentids' => '130000,130800',
    'level' => '2',
    'name' => '承德市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  178 => 
  array (
    'id' => '130801',
    'parentid' => '130800',
    'parentids' => '130000,130800,130801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  179 => 
  array (
    'id' => '130802',
    'parentid' => '130800',
    'parentids' => '130000,130800,130802',
    'level' => '3',
    'name' => '双桥区',
    'letter' => 's',
    'listorder' => '0',
  ),
  180 => 
  array (
    'id' => '130803',
    'parentid' => '130800',
    'parentids' => '130000,130800,130803',
    'level' => '3',
    'name' => '双滦区',
    'letter' => 's',
    'listorder' => '0',
  ),
  181 => 
  array (
    'id' => '130804',
    'parentid' => '130800',
    'parentids' => '130000,130800,130804',
    'level' => '3',
    'name' => '鹰手营子矿区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  182 => 
  array (
    'id' => '130821',
    'parentid' => '130800',
    'parentids' => '130000,130800,130821',
    'level' => '3',
    'name' => '承德县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  183 => 
  array (
    'id' => '130822',
    'parentid' => '130800',
    'parentids' => '130000,130800,130822',
    'level' => '3',
    'name' => '兴隆县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  184 => 
  array (
    'id' => '130823',
    'parentid' => '130800',
    'parentids' => '130000,130800,130823',
    'level' => '3',
    'name' => '平泉县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  185 => 
  array (
    'id' => '130824',
    'parentid' => '130800',
    'parentids' => '130000,130800,130824',
    'level' => '3',
    'name' => '滦平县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  186 => 
  array (
    'id' => '130825',
    'parentid' => '130800',
    'parentids' => '130000,130800,130825',
    'level' => '3',
    'name' => '隆化县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  187 => 
  array (
    'id' => '130826',
    'parentid' => '130800',
    'parentids' => '130000,130800,130826',
    'level' => '3',
    'name' => '丰宁满族自治县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  188 => 
  array (
    'id' => '130827',
    'parentid' => '130800',
    'parentids' => '130000,130800,130827',
    'level' => '3',
    'name' => '宽城满族自治县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  189 => 
  array (
    'id' => '130828',
    'parentid' => '130800',
    'parentids' => '130000,130800,130828',
    'level' => '3',
    'name' => '围场满族蒙古族自治县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  190 => 
  array (
    'id' => '130900',
    'parentid' => '130000',
    'parentids' => '130000,130900',
    'level' => '2',
    'name' => '沧州市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  191 => 
  array (
    'id' => '130901',
    'parentid' => '130900',
    'parentids' => '130000,130900,130901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  192 => 
  array (
    'id' => '130902',
    'parentid' => '130900',
    'parentids' => '130000,130900,130902',
    'level' => '3',
    'name' => '新华区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  193 => 
  array (
    'id' => '130903',
    'parentid' => '130900',
    'parentids' => '130000,130900,130903',
    'level' => '3',
    'name' => '运河区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  194 => 
  array (
    'id' => '130921',
    'parentid' => '130900',
    'parentids' => '130000,130900,130921',
    'level' => '3',
    'name' => '沧　县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  195 => 
  array (
    'id' => '130922',
    'parentid' => '130900',
    'parentids' => '130000,130900,130922',
    'level' => '3',
    'name' => '青　县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  196 => 
  array (
    'id' => '130923',
    'parentid' => '130900',
    'parentids' => '130000,130900,130923',
    'level' => '3',
    'name' => '东光县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  197 => 
  array (
    'id' => '130924',
    'parentid' => '130900',
    'parentids' => '130000,130900,130924',
    'level' => '3',
    'name' => '海兴县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  198 => 
  array (
    'id' => '130925',
    'parentid' => '130900',
    'parentids' => '130000,130900,130925',
    'level' => '3',
    'name' => '盐山县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  199 => 
  array (
    'id' => '130926',
    'parentid' => '130900',
    'parentids' => '130000,130900,130926',
    'level' => '3',
    'name' => '肃宁县',
    'letter' => 's',
    'listorder' => '0',
  ),
  200 => 
  array (
    'id' => '130927',
    'parentid' => '130900',
    'parentids' => '130000,130900,130927',
    'level' => '3',
    'name' => '南皮县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  201 => 
  array (
    'id' => '130928',
    'parentid' => '130900',
    'parentids' => '130000,130900,130928',
    'level' => '3',
    'name' => '吴桥县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  202 => 
  array (
    'id' => '130929',
    'parentid' => '130900',
    'parentids' => '130000,130900,130929',
    'level' => '3',
    'name' => '献　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  203 => 
  array (
    'id' => '130930',
    'parentid' => '130900',
    'parentids' => '130000,130900,130930',
    'level' => '3',
    'name' => '孟村回族自治县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  204 => 
  array (
    'id' => '130981',
    'parentid' => '130900',
    'parentids' => '130000,130900,130981',
    'level' => '3',
    'name' => '泊头市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  205 => 
  array (
    'id' => '130982',
    'parentid' => '130900',
    'parentids' => '130000,130900,130982',
    'level' => '3',
    'name' => '任丘市',
    'letter' => 'r',
    'listorder' => '0',
  ),
  206 => 
  array (
    'id' => '130983',
    'parentid' => '130900',
    'parentids' => '130000,130900,130983',
    'level' => '3',
    'name' => '黄骅市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  207 => 
  array (
    'id' => '130984',
    'parentid' => '130900',
    'parentids' => '130000,130900,130984',
    'level' => '3',
    'name' => '河间市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  208 => 
  array (
    'id' => '131000',
    'parentid' => '130000',
    'parentids' => '130000,131000',
    'level' => '2',
    'name' => '廊坊市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  209 => 
  array (
    'id' => '131001',
    'parentid' => '131000',
    'parentids' => '130000,131000,131001',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  210 => 
  array (
    'id' => '131002',
    'parentid' => '131000',
    'parentids' => '130000,131000,131002',
    'level' => '3',
    'name' => '安次区',
    'letter' => 'a',
    'listorder' => '0',
  ),
  211 => 
  array (
    'id' => '131003',
    'parentid' => '131000',
    'parentids' => '130000,131000,131003',
    'level' => '3',
    'name' => '广阳区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  212 => 
  array (
    'id' => '131022',
    'parentid' => '131000',
    'parentids' => '130000,131000,131022',
    'level' => '3',
    'name' => '固安县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  213 => 
  array (
    'id' => '131023',
    'parentid' => '131000',
    'parentids' => '130000,131000,131023',
    'level' => '3',
    'name' => '永清县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  214 => 
  array (
    'id' => '131024',
    'parentid' => '131000',
    'parentids' => '130000,131000,131024',
    'level' => '3',
    'name' => '香河县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  215 => 
  array (
    'id' => '131025',
    'parentid' => '131000',
    'parentids' => '130000,131000,131025',
    'level' => '3',
    'name' => '大城县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  216 => 
  array (
    'id' => '131026',
    'parentid' => '131000',
    'parentids' => '130000,131000,131026',
    'level' => '3',
    'name' => '文安县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  217 => 
  array (
    'id' => '131028',
    'parentid' => '131000',
    'parentids' => '130000,131000,131028',
    'level' => '3',
    'name' => '大厂回族自治县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  218 => 
  array (
    'id' => '131081',
    'parentid' => '131000',
    'parentids' => '130000,131000,131081',
    'level' => '3',
    'name' => '霸州市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  219 => 
  array (
    'id' => '131082',
    'parentid' => '131000',
    'parentids' => '130000,131000,131082',
    'level' => '3',
    'name' => '三河市',
    'letter' => 's',
    'listorder' => '0',
  ),
  220 => 
  array (
    'id' => '131100',
    'parentid' => '130000',
    'parentids' => '130000,131100',
    'level' => '2',
    'name' => '衡水市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  221 => 
  array (
    'id' => '131101',
    'parentid' => '131100',
    'parentids' => '130000,131100,131101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  222 => 
  array (
    'id' => '131102',
    'parentid' => '131100',
    'parentids' => '130000,131100,131102',
    'level' => '3',
    'name' => '桃城区',
    'letter' => 't',
    'listorder' => '0',
  ),
  223 => 
  array (
    'id' => '131121',
    'parentid' => '131100',
    'parentids' => '130000,131100,131121',
    'level' => '3',
    'name' => '枣强县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  224 => 
  array (
    'id' => '131122',
    'parentid' => '131100',
    'parentids' => '130000,131100,131122',
    'level' => '3',
    'name' => '武邑县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  225 => 
  array (
    'id' => '131123',
    'parentid' => '131100',
    'parentids' => '130000,131100,131123',
    'level' => '3',
    'name' => '武强县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  226 => 
  array (
    'id' => '131124',
    'parentid' => '131100',
    'parentids' => '130000,131100,131124',
    'level' => '3',
    'name' => '饶阳县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  227 => 
  array (
    'id' => '131125',
    'parentid' => '131100',
    'parentids' => '130000,131100,131125',
    'level' => '3',
    'name' => '安平县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  228 => 
  array (
    'id' => '131126',
    'parentid' => '131100',
    'parentids' => '130000,131100,131126',
    'level' => '3',
    'name' => '故城县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  229 => 
  array (
    'id' => '131127',
    'parentid' => '131100',
    'parentids' => '130000,131100,131127',
    'level' => '3',
    'name' => '景　县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  230 => 
  array (
    'id' => '131128',
    'parentid' => '131100',
    'parentids' => '130000,131100,131128',
    'level' => '3',
    'name' => '阜城县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  231 => 
  array (
    'id' => '131181',
    'parentid' => '131100',
    'parentids' => '130000,131100,131181',
    'level' => '3',
    'name' => '冀州市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  232 => 
  array (
    'id' => '131182',
    'parentid' => '131100',
    'parentids' => '130000,131100,131182',
    'level' => '3',
    'name' => '深州市',
    'letter' => 's',
    'listorder' => '0',
  ),
  233 => 
  array (
    'id' => '140000',
    'parentid' => '0',
    'parentids' => '140000',
    'level' => '1',
    'name' => '山西省',
    'letter' => 's',
    'listorder' => '0',
  ),
  234 => 
  array (
    'id' => '140100',
    'parentid' => '140000',
    'parentids' => '140000,140100',
    'level' => '2',
    'name' => '太原市',
    'letter' => 't',
    'listorder' => '0',
  ),
  235 => 
  array (
    'id' => '140101',
    'parentid' => '140100',
    'parentids' => '140000,140100,140101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  236 => 
  array (
    'id' => '140105',
    'parentid' => '140100',
    'parentids' => '140000,140100,140105',
    'level' => '3',
    'name' => '小店区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  237 => 
  array (
    'id' => '140106',
    'parentid' => '140100',
    'parentids' => '140000,140100,140106',
    'level' => '3',
    'name' => '迎泽区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  238 => 
  array (
    'id' => '140107',
    'parentid' => '140100',
    'parentids' => '140000,140100,140107',
    'level' => '3',
    'name' => '杏花岭区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  239 => 
  array (
    'id' => '140108',
    'parentid' => '140100',
    'parentids' => '140000,140100,140108',
    'level' => '3',
    'name' => '尖草坪区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  240 => 
  array (
    'id' => '140109',
    'parentid' => '140100',
    'parentids' => '140000,140100,140109',
    'level' => '3',
    'name' => '万柏林区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  241 => 
  array (
    'id' => '140110',
    'parentid' => '140100',
    'parentids' => '140000,140100,140110',
    'level' => '3',
    'name' => '晋源区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  242 => 
  array (
    'id' => '140121',
    'parentid' => '140100',
    'parentids' => '140000,140100,140121',
    'level' => '3',
    'name' => '清徐县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  243 => 
  array (
    'id' => '140122',
    'parentid' => '140100',
    'parentids' => '140000,140100,140122',
    'level' => '3',
    'name' => '阳曲县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  244 => 
  array (
    'id' => '140123',
    'parentid' => '140100',
    'parentids' => '140000,140100,140123',
    'level' => '3',
    'name' => '娄烦县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  245 => 
  array (
    'id' => '140181',
    'parentid' => '140100',
    'parentids' => '140000,140100,140181',
    'level' => '3',
    'name' => '古交市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  246 => 
  array (
    'id' => '140200',
    'parentid' => '140000',
    'parentids' => '140000,140200',
    'level' => '2',
    'name' => '大同市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  247 => 
  array (
    'id' => '140201',
    'parentid' => '140200',
    'parentids' => '140000,140200,140201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  248 => 
  array (
    'id' => '140202',
    'parentid' => '140200',
    'parentids' => '140000,140200,140202',
    'level' => '3',
    'name' => '城　区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  249 => 
  array (
    'id' => '140203',
    'parentid' => '140200',
    'parentids' => '140000,140200,140203',
    'level' => '3',
    'name' => '矿　区',
    'letter' => 'k',
    'listorder' => '0',
  ),
  250 => 
  array (
    'id' => '140211',
    'parentid' => '140200',
    'parentids' => '140000,140200,140211',
    'level' => '3',
    'name' => '南郊区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  251 => 
  array (
    'id' => '140212',
    'parentid' => '140200',
    'parentids' => '140000,140200,140212',
    'level' => '3',
    'name' => '新荣区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  252 => 
  array (
    'id' => '140221',
    'parentid' => '140200',
    'parentids' => '140000,140200,140221',
    'level' => '3',
    'name' => '阳高县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  253 => 
  array (
    'id' => '140222',
    'parentid' => '140200',
    'parentids' => '140000,140200,140222',
    'level' => '3',
    'name' => '天镇县',
    'letter' => 't',
    'listorder' => '0',
  ),
  254 => 
  array (
    'id' => '140223',
    'parentid' => '140200',
    'parentids' => '140000,140200,140223',
    'level' => '3',
    'name' => '广灵县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  255 => 
  array (
    'id' => '140224',
    'parentid' => '140200',
    'parentids' => '140000,140200,140224',
    'level' => '3',
    'name' => '灵丘县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  256 => 
  array (
    'id' => '140225',
    'parentid' => '140200',
    'parentids' => '140000,140200,140225',
    'level' => '3',
    'name' => '浑源县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  257 => 
  array (
    'id' => '140226',
    'parentid' => '140200',
    'parentids' => '140000,140200,140226',
    'level' => '3',
    'name' => '左云县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  258 => 
  array (
    'id' => '140227',
    'parentid' => '140200',
    'parentids' => '140000,140200,140227',
    'level' => '3',
    'name' => '大同县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  259 => 
  array (
    'id' => '140300',
    'parentid' => '140000',
    'parentids' => '140000,140300',
    'level' => '2',
    'name' => '阳泉市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  260 => 
  array (
    'id' => '140301',
    'parentid' => '140300',
    'parentids' => '140000,140300,140301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  261 => 
  array (
    'id' => '140302',
    'parentid' => '140300',
    'parentids' => '140000,140300,140302',
    'level' => '3',
    'name' => '城　区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  262 => 
  array (
    'id' => '140303',
    'parentid' => '140300',
    'parentids' => '140000,140300,140303',
    'level' => '3',
    'name' => '矿　区',
    'letter' => 'k',
    'listorder' => '0',
  ),
  263 => 
  array (
    'id' => '140311',
    'parentid' => '140300',
    'parentids' => '140000,140300,140311',
    'level' => '3',
    'name' => '郊　区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  264 => 
  array (
    'id' => '140321',
    'parentid' => '140300',
    'parentids' => '140000,140300,140321',
    'level' => '3',
    'name' => '平定县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  265 => 
  array (
    'id' => '140322',
    'parentid' => '140300',
    'parentids' => '140000,140300,140322',
    'level' => '3',
    'name' => '盂　县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  266 => 
  array (
    'id' => '140400',
    'parentid' => '140000',
    'parentids' => '140000,140400',
    'level' => '2',
    'name' => '长治市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  267 => 
  array (
    'id' => '140401',
    'parentid' => '140400',
    'parentids' => '140000,140400,140401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  268 => 
  array (
    'id' => '140402',
    'parentid' => '140400',
    'parentids' => '140000,140400,140402',
    'level' => '3',
    'name' => '城　区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  269 => 
  array (
    'id' => '140411',
    'parentid' => '140400',
    'parentids' => '140000,140400,140411',
    'level' => '3',
    'name' => '郊　区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  270 => 
  array (
    'id' => '140421',
    'parentid' => '140400',
    'parentids' => '140000,140400,140421',
    'level' => '3',
    'name' => '长治县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  271 => 
  array (
    'id' => '140423',
    'parentid' => '140400',
    'parentids' => '140000,140400,140423',
    'level' => '3',
    'name' => '襄垣县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  272 => 
  array (
    'id' => '140424',
    'parentid' => '140400',
    'parentids' => '140000,140400,140424',
    'level' => '3',
    'name' => '屯留县',
    'letter' => 't',
    'listorder' => '0',
  ),
  273 => 
  array (
    'id' => '140425',
    'parentid' => '140400',
    'parentids' => '140000,140400,140425',
    'level' => '3',
    'name' => '平顺县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  274 => 
  array (
    'id' => '140426',
    'parentid' => '140400',
    'parentids' => '140000,140400,140426',
    'level' => '3',
    'name' => '黎城县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  275 => 
  array (
    'id' => '140427',
    'parentid' => '140400',
    'parentids' => '140000,140400,140427',
    'level' => '3',
    'name' => '壶关县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  276 => 
  array (
    'id' => '140428',
    'parentid' => '140400',
    'parentids' => '140000,140400,140428',
    'level' => '3',
    'name' => '长子县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  277 => 
  array (
    'id' => '140429',
    'parentid' => '140400',
    'parentids' => '140000,140400,140429',
    'level' => '3',
    'name' => '武乡县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  278 => 
  array (
    'id' => '140430',
    'parentid' => '140400',
    'parentids' => '140000,140400,140430',
    'level' => '3',
    'name' => '沁　县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  279 => 
  array (
    'id' => '140431',
    'parentid' => '140400',
    'parentids' => '140000,140400,140431',
    'level' => '3',
    'name' => '沁源县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  280 => 
  array (
    'id' => '140481',
    'parentid' => '140400',
    'parentids' => '140000,140400,140481',
    'level' => '3',
    'name' => '潞城市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  281 => 
  array (
    'id' => '140500',
    'parentid' => '140000',
    'parentids' => '140000,140500',
    'level' => '2',
    'name' => '晋城市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  282 => 
  array (
    'id' => '140501',
    'parentid' => '140500',
    'parentids' => '140000,140500,140501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  283 => 
  array (
    'id' => '140502',
    'parentid' => '140500',
    'parentids' => '140000,140500,140502',
    'level' => '3',
    'name' => '城　区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  284 => 
  array (
    'id' => '140521',
    'parentid' => '140500',
    'parentids' => '140000,140500,140521',
    'level' => '3',
    'name' => '沁水县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  285 => 
  array (
    'id' => '140522',
    'parentid' => '140500',
    'parentids' => '140000,140500,140522',
    'level' => '3',
    'name' => '阳城县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  286 => 
  array (
    'id' => '140524',
    'parentid' => '140500',
    'parentids' => '140000,140500,140524',
    'level' => '3',
    'name' => '陵川县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  287 => 
  array (
    'id' => '140525',
    'parentid' => '140500',
    'parentids' => '140000,140500,140525',
    'level' => '3',
    'name' => '泽州县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  288 => 
  array (
    'id' => '140581',
    'parentid' => '140500',
    'parentids' => '140000,140500,140581',
    'level' => '3',
    'name' => '高平市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  289 => 
  array (
    'id' => '140600',
    'parentid' => '140000',
    'parentids' => '140000,140600',
    'level' => '2',
    'name' => '朔州市',
    'letter' => 's',
    'listorder' => '0',
  ),
  290 => 
  array (
    'id' => '140601',
    'parentid' => '140600',
    'parentids' => '140000,140600,140601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  291 => 
  array (
    'id' => '140602',
    'parentid' => '140600',
    'parentids' => '140000,140600,140602',
    'level' => '3',
    'name' => '朔城区',
    'letter' => 's',
    'listorder' => '0',
  ),
  292 => 
  array (
    'id' => '140603',
    'parentid' => '140600',
    'parentids' => '140000,140600,140603',
    'level' => '3',
    'name' => '平鲁区',
    'letter' => 'p',
    'listorder' => '0',
  ),
  293 => 
  array (
    'id' => '140621',
    'parentid' => '140600',
    'parentids' => '140000,140600,140621',
    'level' => '3',
    'name' => '山阴县',
    'letter' => 's',
    'listorder' => '0',
  ),
  294 => 
  array (
    'id' => '140622',
    'parentid' => '140600',
    'parentids' => '140000,140600,140622',
    'level' => '3',
    'name' => '应　县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  295 => 
  array (
    'id' => '140623',
    'parentid' => '140600',
    'parentids' => '140000,140600,140623',
    'level' => '3',
    'name' => '右玉县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  296 => 
  array (
    'id' => '140624',
    'parentid' => '140600',
    'parentids' => '140000,140600,140624',
    'level' => '3',
    'name' => '怀仁县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  297 => 
  array (
    'id' => '140700',
    'parentid' => '140000',
    'parentids' => '140000,140700',
    'level' => '2',
    'name' => '晋中市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  298 => 
  array (
    'id' => '140701',
    'parentid' => '140700',
    'parentids' => '140000,140700,140701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  299 => 
  array (
    'id' => '140702',
    'parentid' => '140700',
    'parentids' => '140000,140700,140702',
    'level' => '3',
    'name' => '榆次区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  300 => 
  array (
    'id' => '140721',
    'parentid' => '140700',
    'parentids' => '140000,140700,140721',
    'level' => '3',
    'name' => '榆社县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  301 => 
  array (
    'id' => '140722',
    'parentid' => '140700',
    'parentids' => '140000,140700,140722',
    'level' => '3',
    'name' => '左权县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  302 => 
  array (
    'id' => '140723',
    'parentid' => '140700',
    'parentids' => '140000,140700,140723',
    'level' => '3',
    'name' => '和顺县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  303 => 
  array (
    'id' => '140724',
    'parentid' => '140700',
    'parentids' => '140000,140700,140724',
    'level' => '3',
    'name' => '昔阳县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  304 => 
  array (
    'id' => '140725',
    'parentid' => '140700',
    'parentids' => '140000,140700,140725',
    'level' => '3',
    'name' => '寿阳县',
    'letter' => 's',
    'listorder' => '0',
  ),
  305 => 
  array (
    'id' => '140726',
    'parentid' => '140700',
    'parentids' => '140000,140700,140726',
    'level' => '3',
    'name' => '太谷县',
    'letter' => 't',
    'listorder' => '0',
  ),
  306 => 
  array (
    'id' => '140727',
    'parentid' => '140700',
    'parentids' => '140000,140700,140727',
    'level' => '3',
    'name' => '祁　县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  307 => 
  array (
    'id' => '140728',
    'parentid' => '140700',
    'parentids' => '140000,140700,140728',
    'level' => '3',
    'name' => '平遥县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  308 => 
  array (
    'id' => '140729',
    'parentid' => '140700',
    'parentids' => '140000,140700,140729',
    'level' => '3',
    'name' => '灵石县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  309 => 
  array (
    'id' => '140781',
    'parentid' => '140700',
    'parentids' => '140000,140700,140781',
    'level' => '3',
    'name' => '介休市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  310 => 
  array (
    'id' => '140800',
    'parentid' => '140000',
    'parentids' => '140000,140800',
    'level' => '2',
    'name' => '运城市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  311 => 
  array (
    'id' => '140801',
    'parentid' => '140800',
    'parentids' => '140000,140800,140801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  312 => 
  array (
    'id' => '140802',
    'parentid' => '140800',
    'parentids' => '140000,140800,140802',
    'level' => '3',
    'name' => '盐湖区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  313 => 
  array (
    'id' => '140821',
    'parentid' => '140800',
    'parentids' => '140000,140800,140821',
    'level' => '3',
    'name' => '临猗县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  314 => 
  array (
    'id' => '140822',
    'parentid' => '140800',
    'parentids' => '140000,140800,140822',
    'level' => '3',
    'name' => '万荣县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  315 => 
  array (
    'id' => '140823',
    'parentid' => '140800',
    'parentids' => '140000,140800,140823',
    'level' => '3',
    'name' => '闻喜县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  316 => 
  array (
    'id' => '140824',
    'parentid' => '140800',
    'parentids' => '140000,140800,140824',
    'level' => '3',
    'name' => '稷山县',
    'letter' => 's',
    'listorder' => '0',
  ),
  317 => 
  array (
    'id' => '140825',
    'parentid' => '140800',
    'parentids' => '140000,140800,140825',
    'level' => '3',
    'name' => '新绛县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  318 => 
  array (
    'id' => '140826',
    'parentid' => '140800',
    'parentids' => '140000,140800,140826',
    'level' => '3',
    'name' => '绛　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  319 => 
  array (
    'id' => '140827',
    'parentid' => '140800',
    'parentids' => '140000,140800,140827',
    'level' => '3',
    'name' => '垣曲县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  320 => 
  array (
    'id' => '140828',
    'parentid' => '140800',
    'parentids' => '140000,140800,140828',
    'level' => '3',
    'name' => '夏　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  321 => 
  array (
    'id' => '140829',
    'parentid' => '140800',
    'parentids' => '140000,140800,140829',
    'level' => '3',
    'name' => '平陆县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  322 => 
  array (
    'id' => '140830',
    'parentid' => '140800',
    'parentids' => '140000,140800,140830',
    'level' => '3',
    'name' => '芮城县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  323 => 
  array (
    'id' => '140881',
    'parentid' => '140800',
    'parentids' => '140000,140800,140881',
    'level' => '3',
    'name' => '永济市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  324 => 
  array (
    'id' => '140882',
    'parentid' => '140800',
    'parentids' => '140000,140800,140882',
    'level' => '3',
    'name' => '河津市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  325 => 
  array (
    'id' => '140900',
    'parentid' => '140000',
    'parentids' => '140000,140900',
    'level' => '2',
    'name' => '忻州市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  326 => 
  array (
    'id' => '140901',
    'parentid' => '140900',
    'parentids' => '140000,140900,140901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  327 => 
  array (
    'id' => '140902',
    'parentid' => '140900',
    'parentids' => '140000,140900,140902',
    'level' => '3',
    'name' => '忻府区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  328 => 
  array (
    'id' => '140921',
    'parentid' => '140900',
    'parentids' => '140000,140900,140921',
    'level' => '3',
    'name' => '定襄县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  329 => 
  array (
    'id' => '140922',
    'parentid' => '140900',
    'parentids' => '140000,140900,140922',
    'level' => '3',
    'name' => '五台县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  330 => 
  array (
    'id' => '140923',
    'parentid' => '140900',
    'parentids' => '140000,140900,140923',
    'level' => '3',
    'name' => '代　县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  331 => 
  array (
    'id' => '140924',
    'parentid' => '140900',
    'parentids' => '140000,140900,140924',
    'level' => '3',
    'name' => '繁峙县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  332 => 
  array (
    'id' => '140925',
    'parentid' => '140900',
    'parentids' => '140000,140900,140925',
    'level' => '3',
    'name' => '宁武县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  333 => 
  array (
    'id' => '140926',
    'parentid' => '140900',
    'parentids' => '140000,140900,140926',
    'level' => '3',
    'name' => '静乐县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  334 => 
  array (
    'id' => '140927',
    'parentid' => '140900',
    'parentids' => '140000,140900,140927',
    'level' => '3',
    'name' => '神池县',
    'letter' => 's',
    'listorder' => '0',
  ),
  335 => 
  array (
    'id' => '140928',
    'parentid' => '140900',
    'parentids' => '140000,140900,140928',
    'level' => '3',
    'name' => '五寨县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  336 => 
  array (
    'id' => '140929',
    'parentid' => '140900',
    'parentids' => '140000,140900,140929',
    'level' => '3',
    'name' => '岢岚县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  337 => 
  array (
    'id' => '140930',
    'parentid' => '140900',
    'parentids' => '140000,140900,140930',
    'level' => '3',
    'name' => '河曲县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  338 => 
  array (
    'id' => '140931',
    'parentid' => '140900',
    'parentids' => '140000,140900,140931',
    'level' => '3',
    'name' => '保德县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  339 => 
  array (
    'id' => '140932',
    'parentid' => '140900',
    'parentids' => '140000,140900,140932',
    'level' => '3',
    'name' => '偏关县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  340 => 
  array (
    'id' => '140981',
    'parentid' => '140900',
    'parentids' => '140000,140900,140981',
    'level' => '3',
    'name' => '原平市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  341 => 
  array (
    'id' => '141000',
    'parentid' => '140000',
    'parentids' => '140000,141000',
    'level' => '2',
    'name' => '临汾市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  342 => 
  array (
    'id' => '141001',
    'parentid' => '141000',
    'parentids' => '140000,141000,141001',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  343 => 
  array (
    'id' => '141002',
    'parentid' => '141000',
    'parentids' => '140000,141000,141002',
    'level' => '3',
    'name' => '尧都区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  344 => 
  array (
    'id' => '141021',
    'parentid' => '141000',
    'parentids' => '140000,141000,141021',
    'level' => '3',
    'name' => '曲沃县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  345 => 
  array (
    'id' => '141022',
    'parentid' => '141000',
    'parentids' => '140000,141000,141022',
    'level' => '3',
    'name' => '翼城县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  346 => 
  array (
    'id' => '141023',
    'parentid' => '141000',
    'parentids' => '140000,141000,141023',
    'level' => '3',
    'name' => '襄汾县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  347 => 
  array (
    'id' => '141024',
    'parentid' => '141000',
    'parentids' => '140000,141000,141024',
    'level' => '3',
    'name' => '洪洞县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  348 => 
  array (
    'id' => '141025',
    'parentid' => '141000',
    'parentids' => '140000,141000,141025',
    'level' => '3',
    'name' => '古　县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  349 => 
  array (
    'id' => '141026',
    'parentid' => '141000',
    'parentids' => '140000,141000,141026',
    'level' => '3',
    'name' => '安泽县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  350 => 
  array (
    'id' => '141027',
    'parentid' => '141000',
    'parentids' => '140000,141000,141027',
    'level' => '3',
    'name' => '浮山县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  351 => 
  array (
    'id' => '141028',
    'parentid' => '141000',
    'parentids' => '140000,141000,141028',
    'level' => '3',
    'name' => '吉　县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  352 => 
  array (
    'id' => '141029',
    'parentid' => '141000',
    'parentids' => '140000,141000,141029',
    'level' => '3',
    'name' => '乡宁县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  353 => 
  array (
    'id' => '141030',
    'parentid' => '141000',
    'parentids' => '140000,141000,141030',
    'level' => '3',
    'name' => '大宁县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  354 => 
  array (
    'id' => '141031',
    'parentid' => '141000',
    'parentids' => '140000,141000,141031',
    'level' => '3',
    'name' => '隰　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  355 => 
  array (
    'id' => '141032',
    'parentid' => '141000',
    'parentids' => '140000,141000,141032',
    'level' => '3',
    'name' => '永和县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  356 => 
  array (
    'id' => '141033',
    'parentid' => '141000',
    'parentids' => '140000,141000,141033',
    'level' => '3',
    'name' => '蒲　县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  357 => 
  array (
    'id' => '141034',
    'parentid' => '141000',
    'parentids' => '140000,141000,141034',
    'level' => '3',
    'name' => '汾西县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  358 => 
  array (
    'id' => '141081',
    'parentid' => '141000',
    'parentids' => '140000,141000,141081',
    'level' => '3',
    'name' => '侯马市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  359 => 
  array (
    'id' => '141082',
    'parentid' => '141000',
    'parentids' => '140000,141000,141082',
    'level' => '3',
    'name' => '霍州市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  360 => 
  array (
    'id' => '141100',
    'parentid' => '140000',
    'parentids' => '140000,141100',
    'level' => '2',
    'name' => '吕梁市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  361 => 
  array (
    'id' => '141101',
    'parentid' => '141100',
    'parentids' => '140000,141100,141101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  362 => 
  array (
    'id' => '141102',
    'parentid' => '141100',
    'parentids' => '140000,141100,141102',
    'level' => '3',
    'name' => '离石区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  363 => 
  array (
    'id' => '141121',
    'parentid' => '141100',
    'parentids' => '140000,141100,141121',
    'level' => '3',
    'name' => '文水县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  364 => 
  array (
    'id' => '141122',
    'parentid' => '141100',
    'parentids' => '140000,141100,141122',
    'level' => '3',
    'name' => '交城县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  365 => 
  array (
    'id' => '141123',
    'parentid' => '141100',
    'parentids' => '140000,141100,141123',
    'level' => '3',
    'name' => '兴　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  366 => 
  array (
    'id' => '141124',
    'parentid' => '141100',
    'parentids' => '140000,141100,141124',
    'level' => '3',
    'name' => '临　县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  367 => 
  array (
    'id' => '141125',
    'parentid' => '141100',
    'parentids' => '140000,141100,141125',
    'level' => '3',
    'name' => '柳林县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  368 => 
  array (
    'id' => '141126',
    'parentid' => '141100',
    'parentids' => '140000,141100,141126',
    'level' => '3',
    'name' => '石楼县',
    'letter' => 's',
    'listorder' => '0',
  ),
  369 => 
  array (
    'id' => '141127',
    'parentid' => '141100',
    'parentids' => '140000,141100,141127',
    'level' => '3',
    'name' => '岚　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  370 => 
  array (
    'id' => '141128',
    'parentid' => '141100',
    'parentids' => '140000,141100,141128',
    'level' => '3',
    'name' => '方山县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  371 => 
  array (
    'id' => '141129',
    'parentid' => '141100',
    'parentids' => '140000,141100,141129',
    'level' => '3',
    'name' => '中阳县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  372 => 
  array (
    'id' => '141130',
    'parentid' => '141100',
    'parentids' => '140000,141100,141130',
    'level' => '3',
    'name' => '交口县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  373 => 
  array (
    'id' => '141181',
    'parentid' => '141100',
    'parentids' => '140000,141100,141181',
    'level' => '3',
    'name' => '孝义市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  374 => 
  array (
    'id' => '141182',
    'parentid' => '141100',
    'parentids' => '140000,141100,141182',
    'level' => '3',
    'name' => '汾阳市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  375 => 
  array (
    'id' => '150000',
    'parentid' => '0',
    'parentids' => '150000',
    'level' => '1',
    'name' => '内蒙古自治区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  376 => 
  array (
    'id' => '150100',
    'parentid' => '150000',
    'parentids' => '150000,150100',
    'level' => '2',
    'name' => '呼和浩特市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  377 => 
  array (
    'id' => '150101',
    'parentid' => '150100',
    'parentids' => '150000,150100,150101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  378 => 
  array (
    'id' => '150102',
    'parentid' => '150100',
    'parentids' => '150000,150100,150102',
    'level' => '3',
    'name' => '新城区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  379 => 
  array (
    'id' => '150103',
    'parentid' => '150100',
    'parentids' => '150000,150100,150103',
    'level' => '3',
    'name' => '回民区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  380 => 
  array (
    'id' => '150104',
    'parentid' => '150100',
    'parentids' => '150000,150100,150104',
    'level' => '3',
    'name' => '玉泉区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  381 => 
  array (
    'id' => '150105',
    'parentid' => '150100',
    'parentids' => '150000,150100,150105',
    'level' => '3',
    'name' => '赛罕区',
    'letter' => 's',
    'listorder' => '0',
  ),
  382 => 
  array (
    'id' => '150121',
    'parentid' => '150100',
    'parentids' => '150000,150100,150121',
    'level' => '3',
    'name' => '土默特左旗',
    'letter' => 't',
    'listorder' => '0',
  ),
  383 => 
  array (
    'id' => '150122',
    'parentid' => '150100',
    'parentids' => '150000,150100,150122',
    'level' => '3',
    'name' => '托克托县',
    'letter' => 't',
    'listorder' => '0',
  ),
  384 => 
  array (
    'id' => '150123',
    'parentid' => '150100',
    'parentids' => '150000,150100,150123',
    'level' => '3',
    'name' => '和林格尔县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  385 => 
  array (
    'id' => '150124',
    'parentid' => '150100',
    'parentids' => '150000,150100,150124',
    'level' => '3',
    'name' => '清水河县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  386 => 
  array (
    'id' => '150125',
    'parentid' => '150100',
    'parentids' => '150000,150100,150125',
    'level' => '3',
    'name' => '武川县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  387 => 
  array (
    'id' => '150200',
    'parentid' => '150000',
    'parentids' => '150000,150200',
    'level' => '2',
    'name' => '包头市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  388 => 
  array (
    'id' => '150201',
    'parentid' => '150200',
    'parentids' => '150000,150200,150201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  389 => 
  array (
    'id' => '150202',
    'parentid' => '150200',
    'parentids' => '150000,150200,150202',
    'level' => '3',
    'name' => '东河区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  390 => 
  array (
    'id' => '150203',
    'parentid' => '150200',
    'parentids' => '150000,150200,150203',
    'level' => '3',
    'name' => '昆都仑区',
    'letter' => 'k',
    'listorder' => '0',
  ),
  391 => 
  array (
    'id' => '150204',
    'parentid' => '150200',
    'parentids' => '150000,150200,150204',
    'level' => '3',
    'name' => '青山区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  392 => 
  array (
    'id' => '150205',
    'parentid' => '150200',
    'parentids' => '150000,150200,150205',
    'level' => '3',
    'name' => '石拐区',
    'letter' => 's',
    'listorder' => '0',
  ),
  393 => 
  array (
    'id' => '150206',
    'parentid' => '150200',
    'parentids' => '150000,150200,150206',
    'level' => '3',
    'name' => '白云矿区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  394 => 
  array (
    'id' => '150207',
    'parentid' => '150200',
    'parentids' => '150000,150200,150207',
    'level' => '3',
    'name' => '九原区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  395 => 
  array (
    'id' => '150221',
    'parentid' => '150200',
    'parentids' => '150000,150200,150221',
    'level' => '3',
    'name' => '土默特右旗',
    'letter' => 't',
    'listorder' => '0',
  ),
  396 => 
  array (
    'id' => '150222',
    'parentid' => '150200',
    'parentids' => '150000,150200,150222',
    'level' => '3',
    'name' => '固阳县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  397 => 
  array (
    'id' => '150223',
    'parentid' => '150200',
    'parentids' => '150000,150200,150223',
    'level' => '3',
    'name' => '达尔罕茂明安联合旗',
    'letter' => 'd',
    'listorder' => '0',
  ),
  398 => 
  array (
    'id' => '150300',
    'parentid' => '150000',
    'parentids' => '150000,150300',
    'level' => '2',
    'name' => '乌海市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  399 => 
  array (
    'id' => '150301',
    'parentid' => '150300',
    'parentids' => '150000,150300,150301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  400 => 
  array (
    'id' => '150302',
    'parentid' => '150300',
    'parentids' => '150000,150300,150302',
    'level' => '3',
    'name' => '海勃湾区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  401 => 
  array (
    'id' => '150303',
    'parentid' => '150300',
    'parentids' => '150000,150300,150303',
    'level' => '3',
    'name' => '海南区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  402 => 
  array (
    'id' => '150304',
    'parentid' => '150300',
    'parentids' => '150000,150300,150304',
    'level' => '3',
    'name' => '乌达区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  403 => 
  array (
    'id' => '150400',
    'parentid' => '150000',
    'parentids' => '150000,150400',
    'level' => '2',
    'name' => '赤峰市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  404 => 
  array (
    'id' => '150401',
    'parentid' => '150400',
    'parentids' => '150000,150400,150401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  405 => 
  array (
    'id' => '150402',
    'parentid' => '150400',
    'parentids' => '150000,150400,150402',
    'level' => '3',
    'name' => '红山区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  406 => 
  array (
    'id' => '150403',
    'parentid' => '150400',
    'parentids' => '150000,150400,150403',
    'level' => '3',
    'name' => '元宝山区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  407 => 
  array (
    'id' => '150404',
    'parentid' => '150400',
    'parentids' => '150000,150400,150404',
    'level' => '3',
    'name' => '松山区',
    'letter' => 's',
    'listorder' => '0',
  ),
  408 => 
  array (
    'id' => '150421',
    'parentid' => '150400',
    'parentids' => '150000,150400,150421',
    'level' => '3',
    'name' => '阿鲁科尔沁旗',
    'letter' => 'a',
    'listorder' => '0',
  ),
  409 => 
  array (
    'id' => '150422',
    'parentid' => '150400',
    'parentids' => '150000,150400,150422',
    'level' => '3',
    'name' => '巴林左旗',
    'letter' => 'b',
    'listorder' => '0',
  ),
  410 => 
  array (
    'id' => '150423',
    'parentid' => '150400',
    'parentids' => '150000,150400,150423',
    'level' => '3',
    'name' => '巴林右旗',
    'letter' => 'b',
    'listorder' => '0',
  ),
  411 => 
  array (
    'id' => '150424',
    'parentid' => '150400',
    'parentids' => '150000,150400,150424',
    'level' => '3',
    'name' => '林西县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  412 => 
  array (
    'id' => '150425',
    'parentid' => '150400',
    'parentids' => '150000,150400,150425',
    'level' => '3',
    'name' => '克什克腾旗',
    'letter' => 'k',
    'listorder' => '0',
  ),
  413 => 
  array (
    'id' => '150426',
    'parentid' => '150400',
    'parentids' => '150000,150400,150426',
    'level' => '3',
    'name' => '翁牛特旗',
    'letter' => 'w',
    'listorder' => '0',
  ),
  414 => 
  array (
    'id' => '150428',
    'parentid' => '150400',
    'parentids' => '150000,150400,150428',
    'level' => '3',
    'name' => '喀喇沁旗',
    'letter' => 'k',
    'listorder' => '0',
  ),
  415 => 
  array (
    'id' => '150429',
    'parentid' => '150400',
    'parentids' => '150000,150400,150429',
    'level' => '3',
    'name' => '宁城县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  416 => 
  array (
    'id' => '150430',
    'parentid' => '150400',
    'parentids' => '150000,150400,150430',
    'level' => '3',
    'name' => '敖汉旗',
    'letter' => 'a',
    'listorder' => '0',
  ),
  417 => 
  array (
    'id' => '150500',
    'parentid' => '150000',
    'parentids' => '150000,150500',
    'level' => '2',
    'name' => '通辽市',
    'letter' => 't',
    'listorder' => '0',
  ),
  418 => 
  array (
    'id' => '150501',
    'parentid' => '150500',
    'parentids' => '150000,150500,150501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  419 => 
  array (
    'id' => '150502',
    'parentid' => '150500',
    'parentids' => '150000,150500,150502',
    'level' => '3',
    'name' => '科尔沁区',
    'letter' => 'k',
    'listorder' => '0',
  ),
  420 => 
  array (
    'id' => '150521',
    'parentid' => '150500',
    'parentids' => '150000,150500,150521',
    'level' => '3',
    'name' => '科尔沁左翼中旗',
    'letter' => 'k',
    'listorder' => '0',
  ),
  421 => 
  array (
    'id' => '150522',
    'parentid' => '150500',
    'parentids' => '150000,150500,150522',
    'level' => '3',
    'name' => '科尔沁左翼后旗',
    'letter' => 'k',
    'listorder' => '0',
  ),
  422 => 
  array (
    'id' => '150523',
    'parentid' => '150500',
    'parentids' => '150000,150500,150523',
    'level' => '3',
    'name' => '开鲁县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  423 => 
  array (
    'id' => '150524',
    'parentid' => '150500',
    'parentids' => '150000,150500,150524',
    'level' => '3',
    'name' => '库伦旗',
    'letter' => 'k',
    'listorder' => '0',
  ),
  424 => 
  array (
    'id' => '150525',
    'parentid' => '150500',
    'parentids' => '150000,150500,150525',
    'level' => '3',
    'name' => '奈曼旗',
    'letter' => 'n',
    'listorder' => '0',
  ),
  425 => 
  array (
    'id' => '150526',
    'parentid' => '150500',
    'parentids' => '150000,150500,150526',
    'level' => '3',
    'name' => '扎鲁特旗',
    'letter' => 'z',
    'listorder' => '0',
  ),
  426 => 
  array (
    'id' => '150581',
    'parentid' => '150500',
    'parentids' => '150000,150500,150581',
    'level' => '3',
    'name' => '霍林郭勒市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  427 => 
  array (
    'id' => '150600',
    'parentid' => '150000',
    'parentids' => '150000,150600',
    'level' => '2',
    'name' => '鄂尔多斯市',
    'letter' => 'e',
    'listorder' => '0',
  ),
  428 => 
  array (
    'id' => '150602',
    'parentid' => '150600',
    'parentids' => '150000,150600,150602',
    'level' => '3',
    'name' => '东胜区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  429 => 
  array (
    'id' => '150621',
    'parentid' => '150600',
    'parentids' => '150000,150600,150621',
    'level' => '3',
    'name' => '达拉特旗',
    'letter' => 'd',
    'listorder' => '0',
  ),
  430 => 
  array (
    'id' => '150622',
    'parentid' => '150600',
    'parentids' => '150000,150600,150622',
    'level' => '3',
    'name' => '准格尔旗',
    'letter' => 'z',
    'listorder' => '0',
  ),
  431 => 
  array (
    'id' => '150623',
    'parentid' => '150600',
    'parentids' => '150000,150600,150623',
    'level' => '3',
    'name' => '鄂托克前旗',
    'letter' => 'e',
    'listorder' => '0',
  ),
  432 => 
  array (
    'id' => '150624',
    'parentid' => '150600',
    'parentids' => '150000,150600,150624',
    'level' => '3',
    'name' => '鄂托克旗',
    'letter' => 'e',
    'listorder' => '0',
  ),
  433 => 
  array (
    'id' => '150625',
    'parentid' => '150600',
    'parentids' => '150000,150600,150625',
    'level' => '3',
    'name' => '杭锦旗',
    'letter' => 'h',
    'listorder' => '0',
  ),
  434 => 
  array (
    'id' => '150626',
    'parentid' => '150600',
    'parentids' => '150000,150600,150626',
    'level' => '3',
    'name' => '乌审旗',
    'letter' => 'w',
    'listorder' => '0',
  ),
  435 => 
  array (
    'id' => '150627',
    'parentid' => '150600',
    'parentids' => '150000,150600,150627',
    'level' => '3',
    'name' => '伊金霍洛旗',
    'letter' => 'y',
    'listorder' => '0',
  ),
  436 => 
  array (
    'id' => '150700',
    'parentid' => '150000',
    'parentids' => '150000,150700',
    'level' => '2',
    'name' => '呼伦贝尔市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  437 => 
  array (
    'id' => '150701',
    'parentid' => '150700',
    'parentids' => '150000,150700,150701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  438 => 
  array (
    'id' => '150702',
    'parentid' => '150700',
    'parentids' => '150000,150700,150702',
    'level' => '3',
    'name' => '海拉尔区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  439 => 
  array (
    'id' => '150721',
    'parentid' => '150700',
    'parentids' => '150000,150700,150721',
    'level' => '3',
    'name' => '阿荣旗',
    'letter' => 'a',
    'listorder' => '0',
  ),
  440 => 
  array (
    'id' => '150722',
    'parentid' => '150700',
    'parentids' => '150000,150700,150722',
    'level' => '3',
    'name' => '莫力达瓦达斡尔族自治旗',
    'letter' => 'm',
    'listorder' => '0',
  ),
  441 => 
  array (
    'id' => '150723',
    'parentid' => '150700',
    'parentids' => '150000,150700,150723',
    'level' => '3',
    'name' => '鄂伦春自治旗',
    'letter' => 'e',
    'listorder' => '0',
  ),
  442 => 
  array (
    'id' => '150724',
    'parentid' => '150700',
    'parentids' => '150000,150700,150724',
    'level' => '3',
    'name' => '鄂温克族自治旗',
    'letter' => 'e',
    'listorder' => '0',
  ),
  443 => 
  array (
    'id' => '150725',
    'parentid' => '150700',
    'parentids' => '150000,150700,150725',
    'level' => '3',
    'name' => '陈巴尔虎旗',
    'letter' => 'c',
    'listorder' => '0',
  ),
  444 => 
  array (
    'id' => '150726',
    'parentid' => '150700',
    'parentids' => '150000,150700,150726',
    'level' => '3',
    'name' => '新巴尔虎左旗',
    'letter' => 'x',
    'listorder' => '0',
  ),
  445 => 
  array (
    'id' => '150727',
    'parentid' => '150700',
    'parentids' => '150000,150700,150727',
    'level' => '3',
    'name' => '新巴尔虎右旗',
    'letter' => 'x',
    'listorder' => '0',
  ),
  446 => 
  array (
    'id' => '150781',
    'parentid' => '150700',
    'parentids' => '150000,150700,150781',
    'level' => '3',
    'name' => '满洲里市',
    'letter' => 'm',
    'listorder' => '0',
  ),
  447 => 
  array (
    'id' => '150782',
    'parentid' => '150700',
    'parentids' => '150000,150700,150782',
    'level' => '3',
    'name' => '牙克石市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  448 => 
  array (
    'id' => '150783',
    'parentid' => '150700',
    'parentids' => '150000,150700,150783',
    'level' => '3',
    'name' => '扎兰屯市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  449 => 
  array (
    'id' => '150784',
    'parentid' => '150700',
    'parentids' => '150000,150700,150784',
    'level' => '3',
    'name' => '额尔古纳市',
    'letter' => 'e',
    'listorder' => '0',
  ),
  450 => 
  array (
    'id' => '150785',
    'parentid' => '150700',
    'parentids' => '150000,150700,150785',
    'level' => '3',
    'name' => '根河市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  451 => 
  array (
    'id' => '150800',
    'parentid' => '150000',
    'parentids' => '150000,150800',
    'level' => '2',
    'name' => '巴彦淖尔市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  452 => 
  array (
    'id' => '150801',
    'parentid' => '150800',
    'parentids' => '150000,150800,150801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  453 => 
  array (
    'id' => '150802',
    'parentid' => '150800',
    'parentids' => '150000,150800,150802',
    'level' => '3',
    'name' => '临河区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  454 => 
  array (
    'id' => '150821',
    'parentid' => '150800',
    'parentids' => '150000,150800,150821',
    'level' => '3',
    'name' => '五原县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  455 => 
  array (
    'id' => '150822',
    'parentid' => '150800',
    'parentids' => '150000,150800,150822',
    'level' => '3',
    'name' => '磴口县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  456 => 
  array (
    'id' => '150823',
    'parentid' => '150800',
    'parentids' => '150000,150800,150823',
    'level' => '3',
    'name' => '乌拉特前旗',
    'letter' => 'w',
    'listorder' => '0',
  ),
  457 => 
  array (
    'id' => '150824',
    'parentid' => '150800',
    'parentids' => '150000,150800,150824',
    'level' => '3',
    'name' => '乌拉特中旗',
    'letter' => 'w',
    'listorder' => '0',
  ),
  458 => 
  array (
    'id' => '150825',
    'parentid' => '150800',
    'parentids' => '150000,150800,150825',
    'level' => '3',
    'name' => '乌拉特后旗',
    'letter' => 'w',
    'listorder' => '0',
  ),
  459 => 
  array (
    'id' => '150826',
    'parentid' => '150800',
    'parentids' => '150000,150800,150826',
    'level' => '3',
    'name' => '杭锦后旗',
    'letter' => 'h',
    'listorder' => '0',
  ),
  460 => 
  array (
    'id' => '150900',
    'parentid' => '150000',
    'parentids' => '150000,150900',
    'level' => '2',
    'name' => '乌兰察布市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  461 => 
  array (
    'id' => '150901',
    'parentid' => '150900',
    'parentids' => '150000,150900,150901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  462 => 
  array (
    'id' => '150902',
    'parentid' => '150900',
    'parentids' => '150000,150900,150902',
    'level' => '3',
    'name' => '集宁区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  463 => 
  array (
    'id' => '150921',
    'parentid' => '150900',
    'parentids' => '150000,150900,150921',
    'level' => '3',
    'name' => '卓资县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  464 => 
  array (
    'id' => '150922',
    'parentid' => '150900',
    'parentids' => '150000,150900,150922',
    'level' => '3',
    'name' => '化德县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  465 => 
  array (
    'id' => '150923',
    'parentid' => '150900',
    'parentids' => '150000,150900,150923',
    'level' => '3',
    'name' => '商都县',
    'letter' => 's',
    'listorder' => '0',
  ),
  466 => 
  array (
    'id' => '150924',
    'parentid' => '150900',
    'parentids' => '150000,150900,150924',
    'level' => '3',
    'name' => '兴和县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  467 => 
  array (
    'id' => '150925',
    'parentid' => '150900',
    'parentids' => '150000,150900,150925',
    'level' => '3',
    'name' => '凉城县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  468 => 
  array (
    'id' => '150926',
    'parentid' => '150900',
    'parentids' => '150000,150900,150926',
    'level' => '3',
    'name' => '察哈尔右翼前旗',
    'letter' => 'c',
    'listorder' => '0',
  ),
  469 => 
  array (
    'id' => '150927',
    'parentid' => '150900',
    'parentids' => '150000,150900,150927',
    'level' => '3',
    'name' => '察哈尔右翼中旗',
    'letter' => 'c',
    'listorder' => '0',
  ),
  470 => 
  array (
    'id' => '150928',
    'parentid' => '150900',
    'parentids' => '150000,150900,150928',
    'level' => '3',
    'name' => '察哈尔右翼后旗',
    'letter' => 'c',
    'listorder' => '0',
  ),
  471 => 
  array (
    'id' => '150929',
    'parentid' => '150900',
    'parentids' => '150000,150900,150929',
    'level' => '3',
    'name' => '四子王旗',
    'letter' => 's',
    'listorder' => '0',
  ),
  472 => 
  array (
    'id' => '150981',
    'parentid' => '150900',
    'parentids' => '150000,150900,150981',
    'level' => '3',
    'name' => '丰镇市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  473 => 
  array (
    'id' => '152200',
    'parentid' => '150000',
    'parentids' => '150000,152200',
    'level' => '2',
    'name' => '兴安盟',
    'letter' => 'x',
    'listorder' => '0',
  ),
  474 => 
  array (
    'id' => '152201',
    'parentid' => '152200',
    'parentids' => '150000,152200,152201',
    'level' => '3',
    'name' => '乌兰浩特市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  475 => 
  array (
    'id' => '152202',
    'parentid' => '152200',
    'parentids' => '150000,152200,152202',
    'level' => '3',
    'name' => '阿尔山市',
    'letter' => 'a',
    'listorder' => '0',
  ),
  476 => 
  array (
    'id' => '152221',
    'parentid' => '152200',
    'parentids' => '150000,152200,152221',
    'level' => '3',
    'name' => '科尔沁右翼前旗',
    'letter' => 'k',
    'listorder' => '0',
  ),
  477 => 
  array (
    'id' => '152222',
    'parentid' => '152200',
    'parentids' => '150000,152200,152222',
    'level' => '3',
    'name' => '科尔沁右翼中旗',
    'letter' => 'k',
    'listorder' => '0',
  ),
  478 => 
  array (
    'id' => '152223',
    'parentid' => '152200',
    'parentids' => '150000,152200,152223',
    'level' => '3',
    'name' => '扎赉特旗',
    'letter' => 'z',
    'listorder' => '0',
  ),
  479 => 
  array (
    'id' => '152224',
    'parentid' => '152200',
    'parentids' => '150000,152200,152224',
    'level' => '3',
    'name' => '突泉县',
    'letter' => 't',
    'listorder' => '0',
  ),
  480 => 
  array (
    'id' => '152500',
    'parentid' => '150000',
    'parentids' => '150000,152500',
    'level' => '2',
    'name' => '锡林郭勒盟',
    'letter' => 'x',
    'listorder' => '0',
  ),
  481 => 
  array (
    'id' => '152501',
    'parentid' => '152500',
    'parentids' => '150000,152500,152501',
    'level' => '3',
    'name' => '二连浩特市',
    'letter' => 'e',
    'listorder' => '0',
  ),
  482 => 
  array (
    'id' => '152502',
    'parentid' => '152500',
    'parentids' => '150000,152500,152502',
    'level' => '3',
    'name' => '锡林浩特市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  483 => 
  array (
    'id' => '152522',
    'parentid' => '152500',
    'parentids' => '150000,152500,152522',
    'level' => '3',
    'name' => '阿巴嘎旗',
    'letter' => 'a',
    'listorder' => '0',
  ),
  484 => 
  array (
    'id' => '152523',
    'parentid' => '152500',
    'parentids' => '150000,152500,152523',
    'level' => '3',
    'name' => '苏尼特左旗',
    'letter' => 's',
    'listorder' => '0',
  ),
  485 => 
  array (
    'id' => '152524',
    'parentid' => '152500',
    'parentids' => '150000,152500,152524',
    'level' => '3',
    'name' => '苏尼特右旗',
    'letter' => 's',
    'listorder' => '0',
  ),
  486 => 
  array (
    'id' => '152525',
    'parentid' => '152500',
    'parentids' => '150000,152500,152525',
    'level' => '3',
    'name' => '东乌珠穆沁旗',
    'letter' => 'd',
    'listorder' => '0',
  ),
  487 => 
  array (
    'id' => '152526',
    'parentid' => '152500',
    'parentids' => '150000,152500,152526',
    'level' => '3',
    'name' => '西乌珠穆沁旗',
    'letter' => 'x',
    'listorder' => '0',
  ),
  488 => 
  array (
    'id' => '152527',
    'parentid' => '152500',
    'parentids' => '150000,152500,152527',
    'level' => '3',
    'name' => '太仆寺旗',
    'letter' => 't',
    'listorder' => '0',
  ),
  489 => 
  array (
    'id' => '152528',
    'parentid' => '152500',
    'parentids' => '150000,152500,152528',
    'level' => '3',
    'name' => '镶黄旗',
    'letter' => 'x',
    'listorder' => '0',
  ),
  490 => 
  array (
    'id' => '152529',
    'parentid' => '152500',
    'parentids' => '150000,152500,152529',
    'level' => '3',
    'name' => '正镶白旗',
    'letter' => 'z',
    'listorder' => '0',
  ),
  491 => 
  array (
    'id' => '152530',
    'parentid' => '152500',
    'parentids' => '150000,152500,152530',
    'level' => '3',
    'name' => '正蓝旗',
    'letter' => 'z',
    'listorder' => '0',
  ),
  492 => 
  array (
    'id' => '152531',
    'parentid' => '152500',
    'parentids' => '150000,152500,152531',
    'level' => '3',
    'name' => '多伦县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  493 => 
  array (
    'id' => '152900',
    'parentid' => '150000',
    'parentids' => '150000,152900',
    'level' => '2',
    'name' => '阿拉善盟',
    'letter' => 'a',
    'listorder' => '0',
  ),
  494 => 
  array (
    'id' => '152921',
    'parentid' => '152900',
    'parentids' => '150000,152900,152921',
    'level' => '3',
    'name' => '阿拉善左旗',
    'letter' => 'a',
    'listorder' => '0',
  ),
  495 => 
  array (
    'id' => '152922',
    'parentid' => '152900',
    'parentids' => '150000,152900,152922',
    'level' => '3',
    'name' => '阿拉善右旗',
    'letter' => 'a',
    'listorder' => '0',
  ),
  496 => 
  array (
    'id' => '152923',
    'parentid' => '152900',
    'parentids' => '150000,152900,152923',
    'level' => '3',
    'name' => '额济纳旗',
    'letter' => 'e',
    'listorder' => '0',
  ),
  497 => 
  array (
    'id' => '210000',
    'parentid' => '0',
    'parentids' => '210000',
    'level' => '1',
    'name' => '辽宁省',
    'letter' => 'l',
    'listorder' => '0',
  ),
  498 => 
  array (
    'id' => '210100',
    'parentid' => '210000',
    'parentids' => '210000,210100',
    'level' => '2',
    'name' => '沈阳市',
    'letter' => 's',
    'listorder' => '0',
  ),
  499 => 
  array (
    'id' => '210101',
    'parentid' => '210100',
    'parentids' => '210000,210100,210101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  500 => 
  array (
    'id' => '210102',
    'parentid' => '210100',
    'parentids' => '210000,210100,210102',
    'level' => '3',
    'name' => '和平区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  501 => 
  array (
    'id' => '210103',
    'parentid' => '210100',
    'parentids' => '210000,210100,210103',
    'level' => '3',
    'name' => '沈河区',
    'letter' => 's',
    'listorder' => '0',
  ),
  502 => 
  array (
    'id' => '210104',
    'parentid' => '210100',
    'parentids' => '210000,210100,210104',
    'level' => '3',
    'name' => '大东区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  503 => 
  array (
    'id' => '210105',
    'parentid' => '210100',
    'parentids' => '210000,210100,210105',
    'level' => '3',
    'name' => '皇姑区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  504 => 
  array (
    'id' => '210106',
    'parentid' => '210100',
    'parentids' => '210000,210100,210106',
    'level' => '3',
    'name' => '铁西区',
    'letter' => 't',
    'listorder' => '0',
  ),
  505 => 
  array (
    'id' => '210111',
    'parentid' => '210100',
    'parentids' => '210000,210100,210111',
    'level' => '3',
    'name' => '苏家屯区',
    'letter' => 's',
    'listorder' => '0',
  ),
  506 => 
  array (
    'id' => '210112',
    'parentid' => '210100',
    'parentids' => '210000,210100,210112',
    'level' => '3',
    'name' => '东陵区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  507 => 
  array (
    'id' => '210113',
    'parentid' => '210100',
    'parentids' => '210000,210100,210113',
    'level' => '3',
    'name' => '新城子区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  508 => 
  array (
    'id' => '210114',
    'parentid' => '210100',
    'parentids' => '210000,210100,210114',
    'level' => '3',
    'name' => '于洪区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  509 => 
  array (
    'id' => '210122',
    'parentid' => '210100',
    'parentids' => '210000,210100,210122',
    'level' => '3',
    'name' => '辽中县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  510 => 
  array (
    'id' => '210123',
    'parentid' => '210100',
    'parentids' => '210000,210100,210123',
    'level' => '3',
    'name' => '康平县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  511 => 
  array (
    'id' => '210124',
    'parentid' => '210100',
    'parentids' => '210000,210100,210124',
    'level' => '3',
    'name' => '法库县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  512 => 
  array (
    'id' => '210181',
    'parentid' => '210100',
    'parentids' => '210000,210100,210181',
    'level' => '3',
    'name' => '新民市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  513 => 
  array (
    'id' => '210200',
    'parentid' => '210000',
    'parentids' => '210000,210200',
    'level' => '2',
    'name' => '大连市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  514 => 
  array (
    'id' => '210201',
    'parentid' => '210200',
    'parentids' => '210000,210200,210201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  515 => 
  array (
    'id' => '210202',
    'parentid' => '210200',
    'parentids' => '210000,210200,210202',
    'level' => '3',
    'name' => '中山区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  516 => 
  array (
    'id' => '210203',
    'parentid' => '210200',
    'parentids' => '210000,210200,210203',
    'level' => '3',
    'name' => '西岗区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  517 => 
  array (
    'id' => '210204',
    'parentid' => '210200',
    'parentids' => '210000,210200,210204',
    'level' => '3',
    'name' => '沙河口区',
    'letter' => 's',
    'listorder' => '0',
  ),
  518 => 
  array (
    'id' => '210211',
    'parentid' => '210200',
    'parentids' => '210000,210200,210211',
    'level' => '3',
    'name' => '甘井子区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  519 => 
  array (
    'id' => '210212',
    'parentid' => '210200',
    'parentids' => '210000,210200,210212',
    'level' => '3',
    'name' => '旅顺口区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  520 => 
  array (
    'id' => '210213',
    'parentid' => '210200',
    'parentids' => '210000,210200,210213',
    'level' => '3',
    'name' => '金州区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  521 => 
  array (
    'id' => '210224',
    'parentid' => '210200',
    'parentids' => '210000,210200,210224',
    'level' => '3',
    'name' => '长海县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  522 => 
  array (
    'id' => '210281',
    'parentid' => '210200',
    'parentids' => '210000,210200,210281',
    'level' => '3',
    'name' => '瓦房店市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  523 => 
  array (
    'id' => '210282',
    'parentid' => '210200',
    'parentids' => '210000,210200,210282',
    'level' => '3',
    'name' => '普兰店市',
    'letter' => 'p',
    'listorder' => '0',
  ),
  524 => 
  array (
    'id' => '210283',
    'parentid' => '210200',
    'parentids' => '210000,210200,210283',
    'level' => '3',
    'name' => '庄河市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  525 => 
  array (
    'id' => '210300',
    'parentid' => '210000',
    'parentids' => '210000,210300',
    'level' => '2',
    'name' => '鞍山市',
    'letter' => 'a',
    'listorder' => '0',
  ),
  526 => 
  array (
    'id' => '210301',
    'parentid' => '210300',
    'parentids' => '210000,210300,210301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  527 => 
  array (
    'id' => '210302',
    'parentid' => '210300',
    'parentids' => '210000,210300,210302',
    'level' => '3',
    'name' => '铁东区',
    'letter' => 't',
    'listorder' => '0',
  ),
  528 => 
  array (
    'id' => '210303',
    'parentid' => '210300',
    'parentids' => '210000,210300,210303',
    'level' => '3',
    'name' => '铁西区',
    'letter' => 't',
    'listorder' => '0',
  ),
  529 => 
  array (
    'id' => '210304',
    'parentid' => '210300',
    'parentids' => '210000,210300,210304',
    'level' => '3',
    'name' => '立山区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  530 => 
  array (
    'id' => '210311',
    'parentid' => '210300',
    'parentids' => '210000,210300,210311',
    'level' => '3',
    'name' => '千山区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  531 => 
  array (
    'id' => '210321',
    'parentid' => '210300',
    'parentids' => '210000,210300,210321',
    'level' => '3',
    'name' => '台安县',
    'letter' => 't',
    'listorder' => '0',
  ),
  532 => 
  array (
    'id' => '210323',
    'parentid' => '210300',
    'parentids' => '210000,210300,210323',
    'level' => '3',
    'name' => '岫岩满族自治县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  533 => 
  array (
    'id' => '210381',
    'parentid' => '210300',
    'parentids' => '210000,210300,210381',
    'level' => '3',
    'name' => '海城市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  534 => 
  array (
    'id' => '210400',
    'parentid' => '210000',
    'parentids' => '210000,210400',
    'level' => '2',
    'name' => '抚顺市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  535 => 
  array (
    'id' => '210401',
    'parentid' => '210400',
    'parentids' => '210000,210400,210401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  536 => 
  array (
    'id' => '210402',
    'parentid' => '210400',
    'parentids' => '210000,210400,210402',
    'level' => '3',
    'name' => '新抚区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  537 => 
  array (
    'id' => '210403',
    'parentid' => '210400',
    'parentids' => '210000,210400,210403',
    'level' => '3',
    'name' => '东洲区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  538 => 
  array (
    'id' => '210404',
    'parentid' => '210400',
    'parentids' => '210000,210400,210404',
    'level' => '3',
    'name' => '望花区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  539 => 
  array (
    'id' => '210411',
    'parentid' => '210400',
    'parentids' => '210000,210400,210411',
    'level' => '3',
    'name' => '顺城区',
    'letter' => 's',
    'listorder' => '0',
  ),
  540 => 
  array (
    'id' => '210421',
    'parentid' => '210400',
    'parentids' => '210000,210400,210421',
    'level' => '3',
    'name' => '抚顺县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  541 => 
  array (
    'id' => '210422',
    'parentid' => '210400',
    'parentids' => '210000,210400,210422',
    'level' => '3',
    'name' => '新宾满族自治县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  542 => 
  array (
    'id' => '210423',
    'parentid' => '210400',
    'parentids' => '210000,210400,210423',
    'level' => '3',
    'name' => '清原满族自治县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  543 => 
  array (
    'id' => '210500',
    'parentid' => '210000',
    'parentids' => '210000,210500',
    'level' => '2',
    'name' => '本溪市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  544 => 
  array (
    'id' => '210501',
    'parentid' => '210500',
    'parentids' => '210000,210500,210501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  545 => 
  array (
    'id' => '210502',
    'parentid' => '210500',
    'parentids' => '210000,210500,210502',
    'level' => '3',
    'name' => '平山区',
    'letter' => 'p',
    'listorder' => '0',
  ),
  546 => 
  array (
    'id' => '210503',
    'parentid' => '210500',
    'parentids' => '210000,210500,210503',
    'level' => '3',
    'name' => '溪湖区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  547 => 
  array (
    'id' => '210504',
    'parentid' => '210500',
    'parentids' => '210000,210500,210504',
    'level' => '3',
    'name' => '明山区',
    'letter' => 'm',
    'listorder' => '0',
  ),
  548 => 
  array (
    'id' => '210505',
    'parentid' => '210500',
    'parentids' => '210000,210500,210505',
    'level' => '3',
    'name' => '南芬区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  549 => 
  array (
    'id' => '210521',
    'parentid' => '210500',
    'parentids' => '210000,210500,210521',
    'level' => '3',
    'name' => '本溪满族自治县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  550 => 
  array (
    'id' => '210522',
    'parentid' => '210500',
    'parentids' => '210000,210500,210522',
    'level' => '3',
    'name' => '桓仁满族自治县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  551 => 
  array (
    'id' => '210600',
    'parentid' => '210000',
    'parentids' => '210000,210600',
    'level' => '2',
    'name' => '丹东市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  552 => 
  array (
    'id' => '210601',
    'parentid' => '210600',
    'parentids' => '210000,210600,210601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  553 => 
  array (
    'id' => '210602',
    'parentid' => '210600',
    'parentids' => '210000,210600,210602',
    'level' => '3',
    'name' => '元宝区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  554 => 
  array (
    'id' => '210603',
    'parentid' => '210600',
    'parentids' => '210000,210600,210603',
    'level' => '3',
    'name' => '振兴区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  555 => 
  array (
    'id' => '210604',
    'parentid' => '210600',
    'parentids' => '210000,210600,210604',
    'level' => '3',
    'name' => '振安区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  556 => 
  array (
    'id' => '210624',
    'parentid' => '210600',
    'parentids' => '210000,210600,210624',
    'level' => '3',
    'name' => '宽甸满族自治县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  557 => 
  array (
    'id' => '210681',
    'parentid' => '210600',
    'parentids' => '210000,210600,210681',
    'level' => '3',
    'name' => '东港市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  558 => 
  array (
    'id' => '210682',
    'parentid' => '210600',
    'parentids' => '210000,210600,210682',
    'level' => '3',
    'name' => '凤城市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  559 => 
  array (
    'id' => '210700',
    'parentid' => '210000',
    'parentids' => '210000,210700',
    'level' => '2',
    'name' => '锦州市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  560 => 
  array (
    'id' => '210701',
    'parentid' => '210700',
    'parentids' => '210000,210700,210701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  561 => 
  array (
    'id' => '210702',
    'parentid' => '210700',
    'parentids' => '210000,210700,210702',
    'level' => '3',
    'name' => '古塔区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  562 => 
  array (
    'id' => '210703',
    'parentid' => '210700',
    'parentids' => '210000,210700,210703',
    'level' => '3',
    'name' => '凌河区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  563 => 
  array (
    'id' => '210711',
    'parentid' => '210700',
    'parentids' => '210000,210700,210711',
    'level' => '3',
    'name' => '太和区',
    'letter' => 't',
    'listorder' => '0',
  ),
  564 => 
  array (
    'id' => '210726',
    'parentid' => '210700',
    'parentids' => '210000,210700,210726',
    'level' => '3',
    'name' => '黑山县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  565 => 
  array (
    'id' => '210727',
    'parentid' => '210700',
    'parentids' => '210000,210700,210727',
    'level' => '3',
    'name' => '义　县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  566 => 
  array (
    'id' => '210781',
    'parentid' => '210700',
    'parentids' => '210000,210700,210781',
    'level' => '3',
    'name' => '凌海市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  567 => 
  array (
    'id' => '210782',
    'parentid' => '210700',
    'parentids' => '210000,210700,210782',
    'level' => '3',
    'name' => '北宁市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  568 => 
  array (
    'id' => '210800',
    'parentid' => '210000',
    'parentids' => '210000,210800',
    'level' => '2',
    'name' => '营口市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  569 => 
  array (
    'id' => '210801',
    'parentid' => '210800',
    'parentids' => '210000,210800,210801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  570 => 
  array (
    'id' => '210802',
    'parentid' => '210800',
    'parentids' => '210000,210800,210802',
    'level' => '3',
    'name' => '站前区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  571 => 
  array (
    'id' => '210803',
    'parentid' => '210800',
    'parentids' => '210000,210800,210803',
    'level' => '3',
    'name' => '西市区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  572 => 
  array (
    'id' => '210804',
    'parentid' => '210800',
    'parentids' => '210000,210800,210804',
    'level' => '3',
    'name' => '鲅鱼圈区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  573 => 
  array (
    'id' => '210811',
    'parentid' => '210800',
    'parentids' => '210000,210800,210811',
    'level' => '3',
    'name' => '老边区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  574 => 
  array (
    'id' => '210881',
    'parentid' => '210800',
    'parentids' => '210000,210800,210881',
    'level' => '3',
    'name' => '盖州市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  575 => 
  array (
    'id' => '210882',
    'parentid' => '210800',
    'parentids' => '210000,210800,210882',
    'level' => '3',
    'name' => '大石桥市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  576 => 
  array (
    'id' => '210900',
    'parentid' => '210000',
    'parentids' => '210000,210900',
    'level' => '2',
    'name' => '阜新市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  577 => 
  array (
    'id' => '210901',
    'parentid' => '210900',
    'parentids' => '210000,210900,210901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  578 => 
  array (
    'id' => '210902',
    'parentid' => '210900',
    'parentids' => '210000,210900,210902',
    'level' => '3',
    'name' => '海州区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  579 => 
  array (
    'id' => '210903',
    'parentid' => '210900',
    'parentids' => '210000,210900,210903',
    'level' => '3',
    'name' => '新邱区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  580 => 
  array (
    'id' => '210904',
    'parentid' => '210900',
    'parentids' => '210000,210900,210904',
    'level' => '3',
    'name' => '太平区',
    'letter' => 't',
    'listorder' => '0',
  ),
  581 => 
  array (
    'id' => '210905',
    'parentid' => '210900',
    'parentids' => '210000,210900,210905',
    'level' => '3',
    'name' => '清河门区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  582 => 
  array (
    'id' => '210911',
    'parentid' => '210900',
    'parentids' => '210000,210900,210911',
    'level' => '3',
    'name' => '细河区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  583 => 
  array (
    'id' => '210921',
    'parentid' => '210900',
    'parentids' => '210000,210900,210921',
    'level' => '3',
    'name' => '阜新蒙古族自治县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  584 => 
  array (
    'id' => '210922',
    'parentid' => '210900',
    'parentids' => '210000,210900,210922',
    'level' => '3',
    'name' => '彰武县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  585 => 
  array (
    'id' => '211000',
    'parentid' => '210000',
    'parentids' => '210000,211000',
    'level' => '2',
    'name' => '辽阳市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  586 => 
  array (
    'id' => '211001',
    'parentid' => '211000',
    'parentids' => '210000,211000,211001',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  587 => 
  array (
    'id' => '211002',
    'parentid' => '211000',
    'parentids' => '210000,211000,211002',
    'level' => '3',
    'name' => '白塔区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  588 => 
  array (
    'id' => '211003',
    'parentid' => '211000',
    'parentids' => '210000,211000,211003',
    'level' => '3',
    'name' => '文圣区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  589 => 
  array (
    'id' => '211004',
    'parentid' => '211000',
    'parentids' => '210000,211000,211004',
    'level' => '3',
    'name' => '宏伟区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  590 => 
  array (
    'id' => '211005',
    'parentid' => '211000',
    'parentids' => '210000,211000,211005',
    'level' => '3',
    'name' => '弓长岭区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  591 => 
  array (
    'id' => '211011',
    'parentid' => '211000',
    'parentids' => '210000,211000,211011',
    'level' => '3',
    'name' => '太子河区',
    'letter' => 't',
    'listorder' => '0',
  ),
  592 => 
  array (
    'id' => '211021',
    'parentid' => '211000',
    'parentids' => '210000,211000,211021',
    'level' => '3',
    'name' => '辽阳县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  593 => 
  array (
    'id' => '211081',
    'parentid' => '211000',
    'parentids' => '210000,211000,211081',
    'level' => '3',
    'name' => '灯塔市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  594 => 
  array (
    'id' => '211100',
    'parentid' => '210000',
    'parentids' => '210000,211100',
    'level' => '2',
    'name' => '盘锦市',
    'letter' => 'p',
    'listorder' => '0',
  ),
  595 => 
  array (
    'id' => '211101',
    'parentid' => '211100',
    'parentids' => '210000,211100,211101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  596 => 
  array (
    'id' => '211102',
    'parentid' => '211100',
    'parentids' => '210000,211100,211102',
    'level' => '3',
    'name' => '双台子区',
    'letter' => 's',
    'listorder' => '0',
  ),
  597 => 
  array (
    'id' => '211103',
    'parentid' => '211100',
    'parentids' => '210000,211100,211103',
    'level' => '3',
    'name' => '兴隆台区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  598 => 
  array (
    'id' => '211121',
    'parentid' => '211100',
    'parentids' => '210000,211100,211121',
    'level' => '3',
    'name' => '大洼县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  599 => 
  array (
    'id' => '211122',
    'parentid' => '211100',
    'parentids' => '210000,211100,211122',
    'level' => '3',
    'name' => '盘山县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  600 => 
  array (
    'id' => '211200',
    'parentid' => '210000',
    'parentids' => '210000,211200',
    'level' => '2',
    'name' => '铁岭市',
    'letter' => 't',
    'listorder' => '0',
  ),
  601 => 
  array (
    'id' => '211201',
    'parentid' => '211200',
    'parentids' => '210000,211200,211201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  602 => 
  array (
    'id' => '211202',
    'parentid' => '211200',
    'parentids' => '210000,211200,211202',
    'level' => '3',
    'name' => '银州区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  603 => 
  array (
    'id' => '211204',
    'parentid' => '211200',
    'parentids' => '210000,211200,211204',
    'level' => '3',
    'name' => '清河区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  604 => 
  array (
    'id' => '211221',
    'parentid' => '211200',
    'parentids' => '210000,211200,211221',
    'level' => '3',
    'name' => '铁岭县',
    'letter' => 't',
    'listorder' => '0',
  ),
  605 => 
  array (
    'id' => '211223',
    'parentid' => '211200',
    'parentids' => '210000,211200,211223',
    'level' => '3',
    'name' => '西丰县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  606 => 
  array (
    'id' => '211224',
    'parentid' => '211200',
    'parentids' => '210000,211200,211224',
    'level' => '3',
    'name' => '昌图县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  607 => 
  array (
    'id' => '211281',
    'parentid' => '211200',
    'parentids' => '210000,211200,211281',
    'level' => '3',
    'name' => '调兵山市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  608 => 
  array (
    'id' => '211282',
    'parentid' => '211200',
    'parentids' => '210000,211200,211282',
    'level' => '3',
    'name' => '开原市',
    'letter' => 'k',
    'listorder' => '0',
  ),
  609 => 
  array (
    'id' => '211300',
    'parentid' => '210000',
    'parentids' => '210000,211300',
    'level' => '2',
    'name' => '朝阳市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  610 => 
  array (
    'id' => '211301',
    'parentid' => '211300',
    'parentids' => '210000,211300,211301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  611 => 
  array (
    'id' => '211302',
    'parentid' => '211300',
    'parentids' => '210000,211300,211302',
    'level' => '3',
    'name' => '双塔区',
    'letter' => 's',
    'listorder' => '0',
  ),
  612 => 
  array (
    'id' => '211303',
    'parentid' => '211300',
    'parentids' => '210000,211300,211303',
    'level' => '3',
    'name' => '龙城区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  613 => 
  array (
    'id' => '211321',
    'parentid' => '211300',
    'parentids' => '210000,211300,211321',
    'level' => '3',
    'name' => '朝阳县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  614 => 
  array (
    'id' => '211322',
    'parentid' => '211300',
    'parentids' => '210000,211300,211322',
    'level' => '3',
    'name' => '建平县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  615 => 
  array (
    'id' => '211324',
    'parentid' => '211300',
    'parentids' => '210000,211300,211324',
    'level' => '3',
    'name' => '喀喇沁左翼蒙古族自治县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  616 => 
  array (
    'id' => '211381',
    'parentid' => '211300',
    'parentids' => '210000,211300,211381',
    'level' => '3',
    'name' => '北票市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  617 => 
  array (
    'id' => '211382',
    'parentid' => '211300',
    'parentids' => '210000,211300,211382',
    'level' => '3',
    'name' => '凌源市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  618 => 
  array (
    'id' => '211400',
    'parentid' => '210000',
    'parentids' => '210000,211400',
    'level' => '2',
    'name' => '葫芦岛市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  619 => 
  array (
    'id' => '211401',
    'parentid' => '211400',
    'parentids' => '210000,211400,211401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  620 => 
  array (
    'id' => '211402',
    'parentid' => '211400',
    'parentids' => '210000,211400,211402',
    'level' => '3',
    'name' => '连山区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  621 => 
  array (
    'id' => '211403',
    'parentid' => '211400',
    'parentids' => '210000,211400,211403',
    'level' => '3',
    'name' => '龙港区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  622 => 
  array (
    'id' => '211404',
    'parentid' => '211400',
    'parentids' => '210000,211400,211404',
    'level' => '3',
    'name' => '南票区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  623 => 
  array (
    'id' => '211421',
    'parentid' => '211400',
    'parentids' => '210000,211400,211421',
    'level' => '3',
    'name' => '绥中县',
    'letter' => 's',
    'listorder' => '0',
  ),
  624 => 
  array (
    'id' => '211422',
    'parentid' => '211400',
    'parentids' => '210000,211400,211422',
    'level' => '3',
    'name' => '建昌县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  625 => 
  array (
    'id' => '211481',
    'parentid' => '211400',
    'parentids' => '210000,211400,211481',
    'level' => '3',
    'name' => '兴城市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  626 => 
  array (
    'id' => '220000',
    'parentid' => '0',
    'parentids' => '220000',
    'level' => '1',
    'name' => '吉林省',
    'letter' => 'j',
    'listorder' => '0',
  ),
  627 => 
  array (
    'id' => '220100',
    'parentid' => '220000',
    'parentids' => '220000,220100',
    'level' => '2',
    'name' => '长春市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  628 => 
  array (
    'id' => '220101',
    'parentid' => '220100',
    'parentids' => '220000,220100,220101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  629 => 
  array (
    'id' => '220102',
    'parentid' => '220100',
    'parentids' => '220000,220100,220102',
    'level' => '3',
    'name' => '南关区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  630 => 
  array (
    'id' => '220103',
    'parentid' => '220100',
    'parentids' => '220000,220100,220103',
    'level' => '3',
    'name' => '宽城区',
    'letter' => 'k',
    'listorder' => '0',
  ),
  631 => 
  array (
    'id' => '220104',
    'parentid' => '220100',
    'parentids' => '220000,220100,220104',
    'level' => '3',
    'name' => '朝阳区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  632 => 
  array (
    'id' => '220105',
    'parentid' => '220100',
    'parentids' => '220000,220100,220105',
    'level' => '3',
    'name' => '二道区',
    'letter' => 'e',
    'listorder' => '0',
  ),
  633 => 
  array (
    'id' => '220106',
    'parentid' => '220100',
    'parentids' => '220000,220100,220106',
    'level' => '3',
    'name' => '绿园区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  634 => 
  array (
    'id' => '220112',
    'parentid' => '220100',
    'parentids' => '220000,220100,220112',
    'level' => '3',
    'name' => '双阳区',
    'letter' => 's',
    'listorder' => '0',
  ),
  635 => 
  array (
    'id' => '220122',
    'parentid' => '220100',
    'parentids' => '220000,220100,220122',
    'level' => '3',
    'name' => '农安县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  636 => 
  array (
    'id' => '220181',
    'parentid' => '220100',
    'parentids' => '220000,220100,220181',
    'level' => '3',
    'name' => '九台市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  637 => 
  array (
    'id' => '220182',
    'parentid' => '220100',
    'parentids' => '220000,220100,220182',
    'level' => '3',
    'name' => '榆树市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  638 => 
  array (
    'id' => '220183',
    'parentid' => '220100',
    'parentids' => '220000,220100,220183',
    'level' => '3',
    'name' => '德惠市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  639 => 
  array (
    'id' => '220200',
    'parentid' => '220000',
    'parentids' => '220000,220200',
    'level' => '2',
    'name' => '吉林市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  640 => 
  array (
    'id' => '220201',
    'parentid' => '220200',
    'parentids' => '220000,220200,220201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  641 => 
  array (
    'id' => '220202',
    'parentid' => '220200',
    'parentids' => '220000,220200,220202',
    'level' => '3',
    'name' => '昌邑区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  642 => 
  array (
    'id' => '220203',
    'parentid' => '220200',
    'parentids' => '220000,220200,220203',
    'level' => '3',
    'name' => '龙潭区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  643 => 
  array (
    'id' => '220204',
    'parentid' => '220200',
    'parentids' => '220000,220200,220204',
    'level' => '3',
    'name' => '船营区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  644 => 
  array (
    'id' => '220211',
    'parentid' => '220200',
    'parentids' => '220000,220200,220211',
    'level' => '3',
    'name' => '丰满区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  645 => 
  array (
    'id' => '220221',
    'parentid' => '220200',
    'parentids' => '220000,220200,220221',
    'level' => '3',
    'name' => '永吉县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  646 => 
  array (
    'id' => '220281',
    'parentid' => '220200',
    'parentids' => '220000,220200,220281',
    'level' => '3',
    'name' => '蛟河市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  647 => 
  array (
    'id' => '220282',
    'parentid' => '220200',
    'parentids' => '220000,220200,220282',
    'level' => '3',
    'name' => '桦甸市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  648 => 
  array (
    'id' => '220283',
    'parentid' => '220200',
    'parentids' => '220000,220200,220283',
    'level' => '3',
    'name' => '舒兰市',
    'letter' => 's',
    'listorder' => '0',
  ),
  649 => 
  array (
    'id' => '220284',
    'parentid' => '220200',
    'parentids' => '220000,220200,220284',
    'level' => '3',
    'name' => '磐石市',
    'letter' => 'p',
    'listorder' => '0',
  ),
  650 => 
  array (
    'id' => '220300',
    'parentid' => '220000',
    'parentids' => '220000,220300',
    'level' => '2',
    'name' => '四平市',
    'letter' => 's',
    'listorder' => '0',
  ),
  651 => 
  array (
    'id' => '220301',
    'parentid' => '220300',
    'parentids' => '220000,220300,220301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  652 => 
  array (
    'id' => '220302',
    'parentid' => '220300',
    'parentids' => '220000,220300,220302',
    'level' => '3',
    'name' => '铁西区',
    'letter' => 't',
    'listorder' => '0',
  ),
  653 => 
  array (
    'id' => '220303',
    'parentid' => '220300',
    'parentids' => '220000,220300,220303',
    'level' => '3',
    'name' => '铁东区',
    'letter' => 't',
    'listorder' => '0',
  ),
  654 => 
  array (
    'id' => '220322',
    'parentid' => '220300',
    'parentids' => '220000,220300,220322',
    'level' => '3',
    'name' => '梨树县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  655 => 
  array (
    'id' => '220323',
    'parentid' => '220300',
    'parentids' => '220000,220300,220323',
    'level' => '3',
    'name' => '伊通满族自治县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  656 => 
  array (
    'id' => '220381',
    'parentid' => '220300',
    'parentids' => '220000,220300,220381',
    'level' => '3',
    'name' => '公主岭市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  657 => 
  array (
    'id' => '220382',
    'parentid' => '220300',
    'parentids' => '220000,220300,220382',
    'level' => '3',
    'name' => '双辽市',
    'letter' => 's',
    'listorder' => '0',
  ),
  658 => 
  array (
    'id' => '220400',
    'parentid' => '220000',
    'parentids' => '220000,220400',
    'level' => '2',
    'name' => '辽源市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  659 => 
  array (
    'id' => '220401',
    'parentid' => '220400',
    'parentids' => '220000,220400,220401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  660 => 
  array (
    'id' => '220402',
    'parentid' => '220400',
    'parentids' => '220000,220400,220402',
    'level' => '3',
    'name' => '龙山区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  661 => 
  array (
    'id' => '220403',
    'parentid' => '220400',
    'parentids' => '220000,220400,220403',
    'level' => '3',
    'name' => '西安区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  662 => 
  array (
    'id' => '220421',
    'parentid' => '220400',
    'parentids' => '220000,220400,220421',
    'level' => '3',
    'name' => '东丰县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  663 => 
  array (
    'id' => '220422',
    'parentid' => '220400',
    'parentids' => '220000,220400,220422',
    'level' => '3',
    'name' => '东辽县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  664 => 
  array (
    'id' => '220500',
    'parentid' => '220000',
    'parentids' => '220000,220500',
    'level' => '2',
    'name' => '通化市',
    'letter' => 't',
    'listorder' => '0',
  ),
  665 => 
  array (
    'id' => '220501',
    'parentid' => '220500',
    'parentids' => '220000,220500,220501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  666 => 
  array (
    'id' => '220502',
    'parentid' => '220500',
    'parentids' => '220000,220500,220502',
    'level' => '3',
    'name' => '东昌区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  667 => 
  array (
    'id' => '220503',
    'parentid' => '220500',
    'parentids' => '220000,220500,220503',
    'level' => '3',
    'name' => '二道江区',
    'letter' => 'e',
    'listorder' => '0',
  ),
  668 => 
  array (
    'id' => '220521',
    'parentid' => '220500',
    'parentids' => '220000,220500,220521',
    'level' => '3',
    'name' => '通化县',
    'letter' => 't',
    'listorder' => '0',
  ),
  669 => 
  array (
    'id' => '220523',
    'parentid' => '220500',
    'parentids' => '220000,220500,220523',
    'level' => '3',
    'name' => '辉南县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  670 => 
  array (
    'id' => '220524',
    'parentid' => '220500',
    'parentids' => '220000,220500,220524',
    'level' => '3',
    'name' => '柳河县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  671 => 
  array (
    'id' => '220581',
    'parentid' => '220500',
    'parentids' => '220000,220500,220581',
    'level' => '3',
    'name' => '梅河口市',
    'letter' => 'm',
    'listorder' => '0',
  ),
  672 => 
  array (
    'id' => '220582',
    'parentid' => '220500',
    'parentids' => '220000,220500,220582',
    'level' => '3',
    'name' => '集安市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  673 => 
  array (
    'id' => '220600',
    'parentid' => '220000',
    'parentids' => '220000,220600',
    'level' => '2',
    'name' => '白山市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  674 => 
  array (
    'id' => '220601',
    'parentid' => '220600',
    'parentids' => '220000,220600,220601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  675 => 
  array (
    'id' => '220602',
    'parentid' => '220600',
    'parentids' => '220000,220600,220602',
    'level' => '3',
    'name' => '八道江区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  676 => 
  array (
    'id' => '220621',
    'parentid' => '220600',
    'parentids' => '220000,220600,220621',
    'level' => '3',
    'name' => '抚松县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  677 => 
  array (
    'id' => '220622',
    'parentid' => '220600',
    'parentids' => '220000,220600,220622',
    'level' => '3',
    'name' => '靖宇县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  678 => 
  array (
    'id' => '220623',
    'parentid' => '220600',
    'parentids' => '220000,220600,220623',
    'level' => '3',
    'name' => '长白朝鲜族自治县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  679 => 
  array (
    'id' => '220625',
    'parentid' => '220600',
    'parentids' => '220000,220600,220625',
    'level' => '3',
    'name' => '江源县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  680 => 
  array (
    'id' => '220681',
    'parentid' => '220600',
    'parentids' => '220000,220600,220681',
    'level' => '3',
    'name' => '临江市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  681 => 
  array (
    'id' => '220700',
    'parentid' => '220000',
    'parentids' => '220000,220700',
    'level' => '2',
    'name' => '松原市',
    'letter' => 's',
    'listorder' => '0',
  ),
  682 => 
  array (
    'id' => '220701',
    'parentid' => '220700',
    'parentids' => '220000,220700,220701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  683 => 
  array (
    'id' => '220702',
    'parentid' => '220700',
    'parentids' => '220000,220700,220702',
    'level' => '3',
    'name' => '宁江区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  684 => 
  array (
    'id' => '220721',
    'parentid' => '220700',
    'parentids' => '220000,220700,220721',
    'level' => '3',
    'name' => '前郭尔罗斯蒙古族自治县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  685 => 
  array (
    'id' => '220722',
    'parentid' => '220700',
    'parentids' => '220000,220700,220722',
    'level' => '3',
    'name' => '长岭县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  686 => 
  array (
    'id' => '220723',
    'parentid' => '220700',
    'parentids' => '220000,220700,220723',
    'level' => '3',
    'name' => '乾安县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  687 => 
  array (
    'id' => '220724',
    'parentid' => '220700',
    'parentids' => '220000,220700,220724',
    'level' => '3',
    'name' => '扶余县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  688 => 
  array (
    'id' => '220800',
    'parentid' => '220000',
    'parentids' => '220000,220800',
    'level' => '2',
    'name' => '白城市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  689 => 
  array (
    'id' => '220801',
    'parentid' => '220800',
    'parentids' => '220000,220800,220801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  690 => 
  array (
    'id' => '220802',
    'parentid' => '220800',
    'parentids' => '220000,220800,220802',
    'level' => '3',
    'name' => '洮北区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  691 => 
  array (
    'id' => '220821',
    'parentid' => '220800',
    'parentids' => '220000,220800,220821',
    'level' => '3',
    'name' => '镇赉县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  692 => 
  array (
    'id' => '220822',
    'parentid' => '220800',
    'parentids' => '220000,220800,220822',
    'level' => '3',
    'name' => '通榆县',
    'letter' => 't',
    'listorder' => '0',
  ),
  693 => 
  array (
    'id' => '220881',
    'parentid' => '220800',
    'parentids' => '220000,220800,220881',
    'level' => '3',
    'name' => '洮南市',
    'letter' => 'n',
    'listorder' => '0',
  ),
  694 => 
  array (
    'id' => '220882',
    'parentid' => '220800',
    'parentids' => '220000,220800,220882',
    'level' => '3',
    'name' => '大安市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  695 => 
  array (
    'id' => '222400',
    'parentid' => '220000',
    'parentids' => '220000,222400',
    'level' => '2',
    'name' => '延边朝鲜族自治州',
    'letter' => 'y',
    'listorder' => '0',
  ),
  696 => 
  array (
    'id' => '222401',
    'parentid' => '222400',
    'parentids' => '220000,222400,222401',
    'level' => '3',
    'name' => '延吉市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  697 => 
  array (
    'id' => '222402',
    'parentid' => '222400',
    'parentids' => '220000,222400,222402',
    'level' => '3',
    'name' => '图们市',
    'letter' => 't',
    'listorder' => '0',
  ),
  698 => 
  array (
    'id' => '222403',
    'parentid' => '222400',
    'parentids' => '220000,222400,222403',
    'level' => '3',
    'name' => '敦化市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  699 => 
  array (
    'id' => '222404',
    'parentid' => '222400',
    'parentids' => '220000,222400,222404',
    'level' => '3',
    'name' => '珲春市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  700 => 
  array (
    'id' => '222405',
    'parentid' => '222400',
    'parentids' => '220000,222400,222405',
    'level' => '3',
    'name' => '龙井市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  701 => 
  array (
    'id' => '222406',
    'parentid' => '222400',
    'parentids' => '220000,222400,222406',
    'level' => '3',
    'name' => '和龙市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  702 => 
  array (
    'id' => '222424',
    'parentid' => '222400',
    'parentids' => '220000,222400,222424',
    'level' => '3',
    'name' => '汪清县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  703 => 
  array (
    'id' => '222426',
    'parentid' => '222400',
    'parentids' => '220000,222400,222426',
    'level' => '3',
    'name' => '安图县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  704 => 
  array (
    'id' => '230000',
    'parentid' => '0',
    'parentids' => '230000',
    'level' => '1',
    'name' => '黑龙江省',
    'letter' => 'h',
    'listorder' => '0',
  ),
  705 => 
  array (
    'id' => '230100',
    'parentid' => '230000',
    'parentids' => '230000,230100',
    'level' => '2',
    'name' => '哈尔滨市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  706 => 
  array (
    'id' => '230101',
    'parentid' => '230100',
    'parentids' => '230000,230100,230101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  707 => 
  array (
    'id' => '230102',
    'parentid' => '230100',
    'parentids' => '230000,230100,230102',
    'level' => '3',
    'name' => '道里区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  708 => 
  array (
    'id' => '230103',
    'parentid' => '230100',
    'parentids' => '230000,230100,230103',
    'level' => '3',
    'name' => '南岗区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  709 => 
  array (
    'id' => '230104',
    'parentid' => '230100',
    'parentids' => '230000,230100,230104',
    'level' => '3',
    'name' => '道外区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  710 => 
  array (
    'id' => '230106',
    'parentid' => '230100',
    'parentids' => '230000,230100,230106',
    'level' => '3',
    'name' => '香坊区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  711 => 
  array (
    'id' => '230107',
    'parentid' => '230100',
    'parentids' => '230000,230100,230107',
    'level' => '3',
    'name' => '动力区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  712 => 
  array (
    'id' => '230108',
    'parentid' => '230100',
    'parentids' => '230000,230100,230108',
    'level' => '3',
    'name' => '平房区',
    'letter' => 'p',
    'listorder' => '0',
  ),
  713 => 
  array (
    'id' => '230109',
    'parentid' => '230100',
    'parentids' => '230000,230100,230109',
    'level' => '3',
    'name' => '松北区',
    'letter' => 's',
    'listorder' => '0',
  ),
  714 => 
  array (
    'id' => '230111',
    'parentid' => '230100',
    'parentids' => '230000,230100,230111',
    'level' => '3',
    'name' => '呼兰区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  715 => 
  array (
    'id' => '230123',
    'parentid' => '230100',
    'parentids' => '230000,230100,230123',
    'level' => '3',
    'name' => '依兰县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  716 => 
  array (
    'id' => '230124',
    'parentid' => '230100',
    'parentids' => '230000,230100,230124',
    'level' => '3',
    'name' => '方正县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  717 => 
  array (
    'id' => '230125',
    'parentid' => '230100',
    'parentids' => '230000,230100,230125',
    'level' => '3',
    'name' => '宾　县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  718 => 
  array (
    'id' => '230126',
    'parentid' => '230100',
    'parentids' => '230000,230100,230126',
    'level' => '3',
    'name' => '巴彦县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  719 => 
  array (
    'id' => '230127',
    'parentid' => '230100',
    'parentids' => '230000,230100,230127',
    'level' => '3',
    'name' => '木兰县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  720 => 
  array (
    'id' => '230128',
    'parentid' => '230100',
    'parentids' => '230000,230100,230128',
    'level' => '3',
    'name' => '通河县',
    'letter' => 't',
    'listorder' => '0',
  ),
  721 => 
  array (
    'id' => '230129',
    'parentid' => '230100',
    'parentids' => '230000,230100,230129',
    'level' => '3',
    'name' => '延寿县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  722 => 
  array (
    'id' => '230181',
    'parentid' => '230100',
    'parentids' => '230000,230100,230181',
    'level' => '3',
    'name' => '阿城市',
    'letter' => 'a',
    'listorder' => '0',
  ),
  723 => 
  array (
    'id' => '230182',
    'parentid' => '230100',
    'parentids' => '230000,230100,230182',
    'level' => '3',
    'name' => '双城市',
    'letter' => 's',
    'listorder' => '0',
  ),
  724 => 
  array (
    'id' => '230183',
    'parentid' => '230100',
    'parentids' => '230000,230100,230183',
    'level' => '3',
    'name' => '尚志市',
    'letter' => 's',
    'listorder' => '0',
  ),
  725 => 
  array (
    'id' => '230184',
    'parentid' => '230100',
    'parentids' => '230000,230100,230184',
    'level' => '3',
    'name' => '五常市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  726 => 
  array (
    'id' => '230200',
    'parentid' => '230000',
    'parentids' => '230000,230200',
    'level' => '2',
    'name' => '齐齐哈尔市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  727 => 
  array (
    'id' => '230201',
    'parentid' => '230200',
    'parentids' => '230000,230200,230201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  728 => 
  array (
    'id' => '230202',
    'parentid' => '230200',
    'parentids' => '230000,230200,230202',
    'level' => '3',
    'name' => '龙沙区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  729 => 
  array (
    'id' => '230203',
    'parentid' => '230200',
    'parentids' => '230000,230200,230203',
    'level' => '3',
    'name' => '建华区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  730 => 
  array (
    'id' => '230204',
    'parentid' => '230200',
    'parentids' => '230000,230200,230204',
    'level' => '3',
    'name' => '铁锋区',
    'letter' => 't',
    'listorder' => '0',
  ),
  731 => 
  array (
    'id' => '230205',
    'parentid' => '230200',
    'parentids' => '230000,230200,230205',
    'level' => '3',
    'name' => '昂昂溪区',
    'letter' => 'a',
    'listorder' => '0',
  ),
  732 => 
  array (
    'id' => '230206',
    'parentid' => '230200',
    'parentids' => '230000,230200,230206',
    'level' => '3',
    'name' => '富拉尔基区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  733 => 
  array (
    'id' => '230207',
    'parentid' => '230200',
    'parentids' => '230000,230200,230207',
    'level' => '3',
    'name' => '碾子山区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  734 => 
  array (
    'id' => '230208',
    'parentid' => '230200',
    'parentids' => '230000,230200,230208',
    'level' => '3',
    'name' => '梅里斯达斡尔族区',
    'letter' => 'm',
    'listorder' => '0',
  ),
  735 => 
  array (
    'id' => '230221',
    'parentid' => '230200',
    'parentids' => '230000,230200,230221',
    'level' => '3',
    'name' => '龙江县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  736 => 
  array (
    'id' => '230223',
    'parentid' => '230200',
    'parentids' => '230000,230200,230223',
    'level' => '3',
    'name' => '依安县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  737 => 
  array (
    'id' => '230224',
    'parentid' => '230200',
    'parentids' => '230000,230200,230224',
    'level' => '3',
    'name' => '泰来县',
    'letter' => 't',
    'listorder' => '0',
  ),
  738 => 
  array (
    'id' => '230225',
    'parentid' => '230200',
    'parentids' => '230000,230200,230225',
    'level' => '3',
    'name' => '甘南县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  739 => 
  array (
    'id' => '230227',
    'parentid' => '230200',
    'parentids' => '230000,230200,230227',
    'level' => '3',
    'name' => '富裕县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  740 => 
  array (
    'id' => '230229',
    'parentid' => '230200',
    'parentids' => '230000,230200,230229',
    'level' => '3',
    'name' => '克山县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  741 => 
  array (
    'id' => '230230',
    'parentid' => '230200',
    'parentids' => '230000,230200,230230',
    'level' => '3',
    'name' => '克东县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  742 => 
  array (
    'id' => '230231',
    'parentid' => '230200',
    'parentids' => '230000,230200,230231',
    'level' => '3',
    'name' => '拜泉县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  743 => 
  array (
    'id' => '230281',
    'parentid' => '230200',
    'parentids' => '230000,230200,230281',
    'level' => '3',
    'name' => '讷河市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  744 => 
  array (
    'id' => '230300',
    'parentid' => '230000',
    'parentids' => '230000,230300',
    'level' => '2',
    'name' => '鸡西市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  745 => 
  array (
    'id' => '230301',
    'parentid' => '230300',
    'parentids' => '230000,230300,230301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  746 => 
  array (
    'id' => '230302',
    'parentid' => '230300',
    'parentids' => '230000,230300,230302',
    'level' => '3',
    'name' => '鸡冠区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  747 => 
  array (
    'id' => '230303',
    'parentid' => '230300',
    'parentids' => '230000,230300,230303',
    'level' => '3',
    'name' => '恒山区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  748 => 
  array (
    'id' => '230304',
    'parentid' => '230300',
    'parentids' => '230000,230300,230304',
    'level' => '3',
    'name' => '滴道区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  749 => 
  array (
    'id' => '230305',
    'parentid' => '230300',
    'parentids' => '230000,230300,230305',
    'level' => '3',
    'name' => '梨树区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  750 => 
  array (
    'id' => '230306',
    'parentid' => '230300',
    'parentids' => '230000,230300,230306',
    'level' => '3',
    'name' => '城子河区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  751 => 
  array (
    'id' => '230307',
    'parentid' => '230300',
    'parentids' => '230000,230300,230307',
    'level' => '3',
    'name' => '麻山区',
    'letter' => 'm',
    'listorder' => '0',
  ),
  752 => 
  array (
    'id' => '230321',
    'parentid' => '230300',
    'parentids' => '230000,230300,230321',
    'level' => '3',
    'name' => '鸡东县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  753 => 
  array (
    'id' => '230381',
    'parentid' => '230300',
    'parentids' => '230000,230300,230381',
    'level' => '3',
    'name' => '虎林市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  754 => 
  array (
    'id' => '230382',
    'parentid' => '230300',
    'parentids' => '230000,230300,230382',
    'level' => '3',
    'name' => '密山市',
    'letter' => 'm',
    'listorder' => '0',
  ),
  755 => 
  array (
    'id' => '230400',
    'parentid' => '230000',
    'parentids' => '230000,230400',
    'level' => '2',
    'name' => '鹤岗市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  756 => 
  array (
    'id' => '230401',
    'parentid' => '230400',
    'parentids' => '230000,230400,230401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  757 => 
  array (
    'id' => '230402',
    'parentid' => '230400',
    'parentids' => '230000,230400,230402',
    'level' => '3',
    'name' => '向阳区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  758 => 
  array (
    'id' => '230403',
    'parentid' => '230400',
    'parentids' => '230000,230400,230403',
    'level' => '3',
    'name' => '工农区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  759 => 
  array (
    'id' => '230404',
    'parentid' => '230400',
    'parentids' => '230000,230400,230404',
    'level' => '3',
    'name' => '南山区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  760 => 
  array (
    'id' => '230405',
    'parentid' => '230400',
    'parentids' => '230000,230400,230405',
    'level' => '3',
    'name' => '兴安区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  761 => 
  array (
    'id' => '230406',
    'parentid' => '230400',
    'parentids' => '230000,230400,230406',
    'level' => '3',
    'name' => '东山区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  762 => 
  array (
    'id' => '230407',
    'parentid' => '230400',
    'parentids' => '230000,230400,230407',
    'level' => '3',
    'name' => '兴山区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  763 => 
  array (
    'id' => '230421',
    'parentid' => '230400',
    'parentids' => '230000,230400,230421',
    'level' => '3',
    'name' => '萝北县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  764 => 
  array (
    'id' => '230422',
    'parentid' => '230400',
    'parentids' => '230000,230400,230422',
    'level' => '3',
    'name' => '绥滨县',
    'letter' => 's',
    'listorder' => '0',
  ),
  765 => 
  array (
    'id' => '230500',
    'parentid' => '230000',
    'parentids' => '230000,230500',
    'level' => '2',
    'name' => '双鸭山市',
    'letter' => 's',
    'listorder' => '0',
  ),
  766 => 
  array (
    'id' => '230501',
    'parentid' => '230500',
    'parentids' => '230000,230500,230501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  767 => 
  array (
    'id' => '230502',
    'parentid' => '230500',
    'parentids' => '230000,230500,230502',
    'level' => '3',
    'name' => '尖山区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  768 => 
  array (
    'id' => '230503',
    'parentid' => '230500',
    'parentids' => '230000,230500,230503',
    'level' => '3',
    'name' => '岭东区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  769 => 
  array (
    'id' => '230505',
    'parentid' => '230500',
    'parentids' => '230000,230500,230505',
    'level' => '3',
    'name' => '四方台区',
    'letter' => 's',
    'listorder' => '0',
  ),
  770 => 
  array (
    'id' => '230506',
    'parentid' => '230500',
    'parentids' => '230000,230500,230506',
    'level' => '3',
    'name' => '宝山区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  771 => 
  array (
    'id' => '230521',
    'parentid' => '230500',
    'parentids' => '230000,230500,230521',
    'level' => '3',
    'name' => '集贤县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  772 => 
  array (
    'id' => '230522',
    'parentid' => '230500',
    'parentids' => '230000,230500,230522',
    'level' => '3',
    'name' => '友谊县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  773 => 
  array (
    'id' => '230523',
    'parentid' => '230500',
    'parentids' => '230000,230500,230523',
    'level' => '3',
    'name' => '宝清县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  774 => 
  array (
    'id' => '230524',
    'parentid' => '230500',
    'parentids' => '230000,230500,230524',
    'level' => '3',
    'name' => '饶河县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  775 => 
  array (
    'id' => '230600',
    'parentid' => '230000',
    'parentids' => '230000,230600',
    'level' => '2',
    'name' => '大庆市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  776 => 
  array (
    'id' => '230601',
    'parentid' => '230600',
    'parentids' => '230000,230600,230601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  777 => 
  array (
    'id' => '230602',
    'parentid' => '230600',
    'parentids' => '230000,230600,230602',
    'level' => '3',
    'name' => '萨尔图区',
    'letter' => 's',
    'listorder' => '0',
  ),
  778 => 
  array (
    'id' => '230603',
    'parentid' => '230600',
    'parentids' => '230000,230600,230603',
    'level' => '3',
    'name' => '龙凤区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  779 => 
  array (
    'id' => '230604',
    'parentid' => '230600',
    'parentids' => '230000,230600,230604',
    'level' => '3',
    'name' => '让胡路区',
    'letter' => 'r',
    'listorder' => '0',
  ),
  780 => 
  array (
    'id' => '230605',
    'parentid' => '230600',
    'parentids' => '230000,230600,230605',
    'level' => '3',
    'name' => '红岗区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  781 => 
  array (
    'id' => '230606',
    'parentid' => '230600',
    'parentids' => '230000,230600,230606',
    'level' => '3',
    'name' => '大同区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  782 => 
  array (
    'id' => '230621',
    'parentid' => '230600',
    'parentids' => '230000,230600,230621',
    'level' => '3',
    'name' => '肇州县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  783 => 
  array (
    'id' => '230622',
    'parentid' => '230600',
    'parentids' => '230000,230600,230622',
    'level' => '3',
    'name' => '肇源县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  784 => 
  array (
    'id' => '230623',
    'parentid' => '230600',
    'parentids' => '230000,230600,230623',
    'level' => '3',
    'name' => '林甸县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  785 => 
  array (
    'id' => '230624',
    'parentid' => '230600',
    'parentids' => '230000,230600,230624',
    'level' => '3',
    'name' => '杜尔伯特蒙古族自治县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  786 => 
  array (
    'id' => '230700',
    'parentid' => '230000',
    'parentids' => '230000,230700',
    'level' => '2',
    'name' => '伊春市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  787 => 
  array (
    'id' => '230701',
    'parentid' => '230700',
    'parentids' => '230000,230700,230701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  788 => 
  array (
    'id' => '230702',
    'parentid' => '230700',
    'parentids' => '230000,230700,230702',
    'level' => '3',
    'name' => '伊春区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  789 => 
  array (
    'id' => '230703',
    'parentid' => '230700',
    'parentids' => '230000,230700,230703',
    'level' => '3',
    'name' => '南岔区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  790 => 
  array (
    'id' => '230704',
    'parentid' => '230700',
    'parentids' => '230000,230700,230704',
    'level' => '3',
    'name' => '友好区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  791 => 
  array (
    'id' => '230705',
    'parentid' => '230700',
    'parentids' => '230000,230700,230705',
    'level' => '3',
    'name' => '西林区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  792 => 
  array (
    'id' => '230706',
    'parentid' => '230700',
    'parentids' => '230000,230700,230706',
    'level' => '3',
    'name' => '翠峦区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  793 => 
  array (
    'id' => '230707',
    'parentid' => '230700',
    'parentids' => '230000,230700,230707',
    'level' => '3',
    'name' => '新青区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  794 => 
  array (
    'id' => '230708',
    'parentid' => '230700',
    'parentids' => '230000,230700,230708',
    'level' => '3',
    'name' => '美溪区',
    'letter' => 'm',
    'listorder' => '0',
  ),
  795 => 
  array (
    'id' => '230709',
    'parentid' => '230700',
    'parentids' => '230000,230700,230709',
    'level' => '3',
    'name' => '金山屯区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  796 => 
  array (
    'id' => '230710',
    'parentid' => '230700',
    'parentids' => '230000,230700,230710',
    'level' => '3',
    'name' => '五营区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  797 => 
  array (
    'id' => '230711',
    'parentid' => '230700',
    'parentids' => '230000,230700,230711',
    'level' => '3',
    'name' => '乌马河区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  798 => 
  array (
    'id' => '230712',
    'parentid' => '230700',
    'parentids' => '230000,230700,230712',
    'level' => '3',
    'name' => '汤旺河区',
    'letter' => 't',
    'listorder' => '0',
  ),
  799 => 
  array (
    'id' => '230713',
    'parentid' => '230700',
    'parentids' => '230000,230700,230713',
    'level' => '3',
    'name' => '带岭区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  800 => 
  array (
    'id' => '230714',
    'parentid' => '230700',
    'parentids' => '230000,230700,230714',
    'level' => '3',
    'name' => '乌伊岭区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  801 => 
  array (
    'id' => '230715',
    'parentid' => '230700',
    'parentids' => '230000,230700,230715',
    'level' => '3',
    'name' => '红星区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  802 => 
  array (
    'id' => '230716',
    'parentid' => '230700',
    'parentids' => '230000,230700,230716',
    'level' => '3',
    'name' => '上甘岭区',
    'letter' => 's',
    'listorder' => '0',
  ),
  803 => 
  array (
    'id' => '230722',
    'parentid' => '230700',
    'parentids' => '230000,230700,230722',
    'level' => '3',
    'name' => '嘉荫县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  804 => 
  array (
    'id' => '230781',
    'parentid' => '230700',
    'parentids' => '230000,230700,230781',
    'level' => '3',
    'name' => '铁力市',
    'letter' => 't',
    'listorder' => '0',
  ),
  805 => 
  array (
    'id' => '230800',
    'parentid' => '230000',
    'parentids' => '230000,230800',
    'level' => '2',
    'name' => '佳木斯市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  806 => 
  array (
    'id' => '230801',
    'parentid' => '230800',
    'parentids' => '230000,230800,230801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  807 => 
  array (
    'id' => '230802',
    'parentid' => '230800',
    'parentids' => '230000,230800,230802',
    'level' => '3',
    'name' => '永红区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  808 => 
  array (
    'id' => '230803',
    'parentid' => '230800',
    'parentids' => '230000,230800,230803',
    'level' => '3',
    'name' => '向阳区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  809 => 
  array (
    'id' => '230804',
    'parentid' => '230800',
    'parentids' => '230000,230800,230804',
    'level' => '3',
    'name' => '前进区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  810 => 
  array (
    'id' => '230805',
    'parentid' => '230800',
    'parentids' => '230000,230800,230805',
    'level' => '3',
    'name' => '东风区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  811 => 
  array (
    'id' => '230811',
    'parentid' => '230800',
    'parentids' => '230000,230800,230811',
    'level' => '3',
    'name' => '郊　区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  812 => 
  array (
    'id' => '230822',
    'parentid' => '230800',
    'parentids' => '230000,230800,230822',
    'level' => '3',
    'name' => '桦南县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  813 => 
  array (
    'id' => '230826',
    'parentid' => '230800',
    'parentids' => '230000,230800,230826',
    'level' => '3',
    'name' => '桦川县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  814 => 
  array (
    'id' => '230828',
    'parentid' => '230800',
    'parentids' => '230000,230800,230828',
    'level' => '3',
    'name' => '汤原县',
    'letter' => 't',
    'listorder' => '0',
  ),
  815 => 
  array (
    'id' => '230833',
    'parentid' => '230800',
    'parentids' => '230000,230800,230833',
    'level' => '3',
    'name' => '抚远县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  816 => 
  array (
    'id' => '230881',
    'parentid' => '230800',
    'parentids' => '230000,230800,230881',
    'level' => '3',
    'name' => '同江市',
    'letter' => 't',
    'listorder' => '0',
  ),
  817 => 
  array (
    'id' => '230882',
    'parentid' => '230800',
    'parentids' => '230000,230800,230882',
    'level' => '3',
    'name' => '富锦市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  818 => 
  array (
    'id' => '230900',
    'parentid' => '230000',
    'parentids' => '230000,230900',
    'level' => '2',
    'name' => '七台河市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  819 => 
  array (
    'id' => '230901',
    'parentid' => '230900',
    'parentids' => '230000,230900,230901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  820 => 
  array (
    'id' => '230902',
    'parentid' => '230900',
    'parentids' => '230000,230900,230902',
    'level' => '3',
    'name' => '新兴区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  821 => 
  array (
    'id' => '230903',
    'parentid' => '230900',
    'parentids' => '230000,230900,230903',
    'level' => '3',
    'name' => '桃山区',
    'letter' => 't',
    'listorder' => '0',
  ),
  822 => 
  array (
    'id' => '230904',
    'parentid' => '230900',
    'parentids' => '230000,230900,230904',
    'level' => '3',
    'name' => '茄子河区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  823 => 
  array (
    'id' => '230921',
    'parentid' => '230900',
    'parentids' => '230000,230900,230921',
    'level' => '3',
    'name' => '勃利县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  824 => 
  array (
    'id' => '231000',
    'parentid' => '230000',
    'parentids' => '230000,231000',
    'level' => '2',
    'name' => '牡丹江市',
    'letter' => 'm',
    'listorder' => '0',
  ),
  825 => 
  array (
    'id' => '231001',
    'parentid' => '231000',
    'parentids' => '230000,231000,231001',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  826 => 
  array (
    'id' => '231002',
    'parentid' => '231000',
    'parentids' => '230000,231000,231002',
    'level' => '3',
    'name' => '东安区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  827 => 
  array (
    'id' => '231003',
    'parentid' => '231000',
    'parentids' => '230000,231000,231003',
    'level' => '3',
    'name' => '阳明区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  828 => 
  array (
    'id' => '231004',
    'parentid' => '231000',
    'parentids' => '230000,231000,231004',
    'level' => '3',
    'name' => '爱民区',
    'letter' => 'a',
    'listorder' => '0',
  ),
  829 => 
  array (
    'id' => '231005',
    'parentid' => '231000',
    'parentids' => '230000,231000,231005',
    'level' => '3',
    'name' => '西安区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  830 => 
  array (
    'id' => '231024',
    'parentid' => '231000',
    'parentids' => '230000,231000,231024',
    'level' => '3',
    'name' => '东宁县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  831 => 
  array (
    'id' => '231025',
    'parentid' => '231000',
    'parentids' => '230000,231000,231025',
    'level' => '3',
    'name' => '林口县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  832 => 
  array (
    'id' => '231081',
    'parentid' => '231000',
    'parentids' => '230000,231000,231081',
    'level' => '3',
    'name' => '绥芬河市',
    'letter' => 's',
    'listorder' => '0',
  ),
  833 => 
  array (
    'id' => '231083',
    'parentid' => '231000',
    'parentids' => '230000,231000,231083',
    'level' => '3',
    'name' => '海林市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  834 => 
  array (
    'id' => '231084',
    'parentid' => '231000',
    'parentids' => '230000,231000,231084',
    'level' => '3',
    'name' => '宁安市',
    'letter' => 'n',
    'listorder' => '0',
  ),
  835 => 
  array (
    'id' => '231085',
    'parentid' => '231000',
    'parentids' => '230000,231000,231085',
    'level' => '3',
    'name' => '穆棱市',
    'letter' => 'm',
    'listorder' => '0',
  ),
  836 => 
  array (
    'id' => '231100',
    'parentid' => '230000',
    'parentids' => '230000,231100',
    'level' => '2',
    'name' => '黑河市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  837 => 
  array (
    'id' => '231101',
    'parentid' => '231100',
    'parentids' => '230000,231100,231101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  838 => 
  array (
    'id' => '231102',
    'parentid' => '231100',
    'parentids' => '230000,231100,231102',
    'level' => '3',
    'name' => '爱辉区',
    'letter' => 'a',
    'listorder' => '0',
  ),
  839 => 
  array (
    'id' => '231121',
    'parentid' => '231100',
    'parentids' => '230000,231100,231121',
    'level' => '3',
    'name' => '嫩江县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  840 => 
  array (
    'id' => '231123',
    'parentid' => '231100',
    'parentids' => '230000,231100,231123',
    'level' => '3',
    'name' => '逊克县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  841 => 
  array (
    'id' => '231124',
    'parentid' => '231100',
    'parentids' => '230000,231100,231124',
    'level' => '3',
    'name' => '孙吴县',
    'letter' => 's',
    'listorder' => '0',
  ),
  842 => 
  array (
    'id' => '231181',
    'parentid' => '231100',
    'parentids' => '230000,231100,231181',
    'level' => '3',
    'name' => '北安市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  843 => 
  array (
    'id' => '231182',
    'parentid' => '231100',
    'parentids' => '230000,231100,231182',
    'level' => '3',
    'name' => '五大连池市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  844 => 
  array (
    'id' => '231200',
    'parentid' => '230000',
    'parentids' => '230000,231200',
    'level' => '2',
    'name' => '绥化市',
    'letter' => 's',
    'listorder' => '0',
  ),
  845 => 
  array (
    'id' => '231201',
    'parentid' => '231200',
    'parentids' => '230000,231200,231201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  846 => 
  array (
    'id' => '231202',
    'parentid' => '231200',
    'parentids' => '230000,231200,231202',
    'level' => '3',
    'name' => '北林区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  847 => 
  array (
    'id' => '231221',
    'parentid' => '231200',
    'parentids' => '230000,231200,231221',
    'level' => '3',
    'name' => '望奎县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  848 => 
  array (
    'id' => '231222',
    'parentid' => '231200',
    'parentids' => '230000,231200,231222',
    'level' => '3',
    'name' => '兰西县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  849 => 
  array (
    'id' => '231223',
    'parentid' => '231200',
    'parentids' => '230000,231200,231223',
    'level' => '3',
    'name' => '青冈县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  850 => 
  array (
    'id' => '231224',
    'parentid' => '231200',
    'parentids' => '230000,231200,231224',
    'level' => '3',
    'name' => '庆安县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  851 => 
  array (
    'id' => '231225',
    'parentid' => '231200',
    'parentids' => '230000,231200,231225',
    'level' => '3',
    'name' => '明水县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  852 => 
  array (
    'id' => '231226',
    'parentid' => '231200',
    'parentids' => '230000,231200,231226',
    'level' => '3',
    'name' => '绥棱县',
    'letter' => 's',
    'listorder' => '0',
  ),
  853 => 
  array (
    'id' => '231281',
    'parentid' => '231200',
    'parentids' => '230000,231200,231281',
    'level' => '3',
    'name' => '安达市',
    'letter' => 'a',
    'listorder' => '0',
  ),
  854 => 
  array (
    'id' => '231282',
    'parentid' => '231200',
    'parentids' => '230000,231200,231282',
    'level' => '3',
    'name' => '肇东市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  855 => 
  array (
    'id' => '231283',
    'parentid' => '231200',
    'parentids' => '230000,231200,231283',
    'level' => '3',
    'name' => '海伦市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  856 => 
  array (
    'id' => '232700',
    'parentid' => '230000',
    'parentids' => '230000,232700',
    'level' => '2',
    'name' => '大兴安岭地区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  857 => 
  array (
    'id' => '232721',
    'parentid' => '232700',
    'parentids' => '230000,232700,232721',
    'level' => '3',
    'name' => '呼玛县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  858 => 
  array (
    'id' => '232722',
    'parentid' => '232700',
    'parentids' => '230000,232700,232722',
    'level' => '3',
    'name' => '塔河县',
    'letter' => 't',
    'listorder' => '0',
  ),
  859 => 
  array (
    'id' => '232723',
    'parentid' => '232700',
    'parentids' => '230000,232700,232723',
    'level' => '3',
    'name' => '漠河县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  860 => 
  array (
    'id' => '310000',
    'parentid' => '0',
    'parentids' => '310000',
    'level' => '1',
    'name' => '上海市',
    'letter' => 's',
    'listorder' => '0',
  ),
  861 => 
  array (
    'id' => '310100',
    'parentid' => '310000',
    'parentids' => '310000,310100',
    'level' => '2',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  862 => 
  array (
    'id' => '310101',
    'parentid' => '310100',
    'parentids' => '310000,310100,310101',
    'level' => '3',
    'name' => '黄浦区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  863 => 
  array (
    'id' => '310103',
    'parentid' => '310100',
    'parentids' => '310000,310100,310103',
    'level' => '3',
    'name' => '卢湾区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  864 => 
  array (
    'id' => '310104',
    'parentid' => '310100',
    'parentids' => '310000,310100,310104',
    'level' => '3',
    'name' => '徐汇区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  865 => 
  array (
    'id' => '310105',
    'parentid' => '310100',
    'parentids' => '310000,310100,310105',
    'level' => '3',
    'name' => '长宁区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  866 => 
  array (
    'id' => '310106',
    'parentid' => '310100',
    'parentids' => '310000,310100,310106',
    'level' => '3',
    'name' => '静安区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  867 => 
  array (
    'id' => '310107',
    'parentid' => '310100',
    'parentids' => '310000,310100,310107',
    'level' => '3',
    'name' => '普陀区',
    'letter' => 'p',
    'listorder' => '0',
  ),
  868 => 
  array (
    'id' => '310108',
    'parentid' => '310100',
    'parentids' => '310000,310100,310108',
    'level' => '3',
    'name' => '闸北区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  869 => 
  array (
    'id' => '310109',
    'parentid' => '310100',
    'parentids' => '310000,310100,310109',
    'level' => '3',
    'name' => '虹口区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  870 => 
  array (
    'id' => '310110',
    'parentid' => '310100',
    'parentids' => '310000,310100,310110',
    'level' => '3',
    'name' => '杨浦区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  871 => 
  array (
    'id' => '310112',
    'parentid' => '310100',
    'parentids' => '310000,310100,310112',
    'level' => '3',
    'name' => '闵行区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  872 => 
  array (
    'id' => '310113',
    'parentid' => '310100',
    'parentids' => '310000,310100,310113',
    'level' => '3',
    'name' => '宝山区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  873 => 
  array (
    'id' => '310114',
    'parentid' => '310100',
    'parentids' => '310000,310100,310114',
    'level' => '3',
    'name' => '嘉定区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  874 => 
  array (
    'id' => '310115',
    'parentid' => '310100',
    'parentids' => '310000,310100,310115',
    'level' => '3',
    'name' => '浦东新区',
    'letter' => 'p',
    'listorder' => '0',
  ),
  875 => 
  array (
    'id' => '310116',
    'parentid' => '310100',
    'parentids' => '310000,310100,310116',
    'level' => '3',
    'name' => '金山区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  876 => 
  array (
    'id' => '310117',
    'parentid' => '310100',
    'parentids' => '310000,310100,310117',
    'level' => '3',
    'name' => '松江区',
    'letter' => 's',
    'listorder' => '0',
  ),
  877 => 
  array (
    'id' => '310118',
    'parentid' => '310100',
    'parentids' => '310000,310100,310118',
    'level' => '3',
    'name' => '青浦区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  878 => 
  array (
    'id' => '310119',
    'parentid' => '310100',
    'parentids' => '310000,310100,310119',
    'level' => '3',
    'name' => '南汇区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  879 => 
  array (
    'id' => '310120',
    'parentid' => '310100',
    'parentids' => '310000,310100,310120',
    'level' => '3',
    'name' => '奉贤区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  880 => 
  array (
    'id' => '310200',
    'parentid' => '310000',
    'parentids' => '310000,310200',
    'level' => '2',
    'name' => '县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  881 => 
  array (
    'id' => '310230',
    'parentid' => '310200',
    'parentids' => '310000,310200,310230',
    'level' => '3',
    'name' => '崇明县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  882 => 
  array (
    'id' => '320000',
    'parentid' => '0',
    'parentids' => '320000',
    'level' => '1',
    'name' => '江苏省',
    'letter' => 'j',
    'listorder' => '0',
  ),
  883 => 
  array (
    'id' => '320100',
    'parentid' => '320000',
    'parentids' => '320000,320100',
    'level' => '2',
    'name' => '南京市',
    'letter' => 'n',
    'listorder' => '0',
  ),
  884 => 
  array (
    'id' => '320101',
    'parentid' => '320100',
    'parentids' => '320000,320100,320101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  885 => 
  array (
    'id' => '320102',
    'parentid' => '320100',
    'parentids' => '320000,320100,320102',
    'level' => '3',
    'name' => '玄武区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  886 => 
  array (
    'id' => '320103',
    'parentid' => '320100',
    'parentids' => '320000,320100,320103',
    'level' => '3',
    'name' => '白下区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  887 => 
  array (
    'id' => '320104',
    'parentid' => '320100',
    'parentids' => '320000,320100,320104',
    'level' => '3',
    'name' => '秦淮区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  888 => 
  array (
    'id' => '320105',
    'parentid' => '320100',
    'parentids' => '320000,320100,320105',
    'level' => '3',
    'name' => '建邺区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  889 => 
  array (
    'id' => '320106',
    'parentid' => '320100',
    'parentids' => '320000,320100,320106',
    'level' => '3',
    'name' => '鼓楼区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  890 => 
  array (
    'id' => '320107',
    'parentid' => '320100',
    'parentids' => '320000,320100,320107',
    'level' => '3',
    'name' => '下关区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  891 => 
  array (
    'id' => '320111',
    'parentid' => '320100',
    'parentids' => '320000,320100,320111',
    'level' => '3',
    'name' => '浦口区',
    'letter' => 'p',
    'listorder' => '0',
  ),
  892 => 
  array (
    'id' => '320113',
    'parentid' => '320100',
    'parentids' => '320000,320100,320113',
    'level' => '3',
    'name' => '栖霞区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  893 => 
  array (
    'id' => '320114',
    'parentid' => '320100',
    'parentids' => '320000,320100,320114',
    'level' => '3',
    'name' => '雨花台区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  894 => 
  array (
    'id' => '320115',
    'parentid' => '320100',
    'parentids' => '320000,320100,320115',
    'level' => '3',
    'name' => '江宁区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  895 => 
  array (
    'id' => '320116',
    'parentid' => '320100',
    'parentids' => '320000,320100,320116',
    'level' => '3',
    'name' => '六合区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  896 => 
  array (
    'id' => '320124',
    'parentid' => '320100',
    'parentids' => '320000,320100,320124',
    'level' => '3',
    'name' => '溧水县',
    'letter' => 's',
    'listorder' => '0',
  ),
  897 => 
  array (
    'id' => '320125',
    'parentid' => '320100',
    'parentids' => '320000,320100,320125',
    'level' => '3',
    'name' => '高淳县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  898 => 
  array (
    'id' => '320200',
    'parentid' => '320000',
    'parentids' => '320000,320200',
    'level' => '2',
    'name' => '无锡市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  899 => 
  array (
    'id' => '320201',
    'parentid' => '320200',
    'parentids' => '320000,320200,320201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  900 => 
  array (
    'id' => '320202',
    'parentid' => '320200',
    'parentids' => '320000,320200,320202',
    'level' => '3',
    'name' => '崇安区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  901 => 
  array (
    'id' => '320203',
    'parentid' => '320200',
    'parentids' => '320000,320200,320203',
    'level' => '3',
    'name' => '南长区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  902 => 
  array (
    'id' => '320204',
    'parentid' => '320200',
    'parentids' => '320000,320200,320204',
    'level' => '3',
    'name' => '北塘区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  903 => 
  array (
    'id' => '320205',
    'parentid' => '320200',
    'parentids' => '320000,320200,320205',
    'level' => '3',
    'name' => '锡山区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  904 => 
  array (
    'id' => '320206',
    'parentid' => '320200',
    'parentids' => '320000,320200,320206',
    'level' => '3',
    'name' => '惠山区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  905 => 
  array (
    'id' => '320211',
    'parentid' => '320200',
    'parentids' => '320000,320200,320211',
    'level' => '3',
    'name' => '滨湖区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  906 => 
  array (
    'id' => '320281',
    'parentid' => '320200',
    'parentids' => '320000,320200,320281',
    'level' => '3',
    'name' => '江阴市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  907 => 
  array (
    'id' => '320282',
    'parentid' => '320200',
    'parentids' => '320000,320200,320282',
    'level' => '3',
    'name' => '宜兴市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  908 => 
  array (
    'id' => '320300',
    'parentid' => '320000',
    'parentids' => '320000,320300',
    'level' => '2',
    'name' => '徐州市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  909 => 
  array (
    'id' => '320301',
    'parentid' => '320300',
    'parentids' => '320000,320300,320301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  910 => 
  array (
    'id' => '320302',
    'parentid' => '320300',
    'parentids' => '320000,320300,320302',
    'level' => '3',
    'name' => '鼓楼区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  911 => 
  array (
    'id' => '320303',
    'parentid' => '320300',
    'parentids' => '320000,320300,320303',
    'level' => '3',
    'name' => '云龙区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  912 => 
  array (
    'id' => '320304',
    'parentid' => '320300',
    'parentids' => '320000,320300,320304',
    'level' => '3',
    'name' => '九里区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  913 => 
  array (
    'id' => '320305',
    'parentid' => '320300',
    'parentids' => '320000,320300,320305',
    'level' => '3',
    'name' => '贾汪区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  914 => 
  array (
    'id' => '320311',
    'parentid' => '320300',
    'parentids' => '320000,320300,320311',
    'level' => '3',
    'name' => '泉山区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  915 => 
  array (
    'id' => '320321',
    'parentid' => '320300',
    'parentids' => '320000,320300,320321',
    'level' => '3',
    'name' => '丰　县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  916 => 
  array (
    'id' => '320322',
    'parentid' => '320300',
    'parentids' => '320000,320300,320322',
    'level' => '3',
    'name' => '沛　县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  917 => 
  array (
    'id' => '320323',
    'parentid' => '320300',
    'parentids' => '320000,320300,320323',
    'level' => '3',
    'name' => '铜山县',
    'letter' => 't',
    'listorder' => '0',
  ),
  918 => 
  array (
    'id' => '320324',
    'parentid' => '320300',
    'parentids' => '320000,320300,320324',
    'level' => '3',
    'name' => '睢宁县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  919 => 
  array (
    'id' => '320381',
    'parentid' => '320300',
    'parentids' => '320000,320300,320381',
    'level' => '3',
    'name' => '新沂市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  920 => 
  array (
    'id' => '320382',
    'parentid' => '320300',
    'parentids' => '320000,320300,320382',
    'level' => '3',
    'name' => '邳州市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  921 => 
  array (
    'id' => '320400',
    'parentid' => '320000',
    'parentids' => '320000,320400',
    'level' => '2',
    'name' => '常州市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  922 => 
  array (
    'id' => '320401',
    'parentid' => '320400',
    'parentids' => '320000,320400,320401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  923 => 
  array (
    'id' => '320402',
    'parentid' => '320400',
    'parentids' => '320000,320400,320402',
    'level' => '3',
    'name' => '天宁区',
    'letter' => 't',
    'listorder' => '0',
  ),
  924 => 
  array (
    'id' => '320404',
    'parentid' => '320400',
    'parentids' => '320000,320400,320404',
    'level' => '3',
    'name' => '钟楼区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  925 => 
  array (
    'id' => '320405',
    'parentid' => '320400',
    'parentids' => '320000,320400,320405',
    'level' => '3',
    'name' => '戚墅堰区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  926 => 
  array (
    'id' => '320411',
    'parentid' => '320400',
    'parentids' => '320000,320400,320411',
    'level' => '3',
    'name' => '新北区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  927 => 
  array (
    'id' => '320412',
    'parentid' => '320400',
    'parentids' => '320000,320400,320412',
    'level' => '3',
    'name' => '武进区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  928 => 
  array (
    'id' => '320481',
    'parentid' => '320400',
    'parentids' => '320000,320400,320481',
    'level' => '3',
    'name' => '溧阳市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  929 => 
  array (
    'id' => '320482',
    'parentid' => '320400',
    'parentids' => '320000,320400,320482',
    'level' => '3',
    'name' => '金坛市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  930 => 
  array (
    'id' => '320500',
    'parentid' => '320000',
    'parentids' => '320000,320500',
    'level' => '2',
    'name' => '苏州市',
    'letter' => 's',
    'listorder' => '0',
  ),
  931 => 
  array (
    'id' => '320501',
    'parentid' => '320500',
    'parentids' => '320000,320500,320501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  932 => 
  array (
    'id' => '320502',
    'parentid' => '320500',
    'parentids' => '320000,320500,320502',
    'level' => '3',
    'name' => '沧浪区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  933 => 
  array (
    'id' => '320503',
    'parentid' => '320500',
    'parentids' => '320000,320500,320503',
    'level' => '3',
    'name' => '平江区',
    'letter' => 'p',
    'listorder' => '0',
  ),
  934 => 
  array (
    'id' => '320504',
    'parentid' => '320500',
    'parentids' => '320000,320500,320504',
    'level' => '3',
    'name' => '金阊区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  935 => 
  array (
    'id' => '320505',
    'parentid' => '320500',
    'parentids' => '320000,320500,320505',
    'level' => '3',
    'name' => '虎丘区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  936 => 
  array (
    'id' => '320506',
    'parentid' => '320500',
    'parentids' => '320000,320500,320506',
    'level' => '3',
    'name' => '吴中区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  937 => 
  array (
    'id' => '320507',
    'parentid' => '320500',
    'parentids' => '320000,320500,320507',
    'level' => '3',
    'name' => '相城区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  938 => 
  array (
    'id' => '320581',
    'parentid' => '320500',
    'parentids' => '320000,320500,320581',
    'level' => '3',
    'name' => '常熟市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  939 => 
  array (
    'id' => '320582',
    'parentid' => '320500',
    'parentids' => '320000,320500,320582',
    'level' => '3',
    'name' => '张家港市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  940 => 
  array (
    'id' => '320583',
    'parentid' => '320500',
    'parentids' => '320000,320500,320583',
    'level' => '3',
    'name' => '昆山市',
    'letter' => 'k',
    'listorder' => '0',
  ),
  941 => 
  array (
    'id' => '320584',
    'parentid' => '320500',
    'parentids' => '320000,320500,320584',
    'level' => '3',
    'name' => '吴江市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  942 => 
  array (
    'id' => '320585',
    'parentid' => '320500',
    'parentids' => '320000,320500,320585',
    'level' => '3',
    'name' => '太仓市',
    'letter' => 't',
    'listorder' => '0',
  ),
  943 => 
  array (
    'id' => '320600',
    'parentid' => '320000',
    'parentids' => '320000,320600',
    'level' => '2',
    'name' => '南通市',
    'letter' => 'n',
    'listorder' => '0',
  ),
  944 => 
  array (
    'id' => '320601',
    'parentid' => '320600',
    'parentids' => '320000,320600,320601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  945 => 
  array (
    'id' => '320602',
    'parentid' => '320600',
    'parentids' => '320000,320600,320602',
    'level' => '3',
    'name' => '崇川区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  946 => 
  array (
    'id' => '320611',
    'parentid' => '320600',
    'parentids' => '320000,320600,320611',
    'level' => '3',
    'name' => '港闸区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  947 => 
  array (
    'id' => '320621',
    'parentid' => '320600',
    'parentids' => '320000,320600,320621',
    'level' => '3',
    'name' => '海安县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  948 => 
  array (
    'id' => '320623',
    'parentid' => '320600',
    'parentids' => '320000,320600,320623',
    'level' => '3',
    'name' => '如东县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  949 => 
  array (
    'id' => '320681',
    'parentid' => '320600',
    'parentids' => '320000,320600,320681',
    'level' => '3',
    'name' => '启东市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  950 => 
  array (
    'id' => '320682',
    'parentid' => '320600',
    'parentids' => '320000,320600,320682',
    'level' => '3',
    'name' => '如皋市',
    'letter' => 'r',
    'listorder' => '0',
  ),
  951 => 
  array (
    'id' => '320683',
    'parentid' => '320600',
    'parentids' => '320000,320600,320683',
    'level' => '3',
    'name' => '通州市',
    'letter' => 't',
    'listorder' => '0',
  ),
  952 => 
  array (
    'id' => '320684',
    'parentid' => '320600',
    'parentids' => '320000,320600,320684',
    'level' => '3',
    'name' => '海门市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  953 => 
  array (
    'id' => '320700',
    'parentid' => '320000',
    'parentids' => '320000,320700',
    'level' => '2',
    'name' => '连云港市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  954 => 
  array (
    'id' => '320701',
    'parentid' => '320700',
    'parentids' => '320000,320700,320701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  955 => 
  array (
    'id' => '320703',
    'parentid' => '320700',
    'parentids' => '320000,320700,320703',
    'level' => '3',
    'name' => '连云区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  956 => 
  array (
    'id' => '320705',
    'parentid' => '320700',
    'parentids' => '320000,320700,320705',
    'level' => '3',
    'name' => '新浦区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  957 => 
  array (
    'id' => '320706',
    'parentid' => '320700',
    'parentids' => '320000,320700,320706',
    'level' => '3',
    'name' => '海州区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  958 => 
  array (
    'id' => '320721',
    'parentid' => '320700',
    'parentids' => '320000,320700,320721',
    'level' => '3',
    'name' => '赣榆县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  959 => 
  array (
    'id' => '320722',
    'parentid' => '320700',
    'parentids' => '320000,320700,320722',
    'level' => '3',
    'name' => '东海县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  960 => 
  array (
    'id' => '320723',
    'parentid' => '320700',
    'parentids' => '320000,320700,320723',
    'level' => '3',
    'name' => '灌云县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  961 => 
  array (
    'id' => '320724',
    'parentid' => '320700',
    'parentids' => '320000,320700,320724',
    'level' => '3',
    'name' => '灌南县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  962 => 
  array (
    'id' => '320800',
    'parentid' => '320000',
    'parentids' => '320000,320800',
    'level' => '2',
    'name' => '淮安市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  963 => 
  array (
    'id' => '320801',
    'parentid' => '320800',
    'parentids' => '320000,320800,320801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  964 => 
  array (
    'id' => '320802',
    'parentid' => '320800',
    'parentids' => '320000,320800,320802',
    'level' => '3',
    'name' => '清河区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  965 => 
  array (
    'id' => '320803',
    'parentid' => '320800',
    'parentids' => '320000,320800,320803',
    'level' => '3',
    'name' => '楚州区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  966 => 
  array (
    'id' => '320804',
    'parentid' => '320800',
    'parentids' => '320000,320800,320804',
    'level' => '3',
    'name' => '淮阴区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  967 => 
  array (
    'id' => '320811',
    'parentid' => '320800',
    'parentids' => '320000,320800,320811',
    'level' => '3',
    'name' => '清浦区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  968 => 
  array (
    'id' => '320826',
    'parentid' => '320800',
    'parentids' => '320000,320800,320826',
    'level' => '3',
    'name' => '涟水县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  969 => 
  array (
    'id' => '320829',
    'parentid' => '320800',
    'parentids' => '320000,320800,320829',
    'level' => '3',
    'name' => '洪泽县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  970 => 
  array (
    'id' => '320830',
    'parentid' => '320800',
    'parentids' => '320000,320800,320830',
    'level' => '3',
    'name' => '盱眙县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  971 => 
  array (
    'id' => '320831',
    'parentid' => '320800',
    'parentids' => '320000,320800,320831',
    'level' => '3',
    'name' => '金湖县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  972 => 
  array (
    'id' => '320900',
    'parentid' => '320000',
    'parentids' => '320000,320900',
    'level' => '2',
    'name' => '盐城市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  973 => 
  array (
    'id' => '320901',
    'parentid' => '320900',
    'parentids' => '320000,320900,320901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  974 => 
  array (
    'id' => '320902',
    'parentid' => '320900',
    'parentids' => '320000,320900,320902',
    'level' => '3',
    'name' => '亭湖区',
    'letter' => 't',
    'listorder' => '0',
  ),
  975 => 
  array (
    'id' => '320903',
    'parentid' => '320900',
    'parentids' => '320000,320900,320903',
    'level' => '3',
    'name' => '盐都区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  976 => 
  array (
    'id' => '320921',
    'parentid' => '320900',
    'parentids' => '320000,320900,320921',
    'level' => '3',
    'name' => '响水县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  977 => 
  array (
    'id' => '320922',
    'parentid' => '320900',
    'parentids' => '320000,320900,320922',
    'level' => '3',
    'name' => '滨海县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  978 => 
  array (
    'id' => '320923',
    'parentid' => '320900',
    'parentids' => '320000,320900,320923',
    'level' => '3',
    'name' => '阜宁县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  979 => 
  array (
    'id' => '320924',
    'parentid' => '320900',
    'parentids' => '320000,320900,320924',
    'level' => '3',
    'name' => '射阳县',
    'letter' => 's',
    'listorder' => '0',
  ),
  980 => 
  array (
    'id' => '320925',
    'parentid' => '320900',
    'parentids' => '320000,320900,320925',
    'level' => '3',
    'name' => '建湖县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  981 => 
  array (
    'id' => '320981',
    'parentid' => '320900',
    'parentids' => '320000,320900,320981',
    'level' => '3',
    'name' => '东台市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  982 => 
  array (
    'id' => '320982',
    'parentid' => '320900',
    'parentids' => '320000,320900,320982',
    'level' => '3',
    'name' => '大丰市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  983 => 
  array (
    'id' => '321000',
    'parentid' => '320000',
    'parentids' => '320000,321000',
    'level' => '2',
    'name' => '扬州市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  984 => 
  array (
    'id' => '321001',
    'parentid' => '321000',
    'parentids' => '320000,321000,321001',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  985 => 
  array (
    'id' => '321002',
    'parentid' => '321000',
    'parentids' => '320000,321000,321002',
    'level' => '3',
    'name' => '广陵区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  986 => 
  array (
    'id' => '321003',
    'parentid' => '321000',
    'parentids' => '320000,321000,321003',
    'level' => '3',
    'name' => '邗江区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  987 => 
  array (
    'id' => '321011',
    'parentid' => '321000',
    'parentids' => '320000,321000,321011',
    'level' => '3',
    'name' => '郊　区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  988 => 
  array (
    'id' => '321023',
    'parentid' => '321000',
    'parentids' => '320000,321000,321023',
    'level' => '3',
    'name' => '宝应县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  989 => 
  array (
    'id' => '321081',
    'parentid' => '321000',
    'parentids' => '320000,321000,321081',
    'level' => '3',
    'name' => '仪征市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  990 => 
  array (
    'id' => '321084',
    'parentid' => '321000',
    'parentids' => '320000,321000,321084',
    'level' => '3',
    'name' => '高邮市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  991 => 
  array (
    'id' => '321088',
    'parentid' => '321000',
    'parentids' => '320000,321000,321088',
    'level' => '3',
    'name' => '江都市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  992 => 
  array (
    'id' => '321100',
    'parentid' => '320000',
    'parentids' => '320000,321100',
    'level' => '2',
    'name' => '镇江市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  993 => 
  array (
    'id' => '321101',
    'parentid' => '321100',
    'parentids' => '320000,321100,321101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  994 => 
  array (
    'id' => '321102',
    'parentid' => '321100',
    'parentids' => '320000,321100,321102',
    'level' => '3',
    'name' => '京口区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  995 => 
  array (
    'id' => '321111',
    'parentid' => '321100',
    'parentids' => '320000,321100,321111',
    'level' => '3',
    'name' => '润州区',
    'letter' => 'r',
    'listorder' => '0',
  ),
  996 => 
  array (
    'id' => '321112',
    'parentid' => '321100',
    'parentids' => '320000,321100,321112',
    'level' => '3',
    'name' => '丹徒区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  997 => 
  array (
    'id' => '321181',
    'parentid' => '321100',
    'parentids' => '320000,321100,321181',
    'level' => '3',
    'name' => '丹阳市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  998 => 
  array (
    'id' => '321182',
    'parentid' => '321100',
    'parentids' => '320000,321100,321182',
    'level' => '3',
    'name' => '扬中市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  999 => 
  array (
    'id' => '321183',
    'parentid' => '321100',
    'parentids' => '320000,321100,321183',
    'level' => '3',
    'name' => '句容市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1000 => 
  array (
    'id' => '321200',
    'parentid' => '320000',
    'parentids' => '320000,321200',
    'level' => '2',
    'name' => '泰州市',
    'letter' => 't',
    'listorder' => '0',
  ),
  1001 => 
  array (
    'id' => '321201',
    'parentid' => '321200',
    'parentids' => '320000,321200,321201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1002 => 
  array (
    'id' => '321202',
    'parentid' => '321200',
    'parentids' => '320000,321200,321202',
    'level' => '3',
    'name' => '海陵区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1003 => 
  array (
    'id' => '321203',
    'parentid' => '321200',
    'parentids' => '320000,321200,321203',
    'level' => '3',
    'name' => '高港区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1004 => 
  array (
    'id' => '321281',
    'parentid' => '321200',
    'parentids' => '320000,321200,321281',
    'level' => '3',
    'name' => '兴化市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1005 => 
  array (
    'id' => '321282',
    'parentid' => '321200',
    'parentids' => '320000,321200,321282',
    'level' => '3',
    'name' => '靖江市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1006 => 
  array (
    'id' => '321283',
    'parentid' => '321200',
    'parentids' => '320000,321200,321283',
    'level' => '3',
    'name' => '泰兴市',
    'letter' => 't',
    'listorder' => '0',
  ),
  1007 => 
  array (
    'id' => '321284',
    'parentid' => '321200',
    'parentids' => '320000,321200,321284',
    'level' => '3',
    'name' => '姜堰市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1008 => 
  array (
    'id' => '321300',
    'parentid' => '320000',
    'parentids' => '320000,321300',
    'level' => '2',
    'name' => '宿迁市',
    'letter' => 's',
    'listorder' => '0',
  ),
  1009 => 
  array (
    'id' => '321301',
    'parentid' => '321300',
    'parentids' => '320000,321300,321301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1010 => 
  array (
    'id' => '321302',
    'parentid' => '321300',
    'parentids' => '320000,321300,321302',
    'level' => '3',
    'name' => '宿城区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1011 => 
  array (
    'id' => '321311',
    'parentid' => '321300',
    'parentids' => '320000,321300,321311',
    'level' => '3',
    'name' => '宿豫区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1012 => 
  array (
    'id' => '321322',
    'parentid' => '321300',
    'parentids' => '320000,321300,321322',
    'level' => '3',
    'name' => '沭阳县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1013 => 
  array (
    'id' => '321323',
    'parentid' => '321300',
    'parentids' => '320000,321300,321323',
    'level' => '3',
    'name' => '泗阳县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1014 => 
  array (
    'id' => '321324',
    'parentid' => '321300',
    'parentids' => '320000,321300,321324',
    'level' => '3',
    'name' => '泗洪县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1015 => 
  array (
    'id' => '330000',
    'parentid' => '0',
    'parentids' => '330000',
    'level' => '1',
    'name' => '浙江省',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1016 => 
  array (
    'id' => '330100',
    'parentid' => '330000',
    'parentids' => '330000,330100',
    'level' => '2',
    'name' => '杭州市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1017 => 
  array (
    'id' => '330101',
    'parentid' => '330100',
    'parentids' => '330000,330100,330101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1018 => 
  array (
    'id' => '330102',
    'parentid' => '330100',
    'parentids' => '330000,330100,330102',
    'level' => '3',
    'name' => '上城区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1019 => 
  array (
    'id' => '330103',
    'parentid' => '330100',
    'parentids' => '330000,330100,330103',
    'level' => '3',
    'name' => '下城区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1020 => 
  array (
    'id' => '330104',
    'parentid' => '330100',
    'parentids' => '330000,330100,330104',
    'level' => '3',
    'name' => '江干区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1021 => 
  array (
    'id' => '330105',
    'parentid' => '330100',
    'parentids' => '330000,330100,330105',
    'level' => '3',
    'name' => '拱墅区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1022 => 
  array (
    'id' => '330106',
    'parentid' => '330100',
    'parentids' => '330000,330100,330106',
    'level' => '3',
    'name' => '西湖区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1023 => 
  array (
    'id' => '330108',
    'parentid' => '330100',
    'parentids' => '330000,330100,330108',
    'level' => '3',
    'name' => '滨江区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  1024 => 
  array (
    'id' => '330109',
    'parentid' => '330100',
    'parentids' => '330000,330100,330109',
    'level' => '3',
    'name' => '萧山区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1025 => 
  array (
    'id' => '330110',
    'parentid' => '330100',
    'parentids' => '330000,330100,330110',
    'level' => '3',
    'name' => '余杭区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1026 => 
  array (
    'id' => '330122',
    'parentid' => '330100',
    'parentids' => '330000,330100,330122',
    'level' => '3',
    'name' => '桐庐县',
    'letter' => 't',
    'listorder' => '0',
  ),
  1027 => 
  array (
    'id' => '330127',
    'parentid' => '330100',
    'parentids' => '330000,330100,330127',
    'level' => '3',
    'name' => '淳安县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1028 => 
  array (
    'id' => '330182',
    'parentid' => '330100',
    'parentids' => '330000,330100,330182',
    'level' => '3',
    'name' => '建德市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1029 => 
  array (
    'id' => '330183',
    'parentid' => '330100',
    'parentids' => '330000,330100,330183',
    'level' => '3',
    'name' => '富阳市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1030 => 
  array (
    'id' => '330185',
    'parentid' => '330100',
    'parentids' => '330000,330100,330185',
    'level' => '3',
    'name' => '临安市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1031 => 
  array (
    'id' => '330200',
    'parentid' => '330000',
    'parentids' => '330000,330200',
    'level' => '2',
    'name' => '宁波市',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1032 => 
  array (
    'id' => '330201',
    'parentid' => '330200',
    'parentids' => '330000,330200,330201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1033 => 
  array (
    'id' => '330203',
    'parentid' => '330200',
    'parentids' => '330000,330200,330203',
    'level' => '3',
    'name' => '海曙区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1034 => 
  array (
    'id' => '330204',
    'parentid' => '330200',
    'parentids' => '330000,330200,330204',
    'level' => '3',
    'name' => '江东区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1035 => 
  array (
    'id' => '330205',
    'parentid' => '330200',
    'parentids' => '330000,330200,330205',
    'level' => '3',
    'name' => '江北区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1036 => 
  array (
    'id' => '330206',
    'parentid' => '330200',
    'parentids' => '330000,330200,330206',
    'level' => '3',
    'name' => '北仑区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  1037 => 
  array (
    'id' => '330211',
    'parentid' => '330200',
    'parentids' => '330000,330200,330211',
    'level' => '3',
    'name' => '镇海区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1038 => 
  array (
    'id' => '330212',
    'parentid' => '330200',
    'parentids' => '330000,330200,330212',
    'level' => '3',
    'name' => '鄞州区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1039 => 
  array (
    'id' => '330225',
    'parentid' => '330200',
    'parentids' => '330000,330200,330225',
    'level' => '3',
    'name' => '象山县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1040 => 
  array (
    'id' => '330226',
    'parentid' => '330200',
    'parentids' => '330000,330200,330226',
    'level' => '3',
    'name' => '宁海县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1041 => 
  array (
    'id' => '330281',
    'parentid' => '330200',
    'parentids' => '330000,330200,330281',
    'level' => '3',
    'name' => '余姚市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1042 => 
  array (
    'id' => '330282',
    'parentid' => '330200',
    'parentids' => '330000,330200,330282',
    'level' => '3',
    'name' => '慈溪市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1043 => 
  array (
    'id' => '330283',
    'parentid' => '330200',
    'parentids' => '330000,330200,330283',
    'level' => '3',
    'name' => '奉化市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1044 => 
  array (
    'id' => '330300',
    'parentid' => '330000',
    'parentids' => '330000,330300',
    'level' => '2',
    'name' => '温州市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1045 => 
  array (
    'id' => '330301',
    'parentid' => '330300',
    'parentids' => '330000,330300,330301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1046 => 
  array (
    'id' => '330302',
    'parentid' => '330300',
    'parentids' => '330000,330300,330302',
    'level' => '3',
    'name' => '鹿城区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1047 => 
  array (
    'id' => '330303',
    'parentid' => '330300',
    'parentids' => '330000,330300,330303',
    'level' => '3',
    'name' => '龙湾区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1048 => 
  array (
    'id' => '330304',
    'parentid' => '330300',
    'parentids' => '330000,330300,330304',
    'level' => '3',
    'name' => '瓯海区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1049 => 
  array (
    'id' => '330322',
    'parentid' => '330300',
    'parentids' => '330000,330300,330322',
    'level' => '3',
    'name' => '洞头县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1050 => 
  array (
    'id' => '330324',
    'parentid' => '330300',
    'parentids' => '330000,330300,330324',
    'level' => '3',
    'name' => '永嘉县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1051 => 
  array (
    'id' => '330326',
    'parentid' => '330300',
    'parentids' => '330000,330300,330326',
    'level' => '3',
    'name' => '平阳县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1052 => 
  array (
    'id' => '330327',
    'parentid' => '330300',
    'parentids' => '330000,330300,330327',
    'level' => '3',
    'name' => '苍南县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1053 => 
  array (
    'id' => '330328',
    'parentid' => '330300',
    'parentids' => '330000,330300,330328',
    'level' => '3',
    'name' => '文成县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1054 => 
  array (
    'id' => '330329',
    'parentid' => '330300',
    'parentids' => '330000,330300,330329',
    'level' => '3',
    'name' => '泰顺县',
    'letter' => 't',
    'listorder' => '0',
  ),
  1055 => 
  array (
    'id' => '330381',
    'parentid' => '330300',
    'parentids' => '330000,330300,330381',
    'level' => '3',
    'name' => '瑞安市',
    'letter' => 'r',
    'listorder' => '0',
  ),
  1056 => 
  array (
    'id' => '330382',
    'parentid' => '330300',
    'parentids' => '330000,330300,330382',
    'level' => '3',
    'name' => '乐清市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1057 => 
  array (
    'id' => '330400',
    'parentid' => '330000',
    'parentids' => '330000,330400',
    'level' => '2',
    'name' => '嘉兴市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1058 => 
  array (
    'id' => '330401',
    'parentid' => '330400',
    'parentids' => '330000,330400,330401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1059 => 
  array (
    'id' => '330402',
    'parentid' => '330400',
    'parentids' => '330000,330400,330402',
    'level' => '3',
    'name' => '秀城区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1060 => 
  array (
    'id' => '330411',
    'parentid' => '330400',
    'parentids' => '330000,330400,330411',
    'level' => '3',
    'name' => '秀洲区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1061 => 
  array (
    'id' => '330421',
    'parentid' => '330400',
    'parentids' => '330000,330400,330421',
    'level' => '3',
    'name' => '嘉善县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1062 => 
  array (
    'id' => '330424',
    'parentid' => '330400',
    'parentids' => '330000,330400,330424',
    'level' => '3',
    'name' => '海盐县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1063 => 
  array (
    'id' => '330481',
    'parentid' => '330400',
    'parentids' => '330000,330400,330481',
    'level' => '3',
    'name' => '海宁市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1064 => 
  array (
    'id' => '330482',
    'parentid' => '330400',
    'parentids' => '330000,330400,330482',
    'level' => '3',
    'name' => '平湖市',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1065 => 
  array (
    'id' => '330483',
    'parentid' => '330400',
    'parentids' => '330000,330400,330483',
    'level' => '3',
    'name' => '桐乡市',
    'letter' => 't',
    'listorder' => '0',
  ),
  1066 => 
  array (
    'id' => '330500',
    'parentid' => '330000',
    'parentids' => '330000,330500',
    'level' => '2',
    'name' => '湖州市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1067 => 
  array (
    'id' => '330501',
    'parentid' => '330500',
    'parentids' => '330000,330500,330501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1068 => 
  array (
    'id' => '330502',
    'parentid' => '330500',
    'parentids' => '330000,330500,330502',
    'level' => '3',
    'name' => '吴兴区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1069 => 
  array (
    'id' => '330503',
    'parentid' => '330500',
    'parentids' => '330000,330500,330503',
    'level' => '3',
    'name' => '南浔区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1070 => 
  array (
    'id' => '330521',
    'parentid' => '330500',
    'parentids' => '330000,330500,330521',
    'level' => '3',
    'name' => '德清县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1071 => 
  array (
    'id' => '330522',
    'parentid' => '330500',
    'parentids' => '330000,330500,330522',
    'level' => '3',
    'name' => '长兴县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1072 => 
  array (
    'id' => '330523',
    'parentid' => '330500',
    'parentids' => '330000,330500,330523',
    'level' => '3',
    'name' => '安吉县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  1073 => 
  array (
    'id' => '330600',
    'parentid' => '330000',
    'parentids' => '330000,330600',
    'level' => '2',
    'name' => '绍兴市',
    'letter' => 's',
    'listorder' => '0',
  ),
  1074 => 
  array (
    'id' => '330601',
    'parentid' => '330600',
    'parentids' => '330000,330600,330601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1075 => 
  array (
    'id' => '330602',
    'parentid' => '330600',
    'parentids' => '330000,330600,330602',
    'level' => '3',
    'name' => '越城区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1076 => 
  array (
    'id' => '330621',
    'parentid' => '330600',
    'parentids' => '330000,330600,330621',
    'level' => '3',
    'name' => '绍兴县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1077 => 
  array (
    'id' => '330624',
    'parentid' => '330600',
    'parentids' => '330000,330600,330624',
    'level' => '3',
    'name' => '新昌县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1078 => 
  array (
    'id' => '330681',
    'parentid' => '330600',
    'parentids' => '330000,330600,330681',
    'level' => '3',
    'name' => '诸暨市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1079 => 
  array (
    'id' => '330682',
    'parentid' => '330600',
    'parentids' => '330000,330600,330682',
    'level' => '3',
    'name' => '上虞市',
    'letter' => 's',
    'listorder' => '0',
  ),
  1080 => 
  array (
    'id' => '330683',
    'parentid' => '330600',
    'parentids' => '330000,330600,330683',
    'level' => '3',
    'name' => '嵊州市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1081 => 
  array (
    'id' => '330700',
    'parentid' => '330000',
    'parentids' => '330000,330700',
    'level' => '2',
    'name' => '金华市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1082 => 
  array (
    'id' => '330701',
    'parentid' => '330700',
    'parentids' => '330000,330700,330701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1083 => 
  array (
    'id' => '330702',
    'parentid' => '330700',
    'parentids' => '330000,330700,330702',
    'level' => '3',
    'name' => '婺城区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1084 => 
  array (
    'id' => '330703',
    'parentid' => '330700',
    'parentids' => '330000,330700,330703',
    'level' => '3',
    'name' => '金东区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1085 => 
  array (
    'id' => '330723',
    'parentid' => '330700',
    'parentids' => '330000,330700,330723',
    'level' => '3',
    'name' => '武义县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1086 => 
  array (
    'id' => '330726',
    'parentid' => '330700',
    'parentids' => '330000,330700,330726',
    'level' => '3',
    'name' => '浦江县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1087 => 
  array (
    'id' => '330727',
    'parentid' => '330700',
    'parentids' => '330000,330700,330727',
    'level' => '3',
    'name' => '磐安县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1088 => 
  array (
    'id' => '330781',
    'parentid' => '330700',
    'parentids' => '330000,330700,330781',
    'level' => '3',
    'name' => '兰溪市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1089 => 
  array (
    'id' => '330782',
    'parentid' => '330700',
    'parentids' => '330000,330700,330782',
    'level' => '3',
    'name' => '义乌市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1090 => 
  array (
    'id' => '330783',
    'parentid' => '330700',
    'parentids' => '330000,330700,330783',
    'level' => '3',
    'name' => '东阳市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1091 => 
  array (
    'id' => '330784',
    'parentid' => '330700',
    'parentids' => '330000,330700,330784',
    'level' => '3',
    'name' => '永康市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1092 => 
  array (
    'id' => '330800',
    'parentid' => '330000',
    'parentids' => '330000,330800',
    'level' => '2',
    'name' => '衢州市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1093 => 
  array (
    'id' => '330801',
    'parentid' => '330800',
    'parentids' => '330000,330800,330801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1094 => 
  array (
    'id' => '330802',
    'parentid' => '330800',
    'parentids' => '330000,330800,330802',
    'level' => '3',
    'name' => '柯城区',
    'letter' => 'k',
    'listorder' => '0',
  ),
  1095 => 
  array (
    'id' => '330803',
    'parentid' => '330800',
    'parentids' => '330000,330800,330803',
    'level' => '3',
    'name' => '衢江区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1096 => 
  array (
    'id' => '330822',
    'parentid' => '330800',
    'parentids' => '330000,330800,330822',
    'level' => '3',
    'name' => '常山县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1097 => 
  array (
    'id' => '330824',
    'parentid' => '330800',
    'parentids' => '330000,330800,330824',
    'level' => '3',
    'name' => '开化县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  1098 => 
  array (
    'id' => '330825',
    'parentid' => '330800',
    'parentids' => '330000,330800,330825',
    'level' => '3',
    'name' => '龙游县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1099 => 
  array (
    'id' => '330881',
    'parentid' => '330800',
    'parentids' => '330000,330800,330881',
    'level' => '3',
    'name' => '江山市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1100 => 
  array (
    'id' => '330900',
    'parentid' => '330000',
    'parentids' => '330000,330900',
    'level' => '2',
    'name' => '舟山市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1101 => 
  array (
    'id' => '330901',
    'parentid' => '330900',
    'parentids' => '330000,330900,330901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1102 => 
  array (
    'id' => '330902',
    'parentid' => '330900',
    'parentids' => '330000,330900,330902',
    'level' => '3',
    'name' => '定海区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1103 => 
  array (
    'id' => '330903',
    'parentid' => '330900',
    'parentids' => '330000,330900,330903',
    'level' => '3',
    'name' => '普陀区',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1104 => 
  array (
    'id' => '330921',
    'parentid' => '330900',
    'parentids' => '330000,330900,330921',
    'level' => '3',
    'name' => '岱山县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1105 => 
  array (
    'id' => '330922',
    'parentid' => '330900',
    'parentids' => '330000,330900,330922',
    'level' => '3',
    'name' => '嵊泗县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1106 => 
  array (
    'id' => '331000',
    'parentid' => '330000',
    'parentids' => '330000,331000',
    'level' => '2',
    'name' => '台州市',
    'letter' => 't',
    'listorder' => '0',
  ),
  1107 => 
  array (
    'id' => '331001',
    'parentid' => '331000',
    'parentids' => '330000,331000,331001',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1108 => 
  array (
    'id' => '331002',
    'parentid' => '331000',
    'parentids' => '330000,331000,331002',
    'level' => '3',
    'name' => '椒江区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1109 => 
  array (
    'id' => '331003',
    'parentid' => '331000',
    'parentids' => '330000,331000,331003',
    'level' => '3',
    'name' => '黄岩区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1110 => 
  array (
    'id' => '331004',
    'parentid' => '331000',
    'parentids' => '330000,331000,331004',
    'level' => '3',
    'name' => '路桥区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1111 => 
  array (
    'id' => '331021',
    'parentid' => '331000',
    'parentids' => '330000,331000,331021',
    'level' => '3',
    'name' => '玉环县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1112 => 
  array (
    'id' => '331022',
    'parentid' => '331000',
    'parentids' => '330000,331000,331022',
    'level' => '3',
    'name' => '三门县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1113 => 
  array (
    'id' => '331023',
    'parentid' => '331000',
    'parentids' => '330000,331000,331023',
    'level' => '3',
    'name' => '天台县',
    'letter' => 't',
    'listorder' => '0',
  ),
  1114 => 
  array (
    'id' => '331024',
    'parentid' => '331000',
    'parentids' => '330000,331000,331024',
    'level' => '3',
    'name' => '仙居县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1115 => 
  array (
    'id' => '331081',
    'parentid' => '331000',
    'parentids' => '330000,331000,331081',
    'level' => '3',
    'name' => '温岭市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1116 => 
  array (
    'id' => '331082',
    'parentid' => '331000',
    'parentids' => '330000,331000,331082',
    'level' => '3',
    'name' => '临海市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1117 => 
  array (
    'id' => '331100',
    'parentid' => '330000',
    'parentids' => '330000,331100',
    'level' => '2',
    'name' => '丽水市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1118 => 
  array (
    'id' => '331101',
    'parentid' => '331100',
    'parentids' => '330000,331100,331101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1119 => 
  array (
    'id' => '331102',
    'parentid' => '331100',
    'parentids' => '330000,331100,331102',
    'level' => '3',
    'name' => '莲都区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1120 => 
  array (
    'id' => '331121',
    'parentid' => '331100',
    'parentids' => '330000,331100,331121',
    'level' => '3',
    'name' => '青田县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1121 => 
  array (
    'id' => '331122',
    'parentid' => '331100',
    'parentids' => '330000,331100,331122',
    'level' => '3',
    'name' => '缙云县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1122 => 
  array (
    'id' => '331123',
    'parentid' => '331100',
    'parentids' => '330000,331100,331123',
    'level' => '3',
    'name' => '遂昌县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1123 => 
  array (
    'id' => '331124',
    'parentid' => '331100',
    'parentids' => '330000,331100,331124',
    'level' => '3',
    'name' => '松阳县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1124 => 
  array (
    'id' => '331125',
    'parentid' => '331100',
    'parentids' => '330000,331100,331125',
    'level' => '3',
    'name' => '云和县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1125 => 
  array (
    'id' => '331126',
    'parentid' => '331100',
    'parentids' => '330000,331100,331126',
    'level' => '3',
    'name' => '庆元县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1126 => 
  array (
    'id' => '331127',
    'parentid' => '331100',
    'parentids' => '330000,331100,331127',
    'level' => '3',
    'name' => '景宁畲族自治县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1127 => 
  array (
    'id' => '331181',
    'parentid' => '331100',
    'parentids' => '330000,331100,331181',
    'level' => '3',
    'name' => '龙泉市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1128 => 
  array (
    'id' => '340000',
    'parentid' => '0',
    'parentids' => '340000',
    'level' => '1',
    'name' => '安徽省',
    'letter' => 'a',
    'listorder' => '0',
  ),
  1129 => 
  array (
    'id' => '340100',
    'parentid' => '340000',
    'parentids' => '340000,340100',
    'level' => '2',
    'name' => '合肥市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1130 => 
  array (
    'id' => '340101',
    'parentid' => '340100',
    'parentids' => '340000,340100,340101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1131 => 
  array (
    'id' => '340102',
    'parentid' => '340100',
    'parentids' => '340000,340100,340102',
    'level' => '3',
    'name' => '瑶海区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1132 => 
  array (
    'id' => '340103',
    'parentid' => '340100',
    'parentids' => '340000,340100,340103',
    'level' => '3',
    'name' => '庐阳区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1133 => 
  array (
    'id' => '340104',
    'parentid' => '340100',
    'parentids' => '340000,340100,340104',
    'level' => '3',
    'name' => '蜀山区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1134 => 
  array (
    'id' => '340111',
    'parentid' => '340100',
    'parentids' => '340000,340100,340111',
    'level' => '3',
    'name' => '包河区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  1135 => 
  array (
    'id' => '340121',
    'parentid' => '340100',
    'parentids' => '340000,340100,340121',
    'level' => '3',
    'name' => '长丰县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1136 => 
  array (
    'id' => '340122',
    'parentid' => '340100',
    'parentids' => '340000,340100,340122',
    'level' => '3',
    'name' => '肥东县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1137 => 
  array (
    'id' => '340123',
    'parentid' => '340100',
    'parentids' => '340000,340100,340123',
    'level' => '3',
    'name' => '肥西县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1138 => 
  array (
    'id' => '340200',
    'parentid' => '340000',
    'parentids' => '340000,340200',
    'level' => '2',
    'name' => '芜湖市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1139 => 
  array (
    'id' => '340201',
    'parentid' => '340200',
    'parentids' => '340000,340200,340201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1140 => 
  array (
    'id' => '340202',
    'parentid' => '340200',
    'parentids' => '340000,340200,340202',
    'level' => '3',
    'name' => '镜湖区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1141 => 
  array (
    'id' => '340203',
    'parentid' => '340200',
    'parentids' => '340000,340200,340203',
    'level' => '3',
    'name' => '马塘区',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1142 => 
  array (
    'id' => '340204',
    'parentid' => '340200',
    'parentids' => '340000,340200,340204',
    'level' => '3',
    'name' => '新芜区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1143 => 
  array (
    'id' => '340207',
    'parentid' => '340200',
    'parentids' => '340000,340200,340207',
    'level' => '3',
    'name' => '鸠江区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1144 => 
  array (
    'id' => '340221',
    'parentid' => '340200',
    'parentids' => '340000,340200,340221',
    'level' => '3',
    'name' => '芜湖县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1145 => 
  array (
    'id' => '340222',
    'parentid' => '340200',
    'parentids' => '340000,340200,340222',
    'level' => '3',
    'name' => '繁昌县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1146 => 
  array (
    'id' => '340223',
    'parentid' => '340200',
    'parentids' => '340000,340200,340223',
    'level' => '3',
    'name' => '南陵县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1147 => 
  array (
    'id' => '340300',
    'parentid' => '340000',
    'parentids' => '340000,340300',
    'level' => '2',
    'name' => '蚌埠市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  1148 => 
  array (
    'id' => '340301',
    'parentid' => '340300',
    'parentids' => '340000,340300,340301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1149 => 
  array (
    'id' => '340302',
    'parentid' => '340300',
    'parentids' => '340000,340300,340302',
    'level' => '3',
    'name' => '龙子湖区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1150 => 
  array (
    'id' => '340303',
    'parentid' => '340300',
    'parentids' => '340000,340300,340303',
    'level' => '3',
    'name' => '蚌山区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  1151 => 
  array (
    'id' => '340304',
    'parentid' => '340300',
    'parentids' => '340000,340300,340304',
    'level' => '3',
    'name' => '禹会区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1152 => 
  array (
    'id' => '340311',
    'parentid' => '340300',
    'parentids' => '340000,340300,340311',
    'level' => '3',
    'name' => '淮上区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1153 => 
  array (
    'id' => '340321',
    'parentid' => '340300',
    'parentids' => '340000,340300,340321',
    'level' => '3',
    'name' => '怀远县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1154 => 
  array (
    'id' => '340322',
    'parentid' => '340300',
    'parentids' => '340000,340300,340322',
    'level' => '3',
    'name' => '五河县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1155 => 
  array (
    'id' => '340323',
    'parentid' => '340300',
    'parentids' => '340000,340300,340323',
    'level' => '3',
    'name' => '固镇县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1156 => 
  array (
    'id' => '340400',
    'parentid' => '340000',
    'parentids' => '340000,340400',
    'level' => '2',
    'name' => '淮南市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1157 => 
  array (
    'id' => '340401',
    'parentid' => '340400',
    'parentids' => '340000,340400,340401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1158 => 
  array (
    'id' => '340402',
    'parentid' => '340400',
    'parentids' => '340000,340400,340402',
    'level' => '3',
    'name' => '大通区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1159 => 
  array (
    'id' => '340403',
    'parentid' => '340400',
    'parentids' => '340000,340400,340403',
    'level' => '3',
    'name' => '田家庵区',
    'letter' => 't',
    'listorder' => '0',
  ),
  1160 => 
  array (
    'id' => '340404',
    'parentid' => '340400',
    'parentids' => '340000,340400,340404',
    'level' => '3',
    'name' => '谢家集区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1161 => 
  array (
    'id' => '340405',
    'parentid' => '340400',
    'parentids' => '340000,340400,340405',
    'level' => '3',
    'name' => '八公山区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  1162 => 
  array (
    'id' => '340406',
    'parentid' => '340400',
    'parentids' => '340000,340400,340406',
    'level' => '3',
    'name' => '潘集区',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1163 => 
  array (
    'id' => '340421',
    'parentid' => '340400',
    'parentids' => '340000,340400,340421',
    'level' => '3',
    'name' => '凤台县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1164 => 
  array (
    'id' => '340500',
    'parentid' => '340000',
    'parentids' => '340000,340500',
    'level' => '2',
    'name' => '马鞍山市',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1165 => 
  array (
    'id' => '340501',
    'parentid' => '340500',
    'parentids' => '340000,340500,340501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1166 => 
  array (
    'id' => '340502',
    'parentid' => '340500',
    'parentids' => '340000,340500,340502',
    'level' => '3',
    'name' => '金家庄区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1167 => 
  array (
    'id' => '340503',
    'parentid' => '340500',
    'parentids' => '340000,340500,340503',
    'level' => '3',
    'name' => '花山区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1168 => 
  array (
    'id' => '340504',
    'parentid' => '340500',
    'parentids' => '340000,340500,340504',
    'level' => '3',
    'name' => '雨山区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1169 => 
  array (
    'id' => '340521',
    'parentid' => '340500',
    'parentids' => '340000,340500,340521',
    'level' => '3',
    'name' => '当涂县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1170 => 
  array (
    'id' => '340600',
    'parentid' => '340000',
    'parentids' => '340000,340600',
    'level' => '2',
    'name' => '淮北市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1171 => 
  array (
    'id' => '340601',
    'parentid' => '340600',
    'parentids' => '340000,340600,340601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1172 => 
  array (
    'id' => '340602',
    'parentid' => '340600',
    'parentids' => '340000,340600,340602',
    'level' => '3',
    'name' => '杜集区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1173 => 
  array (
    'id' => '340603',
    'parentid' => '340600',
    'parentids' => '340000,340600,340603',
    'level' => '3',
    'name' => '相山区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1174 => 
  array (
    'id' => '340604',
    'parentid' => '340600',
    'parentids' => '340000,340600,340604',
    'level' => '3',
    'name' => '烈山区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1175 => 
  array (
    'id' => '340621',
    'parentid' => '340600',
    'parentids' => '340000,340600,340621',
    'level' => '3',
    'name' => '濉溪县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1176 => 
  array (
    'id' => '340700',
    'parentid' => '340000',
    'parentids' => '340000,340700',
    'level' => '2',
    'name' => '铜陵市',
    'letter' => 't',
    'listorder' => '0',
  ),
  1177 => 
  array (
    'id' => '340701',
    'parentid' => '340700',
    'parentids' => '340000,340700,340701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1178 => 
  array (
    'id' => '340702',
    'parentid' => '340700',
    'parentids' => '340000,340700,340702',
    'level' => '3',
    'name' => '铜官山区',
    'letter' => 't',
    'listorder' => '0',
  ),
  1179 => 
  array (
    'id' => '340703',
    'parentid' => '340700',
    'parentids' => '340000,340700,340703',
    'level' => '3',
    'name' => '狮子山区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1180 => 
  array (
    'id' => '340711',
    'parentid' => '340700',
    'parentids' => '340000,340700,340711',
    'level' => '3',
    'name' => '郊　区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1181 => 
  array (
    'id' => '340721',
    'parentid' => '340700',
    'parentids' => '340000,340700,340721',
    'level' => '3',
    'name' => '铜陵县',
    'letter' => 't',
    'listorder' => '0',
  ),
  1182 => 
  array (
    'id' => '340800',
    'parentid' => '340000',
    'parentids' => '340000,340800',
    'level' => '2',
    'name' => '安庆市',
    'letter' => 'a',
    'listorder' => '0',
  ),
  1183 => 
  array (
    'id' => '340801',
    'parentid' => '340800',
    'parentids' => '340000,340800,340801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1184 => 
  array (
    'id' => '340802',
    'parentid' => '340800',
    'parentids' => '340000,340800,340802',
    'level' => '3',
    'name' => '迎江区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1185 => 
  array (
    'id' => '340803',
    'parentid' => '340800',
    'parentids' => '340000,340800,340803',
    'level' => '3',
    'name' => '大观区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1186 => 
  array (
    'id' => '340811',
    'parentid' => '340800',
    'parentids' => '340000,340800,340811',
    'level' => '3',
    'name' => '郊　区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1187 => 
  array (
    'id' => '340822',
    'parentid' => '340800',
    'parentids' => '340000,340800,340822',
    'level' => '3',
    'name' => '怀宁县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1188 => 
  array (
    'id' => '340823',
    'parentid' => '340800',
    'parentids' => '340000,340800,340823',
    'level' => '3',
    'name' => '枞阳县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1189 => 
  array (
    'id' => '340824',
    'parentid' => '340800',
    'parentids' => '340000,340800,340824',
    'level' => '3',
    'name' => '潜山县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1190 => 
  array (
    'id' => '340825',
    'parentid' => '340800',
    'parentids' => '340000,340800,340825',
    'level' => '3',
    'name' => '太湖县',
    'letter' => 't',
    'listorder' => '0',
  ),
  1191 => 
  array (
    'id' => '340826',
    'parentid' => '340800',
    'parentids' => '340000,340800,340826',
    'level' => '3',
    'name' => '宿松县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1192 => 
  array (
    'id' => '340827',
    'parentid' => '340800',
    'parentids' => '340000,340800,340827',
    'level' => '3',
    'name' => '望江县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1193 => 
  array (
    'id' => '340828',
    'parentid' => '340800',
    'parentids' => '340000,340800,340828',
    'level' => '3',
    'name' => '岳西县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1194 => 
  array (
    'id' => '340881',
    'parentid' => '340800',
    'parentids' => '340000,340800,340881',
    'level' => '3',
    'name' => '桐城市',
    'letter' => 't',
    'listorder' => '0',
  ),
  1195 => 
  array (
    'id' => '341000',
    'parentid' => '340000',
    'parentids' => '340000,341000',
    'level' => '2',
    'name' => '黄山市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1196 => 
  array (
    'id' => '341001',
    'parentid' => '341000',
    'parentids' => '340000,341000,341001',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1197 => 
  array (
    'id' => '341002',
    'parentid' => '341000',
    'parentids' => '340000,341000,341002',
    'level' => '3',
    'name' => '屯溪区',
    'letter' => 't',
    'listorder' => '0',
  ),
  1198 => 
  array (
    'id' => '341003',
    'parentid' => '341000',
    'parentids' => '340000,341000,341003',
    'level' => '3',
    'name' => '黄山区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1199 => 
  array (
    'id' => '341004',
    'parentid' => '341000',
    'parentids' => '340000,341000,341004',
    'level' => '3',
    'name' => '徽州区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1200 => 
  array (
    'id' => '341021',
    'parentid' => '341000',
    'parentids' => '340000,341000,341021',
    'level' => '3',
    'name' => '歙　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1201 => 
  array (
    'id' => '341022',
    'parentid' => '341000',
    'parentids' => '340000,341000,341022',
    'level' => '3',
    'name' => '休宁县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1202 => 
  array (
    'id' => '341023',
    'parentid' => '341000',
    'parentids' => '340000,341000,341023',
    'level' => '3',
    'name' => '黟　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1203 => 
  array (
    'id' => '341024',
    'parentid' => '341000',
    'parentids' => '340000,341000,341024',
    'level' => '3',
    'name' => '祁门县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1204 => 
  array (
    'id' => '341100',
    'parentid' => '340000',
    'parentids' => '340000,341100',
    'level' => '2',
    'name' => '滁州市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1205 => 
  array (
    'id' => '341101',
    'parentid' => '341100',
    'parentids' => '340000,341100,341101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1206 => 
  array (
    'id' => '341102',
    'parentid' => '341100',
    'parentids' => '340000,341100,341102',
    'level' => '3',
    'name' => '琅琊区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1207 => 
  array (
    'id' => '341103',
    'parentid' => '341100',
    'parentids' => '340000,341100,341103',
    'level' => '3',
    'name' => '南谯区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1208 => 
  array (
    'id' => '341122',
    'parentid' => '341100',
    'parentids' => '340000,341100,341122',
    'level' => '3',
    'name' => '来安县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1209 => 
  array (
    'id' => '341124',
    'parentid' => '341100',
    'parentids' => '340000,341100,341124',
    'level' => '3',
    'name' => '全椒县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1210 => 
  array (
    'id' => '341125',
    'parentid' => '341100',
    'parentids' => '340000,341100,341125',
    'level' => '3',
    'name' => '定远县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1211 => 
  array (
    'id' => '341126',
    'parentid' => '341100',
    'parentids' => '340000,341100,341126',
    'level' => '3',
    'name' => '凤阳县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1212 => 
  array (
    'id' => '341181',
    'parentid' => '341100',
    'parentids' => '340000,341100,341181',
    'level' => '3',
    'name' => '天长市',
    'letter' => 't',
    'listorder' => '0',
  ),
  1213 => 
  array (
    'id' => '341182',
    'parentid' => '341100',
    'parentids' => '340000,341100,341182',
    'level' => '3',
    'name' => '明光市',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1214 => 
  array (
    'id' => '341200',
    'parentid' => '340000',
    'parentids' => '340000,341200',
    'level' => '2',
    'name' => '阜阳市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1215 => 
  array (
    'id' => '341201',
    'parentid' => '341200',
    'parentids' => '340000,341200,341201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1216 => 
  array (
    'id' => '341202',
    'parentid' => '341200',
    'parentids' => '340000,341200,341202',
    'level' => '3',
    'name' => '颍州区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1217 => 
  array (
    'id' => '341203',
    'parentid' => '341200',
    'parentids' => '340000,341200,341203',
    'level' => '3',
    'name' => '颍东区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1218 => 
  array (
    'id' => '341204',
    'parentid' => '341200',
    'parentids' => '340000,341200,341204',
    'level' => '3',
    'name' => '颍泉区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1219 => 
  array (
    'id' => '341221',
    'parentid' => '341200',
    'parentids' => '340000,341200,341221',
    'level' => '3',
    'name' => '临泉县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1220 => 
  array (
    'id' => '341222',
    'parentid' => '341200',
    'parentids' => '340000,341200,341222',
    'level' => '3',
    'name' => '太和县',
    'letter' => 't',
    'listorder' => '0',
  ),
  1221 => 
  array (
    'id' => '341225',
    'parentid' => '341200',
    'parentids' => '340000,341200,341225',
    'level' => '3',
    'name' => '阜南县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1222 => 
  array (
    'id' => '341226',
    'parentid' => '341200',
    'parentids' => '340000,341200,341226',
    'level' => '3',
    'name' => '颍上县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1223 => 
  array (
    'id' => '341282',
    'parentid' => '341200',
    'parentids' => '340000,341200,341282',
    'level' => '3',
    'name' => '界首市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1224 => 
  array (
    'id' => '341300',
    'parentid' => '340000',
    'parentids' => '340000,341300',
    'level' => '2',
    'name' => '宿州市',
    'letter' => 's',
    'listorder' => '0',
  ),
  1225 => 
  array (
    'id' => '341301',
    'parentid' => '341300',
    'parentids' => '340000,341300,341301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1226 => 
  array (
    'id' => '341302',
    'parentid' => '341300',
    'parentids' => '340000,341300,341302',
    'level' => '3',
    'name' => '墉桥区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1227 => 
  array (
    'id' => '341321',
    'parentid' => '341300',
    'parentids' => '340000,341300,341321',
    'level' => '3',
    'name' => '砀山县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1228 => 
  array (
    'id' => '341322',
    'parentid' => '341300',
    'parentids' => '340000,341300,341322',
    'level' => '3',
    'name' => '萧　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1229 => 
  array (
    'id' => '341323',
    'parentid' => '341300',
    'parentids' => '340000,341300,341323',
    'level' => '3',
    'name' => '灵璧县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1230 => 
  array (
    'id' => '341324',
    'parentid' => '341300',
    'parentids' => '340000,341300,341324',
    'level' => '3',
    'name' => '泗　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1231 => 
  array (
    'id' => '341400',
    'parentid' => '340000',
    'parentids' => '340000,341400',
    'level' => '2',
    'name' => '巢湖市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1232 => 
  array (
    'id' => '341401',
    'parentid' => '341400',
    'parentids' => '340000,341400,341401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1233 => 
  array (
    'id' => '341402',
    'parentid' => '341400',
    'parentids' => '340000,341400,341402',
    'level' => '3',
    'name' => '居巢区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1234 => 
  array (
    'id' => '341421',
    'parentid' => '341400',
    'parentids' => '340000,341400,341421',
    'level' => '3',
    'name' => '庐江县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1235 => 
  array (
    'id' => '341422',
    'parentid' => '341400',
    'parentids' => '340000,341400,341422',
    'level' => '3',
    'name' => '无为县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1236 => 
  array (
    'id' => '341423',
    'parentid' => '341400',
    'parentids' => '340000,341400,341423',
    'level' => '3',
    'name' => '含山县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1237 => 
  array (
    'id' => '341424',
    'parentid' => '341400',
    'parentids' => '340000,341400,341424',
    'level' => '3',
    'name' => '和　县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1238 => 
  array (
    'id' => '341500',
    'parentid' => '340000',
    'parentids' => '340000,341500',
    'level' => '2',
    'name' => '六安市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1239 => 
  array (
    'id' => '341501',
    'parentid' => '341500',
    'parentids' => '340000,341500,341501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1240 => 
  array (
    'id' => '341502',
    'parentid' => '341500',
    'parentids' => '340000,341500,341502',
    'level' => '3',
    'name' => '金安区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1241 => 
  array (
    'id' => '341503',
    'parentid' => '341500',
    'parentids' => '340000,341500,341503',
    'level' => '3',
    'name' => '裕安区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1242 => 
  array (
    'id' => '341521',
    'parentid' => '341500',
    'parentids' => '340000,341500,341521',
    'level' => '3',
    'name' => '寿　县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1243 => 
  array (
    'id' => '341522',
    'parentid' => '341500',
    'parentids' => '340000,341500,341522',
    'level' => '3',
    'name' => '霍邱县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1244 => 
  array (
    'id' => '341523',
    'parentid' => '341500',
    'parentids' => '340000,341500,341523',
    'level' => '3',
    'name' => '舒城县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1245 => 
  array (
    'id' => '341524',
    'parentid' => '341500',
    'parentids' => '340000,341500,341524',
    'level' => '3',
    'name' => '金寨县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1246 => 
  array (
    'id' => '341525',
    'parentid' => '341500',
    'parentids' => '340000,341500,341525',
    'level' => '3',
    'name' => '霍山县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1247 => 
  array (
    'id' => '341600',
    'parentid' => '340000',
    'parentids' => '340000,341600',
    'level' => '2',
    'name' => '亳州市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1248 => 
  array (
    'id' => '341601',
    'parentid' => '341600',
    'parentids' => '340000,341600,341601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1249 => 
  array (
    'id' => '341602',
    'parentid' => '341600',
    'parentids' => '340000,341600,341602',
    'level' => '3',
    'name' => '谯城区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1250 => 
  array (
    'id' => '341621',
    'parentid' => '341600',
    'parentids' => '340000,341600,341621',
    'level' => '3',
    'name' => '涡阳县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1251 => 
  array (
    'id' => '341622',
    'parentid' => '341600',
    'parentids' => '340000,341600,341622',
    'level' => '3',
    'name' => '蒙城县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1252 => 
  array (
    'id' => '341623',
    'parentid' => '341600',
    'parentids' => '340000,341600,341623',
    'level' => '3',
    'name' => '利辛县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1253 => 
  array (
    'id' => '341700',
    'parentid' => '340000',
    'parentids' => '340000,341700',
    'level' => '2',
    'name' => '池州市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1254 => 
  array (
    'id' => '341701',
    'parentid' => '341700',
    'parentids' => '340000,341700,341701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1255 => 
  array (
    'id' => '341702',
    'parentid' => '341700',
    'parentids' => '340000,341700,341702',
    'level' => '3',
    'name' => '贵池区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1256 => 
  array (
    'id' => '341721',
    'parentid' => '341700',
    'parentids' => '340000,341700,341721',
    'level' => '3',
    'name' => '东至县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1257 => 
  array (
    'id' => '341722',
    'parentid' => '341700',
    'parentids' => '340000,341700,341722',
    'level' => '3',
    'name' => '石台县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1258 => 
  array (
    'id' => '341723',
    'parentid' => '341700',
    'parentids' => '340000,341700,341723',
    'level' => '3',
    'name' => '青阳县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1259 => 
  array (
    'id' => '341800',
    'parentid' => '340000',
    'parentids' => '340000,341800',
    'level' => '2',
    'name' => '宣城市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1260 => 
  array (
    'id' => '341801',
    'parentid' => '341800',
    'parentids' => '340000,341800,341801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1261 => 
  array (
    'id' => '341802',
    'parentid' => '341800',
    'parentids' => '340000,341800,341802',
    'level' => '3',
    'name' => '宣州区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1262 => 
  array (
    'id' => '341821',
    'parentid' => '341800',
    'parentids' => '340000,341800,341821',
    'level' => '3',
    'name' => '郎溪县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1263 => 
  array (
    'id' => '341822',
    'parentid' => '341800',
    'parentids' => '340000,341800,341822',
    'level' => '3',
    'name' => '广德县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1264 => 
  array (
    'id' => '341823',
    'parentid' => '341800',
    'parentids' => '340000,341800,341823',
    'level' => '3',
    'name' => '泾　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1265 => 
  array (
    'id' => '341824',
    'parentid' => '341800',
    'parentids' => '340000,341800,341824',
    'level' => '3',
    'name' => '绩溪县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1266 => 
  array (
    'id' => '341825',
    'parentid' => '341800',
    'parentids' => '340000,341800,341825',
    'level' => '3',
    'name' => '旌德县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1267 => 
  array (
    'id' => '341881',
    'parentid' => '341800',
    'parentids' => '340000,341800,341881',
    'level' => '3',
    'name' => '宁国市',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1268 => 
  array (
    'id' => '350000',
    'parentid' => '0',
    'parentids' => '350000',
    'level' => '1',
    'name' => '福建省',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1269 => 
  array (
    'id' => '350100',
    'parentid' => '350000',
    'parentids' => '350000,350100',
    'level' => '2',
    'name' => '福州市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1270 => 
  array (
    'id' => '350101',
    'parentid' => '350100',
    'parentids' => '350000,350100,350101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1271 => 
  array (
    'id' => '350102',
    'parentid' => '350100',
    'parentids' => '350000,350100,350102',
    'level' => '3',
    'name' => '鼓楼区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1272 => 
  array (
    'id' => '350103',
    'parentid' => '350100',
    'parentids' => '350000,350100,350103',
    'level' => '3',
    'name' => '台江区',
    'letter' => 't',
    'listorder' => '0',
  ),
  1273 => 
  array (
    'id' => '350104',
    'parentid' => '350100',
    'parentids' => '350000,350100,350104',
    'level' => '3',
    'name' => '仓山区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1274 => 
  array (
    'id' => '350105',
    'parentid' => '350100',
    'parentids' => '350000,350100,350105',
    'level' => '3',
    'name' => '马尾区',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1275 => 
  array (
    'id' => '350111',
    'parentid' => '350100',
    'parentids' => '350000,350100,350111',
    'level' => '3',
    'name' => '晋安区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1276 => 
  array (
    'id' => '350121',
    'parentid' => '350100',
    'parentids' => '350000,350100,350121',
    'level' => '3',
    'name' => '闽侯县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1277 => 
  array (
    'id' => '350122',
    'parentid' => '350100',
    'parentids' => '350000,350100,350122',
    'level' => '3',
    'name' => '连江县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1278 => 
  array (
    'id' => '350123',
    'parentid' => '350100',
    'parentids' => '350000,350100,350123',
    'level' => '3',
    'name' => '罗源县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1279 => 
  array (
    'id' => '350124',
    'parentid' => '350100',
    'parentids' => '350000,350100,350124',
    'level' => '3',
    'name' => '闽清县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1280 => 
  array (
    'id' => '350125',
    'parentid' => '350100',
    'parentids' => '350000,350100,350125',
    'level' => '3',
    'name' => '永泰县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1281 => 
  array (
    'id' => '350128',
    'parentid' => '350100',
    'parentids' => '350000,350100,350128',
    'level' => '3',
    'name' => '平潭县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1282 => 
  array (
    'id' => '350181',
    'parentid' => '350100',
    'parentids' => '350000,350100,350181',
    'level' => '3',
    'name' => '福清市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1283 => 
  array (
    'id' => '350182',
    'parentid' => '350100',
    'parentids' => '350000,350100,350182',
    'level' => '3',
    'name' => '长乐市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1284 => 
  array (
    'id' => '350200',
    'parentid' => '350000',
    'parentids' => '350000,350200',
    'level' => '2',
    'name' => '厦门市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1285 => 
  array (
    'id' => '350201',
    'parentid' => '350200',
    'parentids' => '350000,350200,350201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1286 => 
  array (
    'id' => '350203',
    'parentid' => '350200',
    'parentids' => '350000,350200,350203',
    'level' => '3',
    'name' => '思明区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1287 => 
  array (
    'id' => '350205',
    'parentid' => '350200',
    'parentids' => '350000,350200,350205',
    'level' => '3',
    'name' => '海沧区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1288 => 
  array (
    'id' => '350206',
    'parentid' => '350200',
    'parentids' => '350000,350200,350206',
    'level' => '3',
    'name' => '湖里区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1289 => 
  array (
    'id' => '350211',
    'parentid' => '350200',
    'parentids' => '350000,350200,350211',
    'level' => '3',
    'name' => '集美区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1290 => 
  array (
    'id' => '350212',
    'parentid' => '350200',
    'parentids' => '350000,350200,350212',
    'level' => '3',
    'name' => '同安区',
    'letter' => 't',
    'listorder' => '0',
  ),
  1291 => 
  array (
    'id' => '350213',
    'parentid' => '350200',
    'parentids' => '350000,350200,350213',
    'level' => '3',
    'name' => '翔安区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1292 => 
  array (
    'id' => '350300',
    'parentid' => '350000',
    'parentids' => '350000,350300',
    'level' => '2',
    'name' => '莆田市',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1293 => 
  array (
    'id' => '350301',
    'parentid' => '350300',
    'parentids' => '350000,350300,350301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1294 => 
  array (
    'id' => '350302',
    'parentid' => '350300',
    'parentids' => '350000,350300,350302',
    'level' => '3',
    'name' => '城厢区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1295 => 
  array (
    'id' => '350303',
    'parentid' => '350300',
    'parentids' => '350000,350300,350303',
    'level' => '3',
    'name' => '涵江区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1296 => 
  array (
    'id' => '350304',
    'parentid' => '350300',
    'parentids' => '350000,350300,350304',
    'level' => '3',
    'name' => '荔城区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1297 => 
  array (
    'id' => '350305',
    'parentid' => '350300',
    'parentids' => '350000,350300,350305',
    'level' => '3',
    'name' => '秀屿区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1298 => 
  array (
    'id' => '350322',
    'parentid' => '350300',
    'parentids' => '350000,350300,350322',
    'level' => '3',
    'name' => '仙游县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1299 => 
  array (
    'id' => '350400',
    'parentid' => '350000',
    'parentids' => '350000,350400',
    'level' => '2',
    'name' => '三明市',
    'letter' => 's',
    'listorder' => '0',
  ),
  1300 => 
  array (
    'id' => '350401',
    'parentid' => '350400',
    'parentids' => '350000,350400,350401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1301 => 
  array (
    'id' => '350402',
    'parentid' => '350400',
    'parentids' => '350000,350400,350402',
    'level' => '3',
    'name' => '梅列区',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1302 => 
  array (
    'id' => '350403',
    'parentid' => '350400',
    'parentids' => '350000,350400,350403',
    'level' => '3',
    'name' => '三元区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1303 => 
  array (
    'id' => '350421',
    'parentid' => '350400',
    'parentids' => '350000,350400,350421',
    'level' => '3',
    'name' => '明溪县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1304 => 
  array (
    'id' => '350423',
    'parentid' => '350400',
    'parentids' => '350000,350400,350423',
    'level' => '3',
    'name' => '清流县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1305 => 
  array (
    'id' => '350424',
    'parentid' => '350400',
    'parentids' => '350000,350400,350424',
    'level' => '3',
    'name' => '宁化县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1306 => 
  array (
    'id' => '350425',
    'parentid' => '350400',
    'parentids' => '350000,350400,350425',
    'level' => '3',
    'name' => '大田县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1307 => 
  array (
    'id' => '350426',
    'parentid' => '350400',
    'parentids' => '350000,350400,350426',
    'level' => '3',
    'name' => '尤溪县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1308 => 
  array (
    'id' => '350427',
    'parentid' => '350400',
    'parentids' => '350000,350400,350427',
    'level' => '3',
    'name' => '沙　县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1309 => 
  array (
    'id' => '350428',
    'parentid' => '350400',
    'parentids' => '350000,350400,350428',
    'level' => '3',
    'name' => '将乐县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1310 => 
  array (
    'id' => '350429',
    'parentid' => '350400',
    'parentids' => '350000,350400,350429',
    'level' => '3',
    'name' => '泰宁县',
    'letter' => 't',
    'listorder' => '0',
  ),
  1311 => 
  array (
    'id' => '350430',
    'parentid' => '350400',
    'parentids' => '350000,350400,350430',
    'level' => '3',
    'name' => '建宁县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1312 => 
  array (
    'id' => '350481',
    'parentid' => '350400',
    'parentids' => '350000,350400,350481',
    'level' => '3',
    'name' => '永安市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1313 => 
  array (
    'id' => '350500',
    'parentid' => '350000',
    'parentids' => '350000,350500',
    'level' => '2',
    'name' => '泉州市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1314 => 
  array (
    'id' => '350501',
    'parentid' => '350500',
    'parentids' => '350000,350500,350501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1315 => 
  array (
    'id' => '350502',
    'parentid' => '350500',
    'parentids' => '350000,350500,350502',
    'level' => '3',
    'name' => '鲤城区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1316 => 
  array (
    'id' => '350503',
    'parentid' => '350500',
    'parentids' => '350000,350500,350503',
    'level' => '3',
    'name' => '丰泽区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1317 => 
  array (
    'id' => '350504',
    'parentid' => '350500',
    'parentids' => '350000,350500,350504',
    'level' => '3',
    'name' => '洛江区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1318 => 
  array (
    'id' => '350505',
    'parentid' => '350500',
    'parentids' => '350000,350500,350505',
    'level' => '3',
    'name' => '泉港区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1319 => 
  array (
    'id' => '350521',
    'parentid' => '350500',
    'parentids' => '350000,350500,350521',
    'level' => '3',
    'name' => '惠安县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1320 => 
  array (
    'id' => '350524',
    'parentid' => '350500',
    'parentids' => '350000,350500,350524',
    'level' => '3',
    'name' => '安溪县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  1321 => 
  array (
    'id' => '350525',
    'parentid' => '350500',
    'parentids' => '350000,350500,350525',
    'level' => '3',
    'name' => '永春县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1322 => 
  array (
    'id' => '350526',
    'parentid' => '350500',
    'parentids' => '350000,350500,350526',
    'level' => '3',
    'name' => '德化县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1323 => 
  array (
    'id' => '350527',
    'parentid' => '350500',
    'parentids' => '350000,350500,350527',
    'level' => '3',
    'name' => '金门县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1324 => 
  array (
    'id' => '350581',
    'parentid' => '350500',
    'parentids' => '350000,350500,350581',
    'level' => '3',
    'name' => '石狮市',
    'letter' => 's',
    'listorder' => '0',
  ),
  1325 => 
  array (
    'id' => '350582',
    'parentid' => '350500',
    'parentids' => '350000,350500,350582',
    'level' => '3',
    'name' => '晋江市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1326 => 
  array (
    'id' => '350583',
    'parentid' => '350500',
    'parentids' => '350000,350500,350583',
    'level' => '3',
    'name' => '南安市',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1327 => 
  array (
    'id' => '350600',
    'parentid' => '350000',
    'parentids' => '350000,350600',
    'level' => '2',
    'name' => '漳州市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1328 => 
  array (
    'id' => '350601',
    'parentid' => '350600',
    'parentids' => '350000,350600,350601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1329 => 
  array (
    'id' => '350602',
    'parentid' => '350600',
    'parentids' => '350000,350600,350602',
    'level' => '3',
    'name' => '芗城区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1330 => 
  array (
    'id' => '350603',
    'parentid' => '350600',
    'parentids' => '350000,350600,350603',
    'level' => '3',
    'name' => '龙文区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1331 => 
  array (
    'id' => '350622',
    'parentid' => '350600',
    'parentids' => '350000,350600,350622',
    'level' => '3',
    'name' => '云霄县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1332 => 
  array (
    'id' => '350623',
    'parentid' => '350600',
    'parentids' => '350000,350600,350623',
    'level' => '3',
    'name' => '漳浦县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1333 => 
  array (
    'id' => '350624',
    'parentid' => '350600',
    'parentids' => '350000,350600,350624',
    'level' => '3',
    'name' => '诏安县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  1334 => 
  array (
    'id' => '350625',
    'parentid' => '350600',
    'parentids' => '350000,350600,350625',
    'level' => '3',
    'name' => '长泰县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1335 => 
  array (
    'id' => '350626',
    'parentid' => '350600',
    'parentids' => '350000,350600,350626',
    'level' => '3',
    'name' => '东山县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1336 => 
  array (
    'id' => '350627',
    'parentid' => '350600',
    'parentids' => '350000,350600,350627',
    'level' => '3',
    'name' => '南靖县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1337 => 
  array (
    'id' => '350628',
    'parentid' => '350600',
    'parentids' => '350000,350600,350628',
    'level' => '3',
    'name' => '平和县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1338 => 
  array (
    'id' => '350629',
    'parentid' => '350600',
    'parentids' => '350000,350600,350629',
    'level' => '3',
    'name' => '华安县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1339 => 
  array (
    'id' => '350681',
    'parentid' => '350600',
    'parentids' => '350000,350600,350681',
    'level' => '3',
    'name' => '龙海市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1340 => 
  array (
    'id' => '350700',
    'parentid' => '350000',
    'parentids' => '350000,350700',
    'level' => '2',
    'name' => '南平市',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1341 => 
  array (
    'id' => '350701',
    'parentid' => '350700',
    'parentids' => '350000,350700,350701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1342 => 
  array (
    'id' => '350702',
    'parentid' => '350700',
    'parentids' => '350000,350700,350702',
    'level' => '3',
    'name' => '延平区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1343 => 
  array (
    'id' => '350721',
    'parentid' => '350700',
    'parentids' => '350000,350700,350721',
    'level' => '3',
    'name' => '顺昌县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1344 => 
  array (
    'id' => '350722',
    'parentid' => '350700',
    'parentids' => '350000,350700,350722',
    'level' => '3',
    'name' => '浦城县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1345 => 
  array (
    'id' => '350723',
    'parentid' => '350700',
    'parentids' => '350000,350700,350723',
    'level' => '3',
    'name' => '光泽县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1346 => 
  array (
    'id' => '350724',
    'parentid' => '350700',
    'parentids' => '350000,350700,350724',
    'level' => '3',
    'name' => '松溪县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1347 => 
  array (
    'id' => '350725',
    'parentid' => '350700',
    'parentids' => '350000,350700,350725',
    'level' => '3',
    'name' => '政和县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1348 => 
  array (
    'id' => '350781',
    'parentid' => '350700',
    'parentids' => '350000,350700,350781',
    'level' => '3',
    'name' => '邵武市',
    'letter' => 's',
    'listorder' => '0',
  ),
  1349 => 
  array (
    'id' => '350782',
    'parentid' => '350700',
    'parentids' => '350000,350700,350782',
    'level' => '3',
    'name' => '武夷山市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1350 => 
  array (
    'id' => '350783',
    'parentid' => '350700',
    'parentids' => '350000,350700,350783',
    'level' => '3',
    'name' => '建瓯市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1351 => 
  array (
    'id' => '350784',
    'parentid' => '350700',
    'parentids' => '350000,350700,350784',
    'level' => '3',
    'name' => '建阳市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1352 => 
  array (
    'id' => '350800',
    'parentid' => '350000',
    'parentids' => '350000,350800',
    'level' => '2',
    'name' => '龙岩市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1353 => 
  array (
    'id' => '350801',
    'parentid' => '350800',
    'parentids' => '350000,350800,350801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1354 => 
  array (
    'id' => '350802',
    'parentid' => '350800',
    'parentids' => '350000,350800,350802',
    'level' => '3',
    'name' => '新罗区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1355 => 
  array (
    'id' => '350821',
    'parentid' => '350800',
    'parentids' => '350000,350800,350821',
    'level' => '3',
    'name' => '长汀县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1356 => 
  array (
    'id' => '350822',
    'parentid' => '350800',
    'parentids' => '350000,350800,350822',
    'level' => '3',
    'name' => '永定县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1357 => 
  array (
    'id' => '350823',
    'parentid' => '350800',
    'parentids' => '350000,350800,350823',
    'level' => '3',
    'name' => '上杭县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1358 => 
  array (
    'id' => '350824',
    'parentid' => '350800',
    'parentids' => '350000,350800,350824',
    'level' => '3',
    'name' => '武平县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1359 => 
  array (
    'id' => '350825',
    'parentid' => '350800',
    'parentids' => '350000,350800,350825',
    'level' => '3',
    'name' => '连城县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1360 => 
  array (
    'id' => '350881',
    'parentid' => '350800',
    'parentids' => '350000,350800,350881',
    'level' => '3',
    'name' => '漳平市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1361 => 
  array (
    'id' => '350900',
    'parentid' => '350000',
    'parentids' => '350000,350900',
    'level' => '2',
    'name' => '宁德市',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1362 => 
  array (
    'id' => '350901',
    'parentid' => '350900',
    'parentids' => '350000,350900,350901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1363 => 
  array (
    'id' => '350902',
    'parentid' => '350900',
    'parentids' => '350000,350900,350902',
    'level' => '3',
    'name' => '蕉城区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1364 => 
  array (
    'id' => '350921',
    'parentid' => '350900',
    'parentids' => '350000,350900,350921',
    'level' => '3',
    'name' => '霞浦县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1365 => 
  array (
    'id' => '350922',
    'parentid' => '350900',
    'parentids' => '350000,350900,350922',
    'level' => '3',
    'name' => '古田县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1366 => 
  array (
    'id' => '350923',
    'parentid' => '350900',
    'parentids' => '350000,350900,350923',
    'level' => '3',
    'name' => '屏南县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1367 => 
  array (
    'id' => '350924',
    'parentid' => '350900',
    'parentids' => '350000,350900,350924',
    'level' => '3',
    'name' => '寿宁县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1368 => 
  array (
    'id' => '350925',
    'parentid' => '350900',
    'parentids' => '350000,350900,350925',
    'level' => '3',
    'name' => '周宁县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1369 => 
  array (
    'id' => '350926',
    'parentid' => '350900',
    'parentids' => '350000,350900,350926',
    'level' => '3',
    'name' => '柘荣县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  1370 => 
  array (
    'id' => '350981',
    'parentid' => '350900',
    'parentids' => '350000,350900,350981',
    'level' => '3',
    'name' => '福安市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1371 => 
  array (
    'id' => '350982',
    'parentid' => '350900',
    'parentids' => '350000,350900,350982',
    'level' => '3',
    'name' => '福鼎市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1372 => 
  array (
    'id' => '360000',
    'parentid' => '0',
    'parentids' => '360000',
    'level' => '1',
    'name' => '江西省',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1373 => 
  array (
    'id' => '360100',
    'parentid' => '360000',
    'parentids' => '360000,360100',
    'level' => '2',
    'name' => '南昌市',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1374 => 
  array (
    'id' => '360101',
    'parentid' => '360100',
    'parentids' => '360000,360100,360101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1375 => 
  array (
    'id' => '360102',
    'parentid' => '360100',
    'parentids' => '360000,360100,360102',
    'level' => '3',
    'name' => '东湖区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1376 => 
  array (
    'id' => '360103',
    'parentid' => '360100',
    'parentids' => '360000,360100,360103',
    'level' => '3',
    'name' => '西湖区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1377 => 
  array (
    'id' => '360104',
    'parentid' => '360100',
    'parentids' => '360000,360100,360104',
    'level' => '3',
    'name' => '青云谱区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1378 => 
  array (
    'id' => '360105',
    'parentid' => '360100',
    'parentids' => '360000,360100,360105',
    'level' => '3',
    'name' => '湾里区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1379 => 
  array (
    'id' => '360111',
    'parentid' => '360100',
    'parentids' => '360000,360100,360111',
    'level' => '3',
    'name' => '青山湖区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1380 => 
  array (
    'id' => '360121',
    'parentid' => '360100',
    'parentids' => '360000,360100,360121',
    'level' => '3',
    'name' => '南昌县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1381 => 
  array (
    'id' => '360122',
    'parentid' => '360100',
    'parentids' => '360000,360100,360122',
    'level' => '3',
    'name' => '新建县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1382 => 
  array (
    'id' => '360123',
    'parentid' => '360100',
    'parentids' => '360000,360100,360123',
    'level' => '3',
    'name' => '安义县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  1383 => 
  array (
    'id' => '360124',
    'parentid' => '360100',
    'parentids' => '360000,360100,360124',
    'level' => '3',
    'name' => '进贤县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1384 => 
  array (
    'id' => '360200',
    'parentid' => '360000',
    'parentids' => '360000,360200',
    'level' => '2',
    'name' => '景德镇市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1385 => 
  array (
    'id' => '360201',
    'parentid' => '360200',
    'parentids' => '360000,360200,360201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1386 => 
  array (
    'id' => '360202',
    'parentid' => '360200',
    'parentids' => '360000,360200,360202',
    'level' => '3',
    'name' => '昌江区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1387 => 
  array (
    'id' => '360203',
    'parentid' => '360200',
    'parentids' => '360000,360200,360203',
    'level' => '3',
    'name' => '珠山区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1388 => 
  array (
    'id' => '360222',
    'parentid' => '360200',
    'parentids' => '360000,360200,360222',
    'level' => '3',
    'name' => '浮梁县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1389 => 
  array (
    'id' => '360281',
    'parentid' => '360200',
    'parentids' => '360000,360200,360281',
    'level' => '3',
    'name' => '乐平市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1390 => 
  array (
    'id' => '360300',
    'parentid' => '360000',
    'parentids' => '360000,360300',
    'level' => '2',
    'name' => '萍乡市',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1391 => 
  array (
    'id' => '360301',
    'parentid' => '360300',
    'parentids' => '360000,360300,360301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1392 => 
  array (
    'id' => '360302',
    'parentid' => '360300',
    'parentids' => '360000,360300,360302',
    'level' => '3',
    'name' => '安源区',
    'letter' => 'a',
    'listorder' => '0',
  ),
  1393 => 
  array (
    'id' => '360313',
    'parentid' => '360300',
    'parentids' => '360000,360300,360313',
    'level' => '3',
    'name' => '湘东区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1394 => 
  array (
    'id' => '360321',
    'parentid' => '360300',
    'parentids' => '360000,360300,360321',
    'level' => '3',
    'name' => '莲花县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1395 => 
  array (
    'id' => '360322',
    'parentid' => '360300',
    'parentids' => '360000,360300,360322',
    'level' => '3',
    'name' => '上栗县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1396 => 
  array (
    'id' => '360323',
    'parentid' => '360300',
    'parentids' => '360000,360300,360323',
    'level' => '3',
    'name' => '芦溪县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1397 => 
  array (
    'id' => '360400',
    'parentid' => '360000',
    'parentids' => '360000,360400',
    'level' => '2',
    'name' => '九江市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1398 => 
  array (
    'id' => '360401',
    'parentid' => '360400',
    'parentids' => '360000,360400,360401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1399 => 
  array (
    'id' => '360402',
    'parentid' => '360400',
    'parentids' => '360000,360400,360402',
    'level' => '3',
    'name' => '庐山区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1400 => 
  array (
    'id' => '360403',
    'parentid' => '360400',
    'parentids' => '360000,360400,360403',
    'level' => '3',
    'name' => '浔阳区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1401 => 
  array (
    'id' => '360421',
    'parentid' => '360400',
    'parentids' => '360000,360400,360421',
    'level' => '3',
    'name' => '九江县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1402 => 
  array (
    'id' => '360423',
    'parentid' => '360400',
    'parentids' => '360000,360400,360423',
    'level' => '3',
    'name' => '武宁县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1403 => 
  array (
    'id' => '360424',
    'parentid' => '360400',
    'parentids' => '360000,360400,360424',
    'level' => '3',
    'name' => '修水县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1404 => 
  array (
    'id' => '360425',
    'parentid' => '360400',
    'parentids' => '360000,360400,360425',
    'level' => '3',
    'name' => '永修县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1405 => 
  array (
    'id' => '360426',
    'parentid' => '360400',
    'parentids' => '360000,360400,360426',
    'level' => '3',
    'name' => '德安县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1406 => 
  array (
    'id' => '360427',
    'parentid' => '360400',
    'parentids' => '360000,360400,360427',
    'level' => '3',
    'name' => '星子县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1407 => 
  array (
    'id' => '360428',
    'parentid' => '360400',
    'parentids' => '360000,360400,360428',
    'level' => '3',
    'name' => '都昌县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1408 => 
  array (
    'id' => '360429',
    'parentid' => '360400',
    'parentids' => '360000,360400,360429',
    'level' => '3',
    'name' => '湖口县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1409 => 
  array (
    'id' => '360430',
    'parentid' => '360400',
    'parentids' => '360000,360400,360430',
    'level' => '3',
    'name' => '彭泽县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1410 => 
  array (
    'id' => '360481',
    'parentid' => '360400',
    'parentids' => '360000,360400,360481',
    'level' => '3',
    'name' => '瑞昌市',
    'letter' => 'r',
    'listorder' => '0',
  ),
  1411 => 
  array (
    'id' => '360500',
    'parentid' => '360000',
    'parentids' => '360000,360500',
    'level' => '2',
    'name' => '新余市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1412 => 
  array (
    'id' => '360501',
    'parentid' => '360500',
    'parentids' => '360000,360500,360501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1413 => 
  array (
    'id' => '360502',
    'parentid' => '360500',
    'parentids' => '360000,360500,360502',
    'level' => '3',
    'name' => '渝水区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1414 => 
  array (
    'id' => '360521',
    'parentid' => '360500',
    'parentids' => '360000,360500,360521',
    'level' => '3',
    'name' => '分宜县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1415 => 
  array (
    'id' => '360600',
    'parentid' => '360000',
    'parentids' => '360000,360600',
    'level' => '2',
    'name' => '鹰潭市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1416 => 
  array (
    'id' => '360601',
    'parentid' => '360600',
    'parentids' => '360000,360600,360601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1417 => 
  array (
    'id' => '360602',
    'parentid' => '360600',
    'parentids' => '360000,360600,360602',
    'level' => '3',
    'name' => '月湖区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1418 => 
  array (
    'id' => '360622',
    'parentid' => '360600',
    'parentids' => '360000,360600,360622',
    'level' => '3',
    'name' => '余江县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1419 => 
  array (
    'id' => '360681',
    'parentid' => '360600',
    'parentids' => '360000,360600,360681',
    'level' => '3',
    'name' => '贵溪市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1420 => 
  array (
    'id' => '360700',
    'parentid' => '360000',
    'parentids' => '360000,360700',
    'level' => '2',
    'name' => '赣州市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1421 => 
  array (
    'id' => '360701',
    'parentid' => '360700',
    'parentids' => '360000,360700,360701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1422 => 
  array (
    'id' => '360702',
    'parentid' => '360700',
    'parentids' => '360000,360700,360702',
    'level' => '3',
    'name' => '章贡区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1423 => 
  array (
    'id' => '360721',
    'parentid' => '360700',
    'parentids' => '360000,360700,360721',
    'level' => '3',
    'name' => '赣　县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1424 => 
  array (
    'id' => '360722',
    'parentid' => '360700',
    'parentids' => '360000,360700,360722',
    'level' => '3',
    'name' => '信丰县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1425 => 
  array (
    'id' => '360723',
    'parentid' => '360700',
    'parentids' => '360000,360700,360723',
    'level' => '3',
    'name' => '大余县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1426 => 
  array (
    'id' => '360724',
    'parentid' => '360700',
    'parentids' => '360000,360700,360724',
    'level' => '3',
    'name' => '上犹县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1427 => 
  array (
    'id' => '360725',
    'parentid' => '360700',
    'parentids' => '360000,360700,360725',
    'level' => '3',
    'name' => '崇义县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1428 => 
  array (
    'id' => '360726',
    'parentid' => '360700',
    'parentids' => '360000,360700,360726',
    'level' => '3',
    'name' => '安远县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  1429 => 
  array (
    'id' => '360727',
    'parentid' => '360700',
    'parentids' => '360000,360700,360727',
    'level' => '3',
    'name' => '龙南县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1430 => 
  array (
    'id' => '360728',
    'parentid' => '360700',
    'parentids' => '360000,360700,360728',
    'level' => '3',
    'name' => '定南县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1431 => 
  array (
    'id' => '360729',
    'parentid' => '360700',
    'parentids' => '360000,360700,360729',
    'level' => '3',
    'name' => '全南县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1432 => 
  array (
    'id' => '360730',
    'parentid' => '360700',
    'parentids' => '360000,360700,360730',
    'level' => '3',
    'name' => '宁都县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1433 => 
  array (
    'id' => '360731',
    'parentid' => '360700',
    'parentids' => '360000,360700,360731',
    'level' => '3',
    'name' => '于都县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1434 => 
  array (
    'id' => '360732',
    'parentid' => '360700',
    'parentids' => '360000,360700,360732',
    'level' => '3',
    'name' => '兴国县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1435 => 
  array (
    'id' => '360733',
    'parentid' => '360700',
    'parentids' => '360000,360700,360733',
    'level' => '3',
    'name' => '会昌县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1436 => 
  array (
    'id' => '360734',
    'parentid' => '360700',
    'parentids' => '360000,360700,360734',
    'level' => '3',
    'name' => '寻乌县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1437 => 
  array (
    'id' => '360735',
    'parentid' => '360700',
    'parentids' => '360000,360700,360735',
    'level' => '3',
    'name' => '石城县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1438 => 
  array (
    'id' => '360781',
    'parentid' => '360700',
    'parentids' => '360000,360700,360781',
    'level' => '3',
    'name' => '瑞金市',
    'letter' => 'r',
    'listorder' => '0',
  ),
  1439 => 
  array (
    'id' => '360782',
    'parentid' => '360700',
    'parentids' => '360000,360700,360782',
    'level' => '3',
    'name' => '南康市',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1440 => 
  array (
    'id' => '360800',
    'parentid' => '360000',
    'parentids' => '360000,360800',
    'level' => '2',
    'name' => '吉安市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1441 => 
  array (
    'id' => '360801',
    'parentid' => '360800',
    'parentids' => '360000,360800,360801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1442 => 
  array (
    'id' => '360802',
    'parentid' => '360800',
    'parentids' => '360000,360800,360802',
    'level' => '3',
    'name' => '吉州区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1443 => 
  array (
    'id' => '360803',
    'parentid' => '360800',
    'parentids' => '360000,360800,360803',
    'level' => '3',
    'name' => '青原区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1444 => 
  array (
    'id' => '360821',
    'parentid' => '360800',
    'parentids' => '360000,360800,360821',
    'level' => '3',
    'name' => '吉安县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1445 => 
  array (
    'id' => '360822',
    'parentid' => '360800',
    'parentids' => '360000,360800,360822',
    'level' => '3',
    'name' => '吉水县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1446 => 
  array (
    'id' => '360823',
    'parentid' => '360800',
    'parentids' => '360000,360800,360823',
    'level' => '3',
    'name' => '峡江县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1447 => 
  array (
    'id' => '360824',
    'parentid' => '360800',
    'parentids' => '360000,360800,360824',
    'level' => '3',
    'name' => '新干县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1448 => 
  array (
    'id' => '360825',
    'parentid' => '360800',
    'parentids' => '360000,360800,360825',
    'level' => '3',
    'name' => '永丰县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1449 => 
  array (
    'id' => '360826',
    'parentid' => '360800',
    'parentids' => '360000,360800,360826',
    'level' => '3',
    'name' => '泰和县',
    'letter' => 't',
    'listorder' => '0',
  ),
  1450 => 
  array (
    'id' => '360827',
    'parentid' => '360800',
    'parentids' => '360000,360800,360827',
    'level' => '3',
    'name' => '遂川县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1451 => 
  array (
    'id' => '360828',
    'parentid' => '360800',
    'parentids' => '360000,360800,360828',
    'level' => '3',
    'name' => '万安县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1452 => 
  array (
    'id' => '360829',
    'parentid' => '360800',
    'parentids' => '360000,360800,360829',
    'level' => '3',
    'name' => '安福县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  1453 => 
  array (
    'id' => '360830',
    'parentid' => '360800',
    'parentids' => '360000,360800,360830',
    'level' => '3',
    'name' => '永新县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1454 => 
  array (
    'id' => '360881',
    'parentid' => '360800',
    'parentids' => '360000,360800,360881',
    'level' => '3',
    'name' => '井冈山市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1455 => 
  array (
    'id' => '360900',
    'parentid' => '360000',
    'parentids' => '360000,360900',
    'level' => '2',
    'name' => '宜春市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1456 => 
  array (
    'id' => '360901',
    'parentid' => '360900',
    'parentids' => '360000,360900,360901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1457 => 
  array (
    'id' => '360902',
    'parentid' => '360900',
    'parentids' => '360000,360900,360902',
    'level' => '3',
    'name' => '袁州区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1458 => 
  array (
    'id' => '360921',
    'parentid' => '360900',
    'parentids' => '360000,360900,360921',
    'level' => '3',
    'name' => '奉新县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1459 => 
  array (
    'id' => '360922',
    'parentid' => '360900',
    'parentids' => '360000,360900,360922',
    'level' => '3',
    'name' => '万载县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1460 => 
  array (
    'id' => '360923',
    'parentid' => '360900',
    'parentids' => '360000,360900,360923',
    'level' => '3',
    'name' => '上高县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1461 => 
  array (
    'id' => '360924',
    'parentid' => '360900',
    'parentids' => '360000,360900,360924',
    'level' => '3',
    'name' => '宜丰县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1462 => 
  array (
    'id' => '360925',
    'parentid' => '360900',
    'parentids' => '360000,360900,360925',
    'level' => '3',
    'name' => '靖安县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1463 => 
  array (
    'id' => '360926',
    'parentid' => '360900',
    'parentids' => '360000,360900,360926',
    'level' => '3',
    'name' => '铜鼓县',
    'letter' => 't',
    'listorder' => '0',
  ),
  1464 => 
  array (
    'id' => '360981',
    'parentid' => '360900',
    'parentids' => '360000,360900,360981',
    'level' => '3',
    'name' => '丰城市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1465 => 
  array (
    'id' => '360982',
    'parentid' => '360900',
    'parentids' => '360000,360900,360982',
    'level' => '3',
    'name' => '樟树市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1466 => 
  array (
    'id' => '360983',
    'parentid' => '360900',
    'parentids' => '360000,360900,360983',
    'level' => '3',
    'name' => '高安市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1467 => 
  array (
    'id' => '361000',
    'parentid' => '360000',
    'parentids' => '360000,361000',
    'level' => '2',
    'name' => '抚州市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1468 => 
  array (
    'id' => '361001',
    'parentid' => '361000',
    'parentids' => '360000,361000,361001',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1469 => 
  array (
    'id' => '361002',
    'parentid' => '361000',
    'parentids' => '360000,361000,361002',
    'level' => '3',
    'name' => '临川区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1470 => 
  array (
    'id' => '361021',
    'parentid' => '361000',
    'parentids' => '360000,361000,361021',
    'level' => '3',
    'name' => '南城县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1471 => 
  array (
    'id' => '361022',
    'parentid' => '361000',
    'parentids' => '360000,361000,361022',
    'level' => '3',
    'name' => '黎川县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1472 => 
  array (
    'id' => '361023',
    'parentid' => '361000',
    'parentids' => '360000,361000,361023',
    'level' => '3',
    'name' => '南丰县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1473 => 
  array (
    'id' => '361024',
    'parentid' => '361000',
    'parentids' => '360000,361000,361024',
    'level' => '3',
    'name' => '崇仁县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1474 => 
  array (
    'id' => '361025',
    'parentid' => '361000',
    'parentids' => '360000,361000,361025',
    'level' => '3',
    'name' => '乐安县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1475 => 
  array (
    'id' => '361026',
    'parentid' => '361000',
    'parentids' => '360000,361000,361026',
    'level' => '3',
    'name' => '宜黄县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1476 => 
  array (
    'id' => '361027',
    'parentid' => '361000',
    'parentids' => '360000,361000,361027',
    'level' => '3',
    'name' => '金溪县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1477 => 
  array (
    'id' => '361028',
    'parentid' => '361000',
    'parentids' => '360000,361000,361028',
    'level' => '3',
    'name' => '资溪县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1478 => 
  array (
    'id' => '361029',
    'parentid' => '361000',
    'parentids' => '360000,361000,361029',
    'level' => '3',
    'name' => '东乡县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1479 => 
  array (
    'id' => '361030',
    'parentid' => '361000',
    'parentids' => '360000,361000,361030',
    'level' => '3',
    'name' => '广昌县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1480 => 
  array (
    'id' => '361100',
    'parentid' => '360000',
    'parentids' => '360000,361100',
    'level' => '2',
    'name' => '上饶市',
    'letter' => 's',
    'listorder' => '0',
  ),
  1481 => 
  array (
    'id' => '361101',
    'parentid' => '361100',
    'parentids' => '360000,361100,361101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1482 => 
  array (
    'id' => '361102',
    'parentid' => '361100',
    'parentids' => '360000,361100,361102',
    'level' => '3',
    'name' => '信州区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1483 => 
  array (
    'id' => '361121',
    'parentid' => '361100',
    'parentids' => '360000,361100,361121',
    'level' => '3',
    'name' => '上饶县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1484 => 
  array (
    'id' => '361122',
    'parentid' => '361100',
    'parentids' => '360000,361100,361122',
    'level' => '3',
    'name' => '广丰县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1485 => 
  array (
    'id' => '361123',
    'parentid' => '361100',
    'parentids' => '360000,361100,361123',
    'level' => '3',
    'name' => '玉山县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1486 => 
  array (
    'id' => '361124',
    'parentid' => '361100',
    'parentids' => '360000,361100,361124',
    'level' => '3',
    'name' => '铅山县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1487 => 
  array (
    'id' => '361125',
    'parentid' => '361100',
    'parentids' => '360000,361100,361125',
    'level' => '3',
    'name' => '横峰县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1488 => 
  array (
    'id' => '361126',
    'parentid' => '361100',
    'parentids' => '360000,361100,361126',
    'level' => '3',
    'name' => '弋阳县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1489 => 
  array (
    'id' => '361127',
    'parentid' => '361100',
    'parentids' => '360000,361100,361127',
    'level' => '3',
    'name' => '余干县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1490 => 
  array (
    'id' => '361128',
    'parentid' => '361100',
    'parentids' => '360000,361100,361128',
    'level' => '3',
    'name' => '鄱阳县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1491 => 
  array (
    'id' => '361129',
    'parentid' => '361100',
    'parentids' => '360000,361100,361129',
    'level' => '3',
    'name' => '万年县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1492 => 
  array (
    'id' => '361130',
    'parentid' => '361100',
    'parentids' => '360000,361100,361130',
    'level' => '3',
    'name' => '婺源县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1493 => 
  array (
    'id' => '361181',
    'parentid' => '361100',
    'parentids' => '360000,361100,361181',
    'level' => '3',
    'name' => '德兴市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1494 => 
  array (
    'id' => '370000',
    'parentid' => '0',
    'parentids' => '370000',
    'level' => '1',
    'name' => '山东省',
    'letter' => 's',
    'listorder' => '0',
  ),
  1495 => 
  array (
    'id' => '370100',
    'parentid' => '370000',
    'parentids' => '370000,370100',
    'level' => '2',
    'name' => '济南市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1496 => 
  array (
    'id' => '370101',
    'parentid' => '370100',
    'parentids' => '370000,370100,370101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1497 => 
  array (
    'id' => '370102',
    'parentid' => '370100',
    'parentids' => '370000,370100,370102',
    'level' => '3',
    'name' => '历下区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1498 => 
  array (
    'id' => '370103',
    'parentid' => '370100',
    'parentids' => '370000,370100,370103',
    'level' => '3',
    'name' => '市中区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1499 => 
  array (
    'id' => '370104',
    'parentid' => '370100',
    'parentids' => '370000,370100,370104',
    'level' => '3',
    'name' => '槐荫区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1500 => 
  array (
    'id' => '370105',
    'parentid' => '370100',
    'parentids' => '370000,370100,370105',
    'level' => '3',
    'name' => '天桥区',
    'letter' => 't',
    'listorder' => '0',
  ),
  1501 => 
  array (
    'id' => '370112',
    'parentid' => '370100',
    'parentids' => '370000,370100,370112',
    'level' => '3',
    'name' => '历城区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1502 => 
  array (
    'id' => '370113',
    'parentid' => '370100',
    'parentids' => '370000,370100,370113',
    'level' => '3',
    'name' => '长清区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1503 => 
  array (
    'id' => '370124',
    'parentid' => '370100',
    'parentids' => '370000,370100,370124',
    'level' => '3',
    'name' => '平阴县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1504 => 
  array (
    'id' => '370125',
    'parentid' => '370100',
    'parentids' => '370000,370100,370125',
    'level' => '3',
    'name' => '济阳县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1505 => 
  array (
    'id' => '370126',
    'parentid' => '370100',
    'parentids' => '370000,370100,370126',
    'level' => '3',
    'name' => '商河县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1506 => 
  array (
    'id' => '370181',
    'parentid' => '370100',
    'parentids' => '370000,370100,370181',
    'level' => '3',
    'name' => '章丘市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1507 => 
  array (
    'id' => '370200',
    'parentid' => '370000',
    'parentids' => '370000,370200',
    'level' => '2',
    'name' => '青岛市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1508 => 
  array (
    'id' => '370201',
    'parentid' => '370200',
    'parentids' => '370000,370200,370201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1509 => 
  array (
    'id' => '370202',
    'parentid' => '370200',
    'parentids' => '370000,370200,370202',
    'level' => '3',
    'name' => '市南区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1510 => 
  array (
    'id' => '370203',
    'parentid' => '370200',
    'parentids' => '370000,370200,370203',
    'level' => '3',
    'name' => '市北区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1511 => 
  array (
    'id' => '370205',
    'parentid' => '370200',
    'parentids' => '370000,370200,370205',
    'level' => '3',
    'name' => '四方区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1512 => 
  array (
    'id' => '370211',
    'parentid' => '370200',
    'parentids' => '370000,370200,370211',
    'level' => '3',
    'name' => '黄岛区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1513 => 
  array (
    'id' => '370212',
    'parentid' => '370200',
    'parentids' => '370000,370200,370212',
    'level' => '3',
    'name' => '崂山区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1514 => 
  array (
    'id' => '370213',
    'parentid' => '370200',
    'parentids' => '370000,370200,370213',
    'level' => '3',
    'name' => '李沧区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1515 => 
  array (
    'id' => '370214',
    'parentid' => '370200',
    'parentids' => '370000,370200,370214',
    'level' => '3',
    'name' => '城阳区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1516 => 
  array (
    'id' => '370281',
    'parentid' => '370200',
    'parentids' => '370000,370200,370281',
    'level' => '3',
    'name' => '胶州市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1517 => 
  array (
    'id' => '370282',
    'parentid' => '370200',
    'parentids' => '370000,370200,370282',
    'level' => '3',
    'name' => '即墨市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1518 => 
  array (
    'id' => '370283',
    'parentid' => '370200',
    'parentids' => '370000,370200,370283',
    'level' => '3',
    'name' => '平度市',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1519 => 
  array (
    'id' => '370284',
    'parentid' => '370200',
    'parentids' => '370000,370200,370284',
    'level' => '3',
    'name' => '胶南市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1520 => 
  array (
    'id' => '370285',
    'parentid' => '370200',
    'parentids' => '370000,370200,370285',
    'level' => '3',
    'name' => '莱西市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1521 => 
  array (
    'id' => '370300',
    'parentid' => '370000',
    'parentids' => '370000,370300',
    'level' => '2',
    'name' => '淄博市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1522 => 
  array (
    'id' => '370301',
    'parentid' => '370300',
    'parentids' => '370000,370300,370301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1523 => 
  array (
    'id' => '370302',
    'parentid' => '370300',
    'parentids' => '370000,370300,370302',
    'level' => '3',
    'name' => '淄川区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1524 => 
  array (
    'id' => '370303',
    'parentid' => '370300',
    'parentids' => '370000,370300,370303',
    'level' => '3',
    'name' => '张店区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1525 => 
  array (
    'id' => '370304',
    'parentid' => '370300',
    'parentids' => '370000,370300,370304',
    'level' => '3',
    'name' => '博山区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  1526 => 
  array (
    'id' => '370305',
    'parentid' => '370300',
    'parentids' => '370000,370300,370305',
    'level' => '3',
    'name' => '临淄区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1527 => 
  array (
    'id' => '370306',
    'parentid' => '370300',
    'parentids' => '370000,370300,370306',
    'level' => '3',
    'name' => '周村区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1528 => 
  array (
    'id' => '370321',
    'parentid' => '370300',
    'parentids' => '370000,370300,370321',
    'level' => '3',
    'name' => '桓台县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1529 => 
  array (
    'id' => '370322',
    'parentid' => '370300',
    'parentids' => '370000,370300,370322',
    'level' => '3',
    'name' => '高青县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1530 => 
  array (
    'id' => '370323',
    'parentid' => '370300',
    'parentids' => '370000,370300,370323',
    'level' => '3',
    'name' => '沂源县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1531 => 
  array (
    'id' => '370400',
    'parentid' => '370000',
    'parentids' => '370000,370400',
    'level' => '2',
    'name' => '枣庄市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1532 => 
  array (
    'id' => '370401',
    'parentid' => '370400',
    'parentids' => '370000,370400,370401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1533 => 
  array (
    'id' => '370402',
    'parentid' => '370400',
    'parentids' => '370000,370400,370402',
    'level' => '3',
    'name' => '市中区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1534 => 
  array (
    'id' => '370403',
    'parentid' => '370400',
    'parentids' => '370000,370400,370403',
    'level' => '3',
    'name' => '薛城区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1535 => 
  array (
    'id' => '370404',
    'parentid' => '370400',
    'parentids' => '370000,370400,370404',
    'level' => '3',
    'name' => '峄城区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1536 => 
  array (
    'id' => '370405',
    'parentid' => '370400',
    'parentids' => '370000,370400,370405',
    'level' => '3',
    'name' => '台儿庄区',
    'letter' => 't',
    'listorder' => '0',
  ),
  1537 => 
  array (
    'id' => '370406',
    'parentid' => '370400',
    'parentids' => '370000,370400,370406',
    'level' => '3',
    'name' => '山亭区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1538 => 
  array (
    'id' => '370481',
    'parentid' => '370400',
    'parentids' => '370000,370400,370481',
    'level' => '3',
    'name' => '滕州市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1539 => 
  array (
    'id' => '370500',
    'parentid' => '370000',
    'parentids' => '370000,370500',
    'level' => '2',
    'name' => '东营市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1540 => 
  array (
    'id' => '370501',
    'parentid' => '370500',
    'parentids' => '370000,370500,370501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1541 => 
  array (
    'id' => '370502',
    'parentid' => '370500',
    'parentids' => '370000,370500,370502',
    'level' => '3',
    'name' => '东营区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1542 => 
  array (
    'id' => '370503',
    'parentid' => '370500',
    'parentids' => '370000,370500,370503',
    'level' => '3',
    'name' => '河口区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1543 => 
  array (
    'id' => '370521',
    'parentid' => '370500',
    'parentids' => '370000,370500,370521',
    'level' => '3',
    'name' => '垦利县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  1544 => 
  array (
    'id' => '370522',
    'parentid' => '370500',
    'parentids' => '370000,370500,370522',
    'level' => '3',
    'name' => '利津县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1545 => 
  array (
    'id' => '370523',
    'parentid' => '370500',
    'parentids' => '370000,370500,370523',
    'level' => '3',
    'name' => '广饶县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1546 => 
  array (
    'id' => '370600',
    'parentid' => '370000',
    'parentids' => '370000,370600',
    'level' => '2',
    'name' => '烟台市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1547 => 
  array (
    'id' => '370601',
    'parentid' => '370600',
    'parentids' => '370000,370600,370601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1548 => 
  array (
    'id' => '370602',
    'parentid' => '370600',
    'parentids' => '370000,370600,370602',
    'level' => '3',
    'name' => '芝罘区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1549 => 
  array (
    'id' => '370611',
    'parentid' => '370600',
    'parentids' => '370000,370600,370611',
    'level' => '3',
    'name' => '福山区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1550 => 
  array (
    'id' => '370612',
    'parentid' => '370600',
    'parentids' => '370000,370600,370612',
    'level' => '3',
    'name' => '牟平区',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1551 => 
  array (
    'id' => '370613',
    'parentid' => '370600',
    'parentids' => '370000,370600,370613',
    'level' => '3',
    'name' => '莱山区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1552 => 
  array (
    'id' => '370634',
    'parentid' => '370600',
    'parentids' => '370000,370600,370634',
    'level' => '3',
    'name' => '长岛县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1553 => 
  array (
    'id' => '370681',
    'parentid' => '370600',
    'parentids' => '370000,370600,370681',
    'level' => '3',
    'name' => '龙口市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1554 => 
  array (
    'id' => '370682',
    'parentid' => '370600',
    'parentids' => '370000,370600,370682',
    'level' => '3',
    'name' => '莱阳市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1555 => 
  array (
    'id' => '370683',
    'parentid' => '370600',
    'parentids' => '370000,370600,370683',
    'level' => '3',
    'name' => '莱州市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1556 => 
  array (
    'id' => '370684',
    'parentid' => '370600',
    'parentids' => '370000,370600,370684',
    'level' => '3',
    'name' => '蓬莱市',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1557 => 
  array (
    'id' => '370685',
    'parentid' => '370600',
    'parentids' => '370000,370600,370685',
    'level' => '3',
    'name' => '招远市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1558 => 
  array (
    'id' => '370686',
    'parentid' => '370600',
    'parentids' => '370000,370600,370686',
    'level' => '3',
    'name' => '栖霞市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1559 => 
  array (
    'id' => '370687',
    'parentid' => '370600',
    'parentids' => '370000,370600,370687',
    'level' => '3',
    'name' => '海阳市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1560 => 
  array (
    'id' => '370700',
    'parentid' => '370000',
    'parentids' => '370000,370700',
    'level' => '2',
    'name' => '潍坊市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1561 => 
  array (
    'id' => '370701',
    'parentid' => '370700',
    'parentids' => '370000,370700,370701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1562 => 
  array (
    'id' => '370702',
    'parentid' => '370700',
    'parentids' => '370000,370700,370702',
    'level' => '3',
    'name' => '潍城区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1563 => 
  array (
    'id' => '370703',
    'parentid' => '370700',
    'parentids' => '370000,370700,370703',
    'level' => '3',
    'name' => '寒亭区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1564 => 
  array (
    'id' => '370704',
    'parentid' => '370700',
    'parentids' => '370000,370700,370704',
    'level' => '3',
    'name' => '坊子区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1565 => 
  array (
    'id' => '370705',
    'parentid' => '370700',
    'parentids' => '370000,370700,370705',
    'level' => '3',
    'name' => '奎文区',
    'letter' => 'k',
    'listorder' => '0',
  ),
  1566 => 
  array (
    'id' => '370724',
    'parentid' => '370700',
    'parentids' => '370000,370700,370724',
    'level' => '3',
    'name' => '临朐县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1567 => 
  array (
    'id' => '370725',
    'parentid' => '370700',
    'parentids' => '370000,370700,370725',
    'level' => '3',
    'name' => '昌乐县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1568 => 
  array (
    'id' => '370781',
    'parentid' => '370700',
    'parentids' => '370000,370700,370781',
    'level' => '3',
    'name' => '青州市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1569 => 
  array (
    'id' => '370782',
    'parentid' => '370700',
    'parentids' => '370000,370700,370782',
    'level' => '3',
    'name' => '诸城市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1570 => 
  array (
    'id' => '370783',
    'parentid' => '370700',
    'parentids' => '370000,370700,370783',
    'level' => '3',
    'name' => '寿光市',
    'letter' => 's',
    'listorder' => '0',
  ),
  1571 => 
  array (
    'id' => '370784',
    'parentid' => '370700',
    'parentids' => '370000,370700,370784',
    'level' => '3',
    'name' => '安丘市',
    'letter' => 'a',
    'listorder' => '0',
  ),
  1572 => 
  array (
    'id' => '370785',
    'parentid' => '370700',
    'parentids' => '370000,370700,370785',
    'level' => '3',
    'name' => '高密市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1573 => 
  array (
    'id' => '370786',
    'parentid' => '370700',
    'parentids' => '370000,370700,370786',
    'level' => '3',
    'name' => '昌邑市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1574 => 
  array (
    'id' => '370800',
    'parentid' => '370000',
    'parentids' => '370000,370800',
    'level' => '2',
    'name' => '济宁市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1575 => 
  array (
    'id' => '370801',
    'parentid' => '370800',
    'parentids' => '370000,370800,370801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1576 => 
  array (
    'id' => '370802',
    'parentid' => '370800',
    'parentids' => '370000,370800,370802',
    'level' => '3',
    'name' => '市中区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1577 => 
  array (
    'id' => '370811',
    'parentid' => '370800',
    'parentids' => '370000,370800,370811',
    'level' => '3',
    'name' => '任城区',
    'letter' => 'r',
    'listorder' => '0',
  ),
  1578 => 
  array (
    'id' => '370826',
    'parentid' => '370800',
    'parentids' => '370000,370800,370826',
    'level' => '3',
    'name' => '微山县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1579 => 
  array (
    'id' => '370827',
    'parentid' => '370800',
    'parentids' => '370000,370800,370827',
    'level' => '3',
    'name' => '鱼台县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1580 => 
  array (
    'id' => '370828',
    'parentid' => '370800',
    'parentids' => '370000,370800,370828',
    'level' => '3',
    'name' => '金乡县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1581 => 
  array (
    'id' => '370829',
    'parentid' => '370800',
    'parentids' => '370000,370800,370829',
    'level' => '3',
    'name' => '嘉祥县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1582 => 
  array (
    'id' => '370830',
    'parentid' => '370800',
    'parentids' => '370000,370800,370830',
    'level' => '3',
    'name' => '汶上县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1583 => 
  array (
    'id' => '370831',
    'parentid' => '370800',
    'parentids' => '370000,370800,370831',
    'level' => '3',
    'name' => '泗水县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1584 => 
  array (
    'id' => '370832',
    'parentid' => '370800',
    'parentids' => '370000,370800,370832',
    'level' => '3',
    'name' => '梁山县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1585 => 
  array (
    'id' => '370881',
    'parentid' => '370800',
    'parentids' => '370000,370800,370881',
    'level' => '3',
    'name' => '曲阜市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1586 => 
  array (
    'id' => '370882',
    'parentid' => '370800',
    'parentids' => '370000,370800,370882',
    'level' => '3',
    'name' => '兖州市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1587 => 
  array (
    'id' => '370883',
    'parentid' => '370800',
    'parentids' => '370000,370800,370883',
    'level' => '3',
    'name' => '邹城市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1588 => 
  array (
    'id' => '370900',
    'parentid' => '370000',
    'parentids' => '370000,370900',
    'level' => '2',
    'name' => '泰安市',
    'letter' => 't',
    'listorder' => '0',
  ),
  1589 => 
  array (
    'id' => '370901',
    'parentid' => '370900',
    'parentids' => '370000,370900,370901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1590 => 
  array (
    'id' => '370902',
    'parentid' => '370900',
    'parentids' => '370000,370900,370902',
    'level' => '3',
    'name' => '泰山区',
    'letter' => 't',
    'listorder' => '0',
  ),
  1591 => 
  array (
    'id' => '370903',
    'parentid' => '370900',
    'parentids' => '370000,370900,370903',
    'level' => '3',
    'name' => '岱岳区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1592 => 
  array (
    'id' => '370921',
    'parentid' => '370900',
    'parentids' => '370000,370900,370921',
    'level' => '3',
    'name' => '宁阳县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1593 => 
  array (
    'id' => '370923',
    'parentid' => '370900',
    'parentids' => '370000,370900,370923',
    'level' => '3',
    'name' => '东平县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1594 => 
  array (
    'id' => '370982',
    'parentid' => '370900',
    'parentids' => '370000,370900,370982',
    'level' => '3',
    'name' => '新泰市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1595 => 
  array (
    'id' => '370983',
    'parentid' => '370900',
    'parentids' => '370000,370900,370983',
    'level' => '3',
    'name' => '肥城市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1596 => 
  array (
    'id' => '371000',
    'parentid' => '370000',
    'parentids' => '370000,371000',
    'level' => '2',
    'name' => '威海市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1597 => 
  array (
    'id' => '371001',
    'parentid' => '371000',
    'parentids' => '370000,371000,371001',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1598 => 
  array (
    'id' => '371002',
    'parentid' => '371000',
    'parentids' => '370000,371000,371002',
    'level' => '3',
    'name' => '环翠区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1599 => 
  array (
    'id' => '371081',
    'parentid' => '371000',
    'parentids' => '370000,371000,371081',
    'level' => '3',
    'name' => '文登市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1600 => 
  array (
    'id' => '371082',
    'parentid' => '371000',
    'parentids' => '370000,371000,371082',
    'level' => '3',
    'name' => '荣成市',
    'letter' => 'r',
    'listorder' => '0',
  ),
  1601 => 
  array (
    'id' => '371083',
    'parentid' => '371000',
    'parentids' => '370000,371000,371083',
    'level' => '3',
    'name' => '乳山市',
    'letter' => 'r',
    'listorder' => '0',
  ),
  1602 => 
  array (
    'id' => '371100',
    'parentid' => '370000',
    'parentids' => '370000,371100',
    'level' => '2',
    'name' => '日照市',
    'letter' => 'r',
    'listorder' => '0',
  ),
  1603 => 
  array (
    'id' => '371101',
    'parentid' => '371100',
    'parentids' => '370000,371100,371101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1604 => 
  array (
    'id' => '371102',
    'parentid' => '371100',
    'parentids' => '370000,371100,371102',
    'level' => '3',
    'name' => '东港区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1605 => 
  array (
    'id' => '371103',
    'parentid' => '371100',
    'parentids' => '370000,371100,371103',
    'level' => '3',
    'name' => '岚山区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1606 => 
  array (
    'id' => '371121',
    'parentid' => '371100',
    'parentids' => '370000,371100,371121',
    'level' => '3',
    'name' => '五莲县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1607 => 
  array (
    'id' => '371122',
    'parentid' => '371100',
    'parentids' => '370000,371100,371122',
    'level' => '3',
    'name' => '莒　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1608 => 
  array (
    'id' => '371200',
    'parentid' => '370000',
    'parentids' => '370000,371200',
    'level' => '2',
    'name' => '莱芜市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1609 => 
  array (
    'id' => '371201',
    'parentid' => '371200',
    'parentids' => '370000,371200,371201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1610 => 
  array (
    'id' => '371202',
    'parentid' => '371200',
    'parentids' => '370000,371200,371202',
    'level' => '3',
    'name' => '莱城区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1611 => 
  array (
    'id' => '371203',
    'parentid' => '371200',
    'parentids' => '370000,371200,371203',
    'level' => '3',
    'name' => '钢城区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1612 => 
  array (
    'id' => '371300',
    'parentid' => '370000',
    'parentids' => '370000,371300',
    'level' => '2',
    'name' => '临沂市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1613 => 
  array (
    'id' => '371301',
    'parentid' => '371300',
    'parentids' => '370000,371300,371301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1614 => 
  array (
    'id' => '371302',
    'parentid' => '371300',
    'parentids' => '370000,371300,371302',
    'level' => '3',
    'name' => '兰山区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1615 => 
  array (
    'id' => '371311',
    'parentid' => '371300',
    'parentids' => '370000,371300,371311',
    'level' => '3',
    'name' => '罗庄区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1616 => 
  array (
    'id' => '371312',
    'parentid' => '371300',
    'parentids' => '370000,371300,371312',
    'level' => '3',
    'name' => '河东区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1617 => 
  array (
    'id' => '371321',
    'parentid' => '371300',
    'parentids' => '370000,371300,371321',
    'level' => '3',
    'name' => '沂南县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1618 => 
  array (
    'id' => '371322',
    'parentid' => '371300',
    'parentids' => '370000,371300,371322',
    'level' => '3',
    'name' => '郯城县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1619 => 
  array (
    'id' => '371323',
    'parentid' => '371300',
    'parentids' => '370000,371300,371323',
    'level' => '3',
    'name' => '沂水县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1620 => 
  array (
    'id' => '371324',
    'parentid' => '371300',
    'parentids' => '370000,371300,371324',
    'level' => '3',
    'name' => '苍山县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1621 => 
  array (
    'id' => '371325',
    'parentid' => '371300',
    'parentids' => '370000,371300,371325',
    'level' => '3',
    'name' => '费　县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1622 => 
  array (
    'id' => '371326',
    'parentid' => '371300',
    'parentids' => '370000,371300,371326',
    'level' => '3',
    'name' => '平邑县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1623 => 
  array (
    'id' => '371327',
    'parentid' => '371300',
    'parentids' => '370000,371300,371327',
    'level' => '3',
    'name' => '莒南县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1624 => 
  array (
    'id' => '371328',
    'parentid' => '371300',
    'parentids' => '370000,371300,371328',
    'level' => '3',
    'name' => '蒙阴县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1625 => 
  array (
    'id' => '371329',
    'parentid' => '371300',
    'parentids' => '370000,371300,371329',
    'level' => '3',
    'name' => '临沭县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1626 => 
  array (
    'id' => '371400',
    'parentid' => '370000',
    'parentids' => '370000,371400',
    'level' => '2',
    'name' => '德州市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1627 => 
  array (
    'id' => '371401',
    'parentid' => '371400',
    'parentids' => '370000,371400,371401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1628 => 
  array (
    'id' => '371402',
    'parentid' => '371400',
    'parentids' => '370000,371400,371402',
    'level' => '3',
    'name' => '德城区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1629 => 
  array (
    'id' => '371421',
    'parentid' => '371400',
    'parentids' => '370000,371400,371421',
    'level' => '3',
    'name' => '陵　县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1630 => 
  array (
    'id' => '371422',
    'parentid' => '371400',
    'parentids' => '370000,371400,371422',
    'level' => '3',
    'name' => '宁津县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1631 => 
  array (
    'id' => '371423',
    'parentid' => '371400',
    'parentids' => '370000,371400,371423',
    'level' => '3',
    'name' => '庆云县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1632 => 
  array (
    'id' => '371424',
    'parentid' => '371400',
    'parentids' => '370000,371400,371424',
    'level' => '3',
    'name' => '临邑县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1633 => 
  array (
    'id' => '371425',
    'parentid' => '371400',
    'parentids' => '370000,371400,371425',
    'level' => '3',
    'name' => '齐河县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1634 => 
  array (
    'id' => '371426',
    'parentid' => '371400',
    'parentids' => '370000,371400,371426',
    'level' => '3',
    'name' => '平原县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1635 => 
  array (
    'id' => '371427',
    'parentid' => '371400',
    'parentids' => '370000,371400,371427',
    'level' => '3',
    'name' => '夏津县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1636 => 
  array (
    'id' => '371428',
    'parentid' => '371400',
    'parentids' => '370000,371400,371428',
    'level' => '3',
    'name' => '武城县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1637 => 
  array (
    'id' => '371481',
    'parentid' => '371400',
    'parentids' => '370000,371400,371481',
    'level' => '3',
    'name' => '乐陵市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1638 => 
  array (
    'id' => '371482',
    'parentid' => '371400',
    'parentids' => '370000,371400,371482',
    'level' => '3',
    'name' => '禹城市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1639 => 
  array (
    'id' => '371500',
    'parentid' => '370000',
    'parentids' => '370000,371500',
    'level' => '2',
    'name' => '聊城市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1640 => 
  array (
    'id' => '371501',
    'parentid' => '371500',
    'parentids' => '370000,371500,371501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1641 => 
  array (
    'id' => '371502',
    'parentid' => '371500',
    'parentids' => '370000,371500,371502',
    'level' => '3',
    'name' => '东昌府区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1642 => 
  array (
    'id' => '371521',
    'parentid' => '371500',
    'parentids' => '370000,371500,371521',
    'level' => '3',
    'name' => '阳谷县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1643 => 
  array (
    'id' => '371522',
    'parentid' => '371500',
    'parentids' => '370000,371500,371522',
    'level' => '3',
    'name' => '莘　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1644 => 
  array (
    'id' => '371523',
    'parentid' => '371500',
    'parentids' => '370000,371500,371523',
    'level' => '3',
    'name' => '茌平县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1645 => 
  array (
    'id' => '371524',
    'parentid' => '371500',
    'parentids' => '370000,371500,371524',
    'level' => '3',
    'name' => '东阿县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1646 => 
  array (
    'id' => '371525',
    'parentid' => '371500',
    'parentids' => '370000,371500,371525',
    'level' => '3',
    'name' => '冠　县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1647 => 
  array (
    'id' => '371526',
    'parentid' => '371500',
    'parentids' => '370000,371500,371526',
    'level' => '3',
    'name' => '高唐县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1648 => 
  array (
    'id' => '371581',
    'parentid' => '371500',
    'parentids' => '370000,371500,371581',
    'level' => '3',
    'name' => '临清市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1649 => 
  array (
    'id' => '371600',
    'parentid' => '370000',
    'parentids' => '370000,371600',
    'level' => '2',
    'name' => '滨州市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  1650 => 
  array (
    'id' => '371601',
    'parentid' => '371600',
    'parentids' => '370000,371600,371601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1651 => 
  array (
    'id' => '371602',
    'parentid' => '371600',
    'parentids' => '370000,371600,371602',
    'level' => '3',
    'name' => '滨城区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  1652 => 
  array (
    'id' => '371621',
    'parentid' => '371600',
    'parentids' => '370000,371600,371621',
    'level' => '3',
    'name' => '惠民县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1653 => 
  array (
    'id' => '371622',
    'parentid' => '371600',
    'parentids' => '370000,371600,371622',
    'level' => '3',
    'name' => '阳信县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1654 => 
  array (
    'id' => '371623',
    'parentid' => '371600',
    'parentids' => '370000,371600,371623',
    'level' => '3',
    'name' => '无棣县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1655 => 
  array (
    'id' => '371624',
    'parentid' => '371600',
    'parentids' => '370000,371600,371624',
    'level' => '3',
    'name' => '沾化县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1656 => 
  array (
    'id' => '371625',
    'parentid' => '371600',
    'parentids' => '370000,371600,371625',
    'level' => '3',
    'name' => '博兴县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  1657 => 
  array (
    'id' => '371626',
    'parentid' => '371600',
    'parentids' => '370000,371600,371626',
    'level' => '3',
    'name' => '邹平县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1658 => 
  array (
    'id' => '371700',
    'parentid' => '370000',
    'parentids' => '370000,371700',
    'level' => '2',
    'name' => '荷泽市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1659 => 
  array (
    'id' => '371701',
    'parentid' => '371700',
    'parentids' => '370000,371700,371701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1660 => 
  array (
    'id' => '371702',
    'parentid' => '371700',
    'parentids' => '370000,371700,371702',
    'level' => '3',
    'name' => '牡丹区',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1661 => 
  array (
    'id' => '371721',
    'parentid' => '371700',
    'parentids' => '370000,371700,371721',
    'level' => '3',
    'name' => '曹　县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1662 => 
  array (
    'id' => '371722',
    'parentid' => '371700',
    'parentids' => '370000,371700,371722',
    'level' => '3',
    'name' => '单　县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1663 => 
  array (
    'id' => '371723',
    'parentid' => '371700',
    'parentids' => '370000,371700,371723',
    'level' => '3',
    'name' => '成武县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1664 => 
  array (
    'id' => '371724',
    'parentid' => '371700',
    'parentids' => '370000,371700,371724',
    'level' => '3',
    'name' => '巨野县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1665 => 
  array (
    'id' => '371725',
    'parentid' => '371700',
    'parentids' => '370000,371700,371725',
    'level' => '3',
    'name' => '郓城县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1666 => 
  array (
    'id' => '371726',
    'parentid' => '371700',
    'parentids' => '370000,371700,371726',
    'level' => '3',
    'name' => '鄄城县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1667 => 
  array (
    'id' => '371727',
    'parentid' => '371700',
    'parentids' => '370000,371700,371727',
    'level' => '3',
    'name' => '定陶县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1668 => 
  array (
    'id' => '371728',
    'parentid' => '371700',
    'parentids' => '370000,371700,371728',
    'level' => '3',
    'name' => '东明县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1669 => 
  array (
    'id' => '410000',
    'parentid' => '0',
    'parentids' => '410000',
    'level' => '1',
    'name' => '河南省',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1670 => 
  array (
    'id' => '410100',
    'parentid' => '410000',
    'parentids' => '410000,410100',
    'level' => '2',
    'name' => '郑州市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1671 => 
  array (
    'id' => '410101',
    'parentid' => '410100',
    'parentids' => '410000,410100,410101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1672 => 
  array (
    'id' => '410102',
    'parentid' => '410100',
    'parentids' => '410000,410100,410102',
    'level' => '3',
    'name' => '中原区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1673 => 
  array (
    'id' => '410103',
    'parentid' => '410100',
    'parentids' => '410000,410100,410103',
    'level' => '3',
    'name' => '二七区',
    'letter' => 'e',
    'listorder' => '0',
  ),
  1674 => 
  array (
    'id' => '410104',
    'parentid' => '410100',
    'parentids' => '410000,410100,410104',
    'level' => '3',
    'name' => '管城回族区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1675 => 
  array (
    'id' => '410105',
    'parentid' => '410100',
    'parentids' => '410000,410100,410105',
    'level' => '3',
    'name' => '金水区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1676 => 
  array (
    'id' => '410106',
    'parentid' => '410100',
    'parentids' => '410000,410100,410106',
    'level' => '3',
    'name' => '上街区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1677 => 
  array (
    'id' => '410108',
    'parentid' => '410100',
    'parentids' => '410000,410100,410108',
    'level' => '3',
    'name' => '邙山区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1678 => 
  array (
    'id' => '410122',
    'parentid' => '410100',
    'parentids' => '410000,410100,410122',
    'level' => '3',
    'name' => '中牟县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1679 => 
  array (
    'id' => '410181',
    'parentid' => '410100',
    'parentids' => '410000,410100,410181',
    'level' => '3',
    'name' => '巩义市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1680 => 
  array (
    'id' => '410182',
    'parentid' => '410100',
    'parentids' => '410000,410100,410182',
    'level' => '3',
    'name' => '荥阳市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1681 => 
  array (
    'id' => '410183',
    'parentid' => '410100',
    'parentids' => '410000,410100,410183',
    'level' => '3',
    'name' => '新密市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1682 => 
  array (
    'id' => '410184',
    'parentid' => '410100',
    'parentids' => '410000,410100,410184',
    'level' => '3',
    'name' => '新郑市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1683 => 
  array (
    'id' => '410185',
    'parentid' => '410100',
    'parentids' => '410000,410100,410185',
    'level' => '3',
    'name' => '登封市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1684 => 
  array (
    'id' => '410200',
    'parentid' => '410000',
    'parentids' => '410000,410200',
    'level' => '2',
    'name' => '开封市',
    'letter' => 'k',
    'listorder' => '0',
  ),
  1685 => 
  array (
    'id' => '410201',
    'parentid' => '410200',
    'parentids' => '410000,410200,410201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1686 => 
  array (
    'id' => '410202',
    'parentid' => '410200',
    'parentids' => '410000,410200,410202',
    'level' => '3',
    'name' => '龙亭区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1687 => 
  array (
    'id' => '410203',
    'parentid' => '410200',
    'parentids' => '410000,410200,410203',
    'level' => '3',
    'name' => '顺河回族区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1688 => 
  array (
    'id' => '410204',
    'parentid' => '410200',
    'parentids' => '410000,410200,410204',
    'level' => '3',
    'name' => '鼓楼区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1689 => 
  array (
    'id' => '410205',
    'parentid' => '410200',
    'parentids' => '410000,410200,410205',
    'level' => '3',
    'name' => '南关区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1690 => 
  array (
    'id' => '410211',
    'parentid' => '410200',
    'parentids' => '410000,410200,410211',
    'level' => '3',
    'name' => '郊　区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1691 => 
  array (
    'id' => '410221',
    'parentid' => '410200',
    'parentids' => '410000,410200,410221',
    'level' => '3',
    'name' => '杞　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1692 => 
  array (
    'id' => '410222',
    'parentid' => '410200',
    'parentids' => '410000,410200,410222',
    'level' => '3',
    'name' => '通许县',
    'letter' => 't',
    'listorder' => '0',
  ),
  1693 => 
  array (
    'id' => '410223',
    'parentid' => '410200',
    'parentids' => '410000,410200,410223',
    'level' => '3',
    'name' => '尉氏县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1694 => 
  array (
    'id' => '410224',
    'parentid' => '410200',
    'parentids' => '410000,410200,410224',
    'level' => '3',
    'name' => '开封县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  1695 => 
  array (
    'id' => '410225',
    'parentid' => '410200',
    'parentids' => '410000,410200,410225',
    'level' => '3',
    'name' => '兰考县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1696 => 
  array (
    'id' => '410300',
    'parentid' => '410000',
    'parentids' => '410000,410300',
    'level' => '2',
    'name' => '洛阳市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1697 => 
  array (
    'id' => '410301',
    'parentid' => '410300',
    'parentids' => '410000,410300,410301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1698 => 
  array (
    'id' => '410302',
    'parentid' => '410300',
    'parentids' => '410000,410300,410302',
    'level' => '3',
    'name' => '老城区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1699 => 
  array (
    'id' => '410303',
    'parentid' => '410300',
    'parentids' => '410000,410300,410303',
    'level' => '3',
    'name' => '西工区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1700 => 
  array (
    'id' => '410304',
    'parentid' => '410300',
    'parentids' => '410000,410300,410304',
    'level' => '3',
    'name' => '廛河回族区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1701 => 
  array (
    'id' => '410305',
    'parentid' => '410300',
    'parentids' => '410000,410300,410305',
    'level' => '3',
    'name' => '涧西区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1702 => 
  array (
    'id' => '410306',
    'parentid' => '410300',
    'parentids' => '410000,410300,410306',
    'level' => '3',
    'name' => '吉利区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1703 => 
  array (
    'id' => '410307',
    'parentid' => '410300',
    'parentids' => '410000,410300,410307',
    'level' => '3',
    'name' => '洛龙区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1704 => 
  array (
    'id' => '410322',
    'parentid' => '410300',
    'parentids' => '410000,410300,410322',
    'level' => '3',
    'name' => '孟津县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1705 => 
  array (
    'id' => '410323',
    'parentid' => '410300',
    'parentids' => '410000,410300,410323',
    'level' => '3',
    'name' => '新安县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1706 => 
  array (
    'id' => '410324',
    'parentid' => '410300',
    'parentids' => '410000,410300,410324',
    'level' => '3',
    'name' => '栾川县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1707 => 
  array (
    'id' => '410325',
    'parentid' => '410300',
    'parentids' => '410000,410300,410325',
    'level' => '3',
    'name' => '嵩　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1708 => 
  array (
    'id' => '410326',
    'parentid' => '410300',
    'parentids' => '410000,410300,410326',
    'level' => '3',
    'name' => '汝阳县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  1709 => 
  array (
    'id' => '410327',
    'parentid' => '410300',
    'parentids' => '410000,410300,410327',
    'level' => '3',
    'name' => '宜阳县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1710 => 
  array (
    'id' => '410328',
    'parentid' => '410300',
    'parentids' => '410000,410300,410328',
    'level' => '3',
    'name' => '洛宁县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1711 => 
  array (
    'id' => '410329',
    'parentid' => '410300',
    'parentids' => '410000,410300,410329',
    'level' => '3',
    'name' => '伊川县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1712 => 
  array (
    'id' => '410381',
    'parentid' => '410300',
    'parentids' => '410000,410300,410381',
    'level' => '3',
    'name' => '偃师市',
    'letter' => 's',
    'listorder' => '0',
  ),
  1713 => 
  array (
    'id' => '410400',
    'parentid' => '410000',
    'parentids' => '410000,410400',
    'level' => '2',
    'name' => '平顶山市',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1714 => 
  array (
    'id' => '410401',
    'parentid' => '410400',
    'parentids' => '410000,410400,410401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1715 => 
  array (
    'id' => '410402',
    'parentid' => '410400',
    'parentids' => '410000,410400,410402',
    'level' => '3',
    'name' => '新华区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1716 => 
  array (
    'id' => '410403',
    'parentid' => '410400',
    'parentids' => '410000,410400,410403',
    'level' => '3',
    'name' => '卫东区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1717 => 
  array (
    'id' => '410404',
    'parentid' => '410400',
    'parentids' => '410000,410400,410404',
    'level' => '3',
    'name' => '石龙区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1718 => 
  array (
    'id' => '410411',
    'parentid' => '410400',
    'parentids' => '410000,410400,410411',
    'level' => '3',
    'name' => '湛河区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1719 => 
  array (
    'id' => '410421',
    'parentid' => '410400',
    'parentids' => '410000,410400,410421',
    'level' => '3',
    'name' => '宝丰县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  1720 => 
  array (
    'id' => '410422',
    'parentid' => '410400',
    'parentids' => '410000,410400,410422',
    'level' => '3',
    'name' => '叶　县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1721 => 
  array (
    'id' => '410423',
    'parentid' => '410400',
    'parentids' => '410000,410400,410423',
    'level' => '3',
    'name' => '鲁山县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1722 => 
  array (
    'id' => '410425',
    'parentid' => '410400',
    'parentids' => '410000,410400,410425',
    'level' => '3',
    'name' => '郏　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1723 => 
  array (
    'id' => '410481',
    'parentid' => '410400',
    'parentids' => '410000,410400,410481',
    'level' => '3',
    'name' => '舞钢市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1724 => 
  array (
    'id' => '410482',
    'parentid' => '410400',
    'parentids' => '410000,410400,410482',
    'level' => '3',
    'name' => '汝州市',
    'letter' => 'r',
    'listorder' => '0',
  ),
  1725 => 
  array (
    'id' => '410500',
    'parentid' => '410000',
    'parentids' => '410000,410500',
    'level' => '2',
    'name' => '安阳市',
    'letter' => 'a',
    'listorder' => '0',
  ),
  1726 => 
  array (
    'id' => '410501',
    'parentid' => '410500',
    'parentids' => '410000,410500,410501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1727 => 
  array (
    'id' => '410502',
    'parentid' => '410500',
    'parentids' => '410000,410500,410502',
    'level' => '3',
    'name' => '文峰区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1728 => 
  array (
    'id' => '410503',
    'parentid' => '410500',
    'parentids' => '410000,410500,410503',
    'level' => '3',
    'name' => '北关区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  1729 => 
  array (
    'id' => '410505',
    'parentid' => '410500',
    'parentids' => '410000,410500,410505',
    'level' => '3',
    'name' => '殷都区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1730 => 
  array (
    'id' => '410506',
    'parentid' => '410500',
    'parentids' => '410000,410500,410506',
    'level' => '3',
    'name' => '龙安区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1731 => 
  array (
    'id' => '410522',
    'parentid' => '410500',
    'parentids' => '410000,410500,410522',
    'level' => '3',
    'name' => '安阳县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  1732 => 
  array (
    'id' => '410523',
    'parentid' => '410500',
    'parentids' => '410000,410500,410523',
    'level' => '3',
    'name' => '汤阴县',
    'letter' => 't',
    'listorder' => '0',
  ),
  1733 => 
  array (
    'id' => '410526',
    'parentid' => '410500',
    'parentids' => '410000,410500,410526',
    'level' => '3',
    'name' => '滑　县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1734 => 
  array (
    'id' => '410527',
    'parentid' => '410500',
    'parentids' => '410000,410500,410527',
    'level' => '3',
    'name' => '内黄县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1735 => 
  array (
    'id' => '410581',
    'parentid' => '410500',
    'parentids' => '410000,410500,410581',
    'level' => '3',
    'name' => '林州市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1736 => 
  array (
    'id' => '410600',
    'parentid' => '410000',
    'parentids' => '410000,410600',
    'level' => '2',
    'name' => '鹤壁市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1737 => 
  array (
    'id' => '410601',
    'parentid' => '410600',
    'parentids' => '410000,410600,410601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1738 => 
  array (
    'id' => '410602',
    'parentid' => '410600',
    'parentids' => '410000,410600,410602',
    'level' => '3',
    'name' => '鹤山区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1739 => 
  array (
    'id' => '410603',
    'parentid' => '410600',
    'parentids' => '410000,410600,410603',
    'level' => '3',
    'name' => '山城区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1740 => 
  array (
    'id' => '410611',
    'parentid' => '410600',
    'parentids' => '410000,410600,410611',
    'level' => '3',
    'name' => '淇滨区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  1741 => 
  array (
    'id' => '410621',
    'parentid' => '410600',
    'parentids' => '410000,410600,410621',
    'level' => '3',
    'name' => '浚　县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1742 => 
  array (
    'id' => '410622',
    'parentid' => '410600',
    'parentids' => '410000,410600,410622',
    'level' => '3',
    'name' => '淇　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1743 => 
  array (
    'id' => '410700',
    'parentid' => '410000',
    'parentids' => '410000,410700',
    'level' => '2',
    'name' => '新乡市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1744 => 
  array (
    'id' => '410701',
    'parentid' => '410700',
    'parentids' => '410000,410700,410701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1745 => 
  array (
    'id' => '410702',
    'parentid' => '410700',
    'parentids' => '410000,410700,410702',
    'level' => '3',
    'name' => '红旗区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1746 => 
  array (
    'id' => '410703',
    'parentid' => '410700',
    'parentids' => '410000,410700,410703',
    'level' => '3',
    'name' => '卫滨区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1747 => 
  array (
    'id' => '410704',
    'parentid' => '410700',
    'parentids' => '410000,410700,410704',
    'level' => '3',
    'name' => '凤泉区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1748 => 
  array (
    'id' => '410711',
    'parentid' => '410700',
    'parentids' => '410000,410700,410711',
    'level' => '3',
    'name' => '牧野区',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1749 => 
  array (
    'id' => '410721',
    'parentid' => '410700',
    'parentids' => '410000,410700,410721',
    'level' => '3',
    'name' => '新乡县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1750 => 
  array (
    'id' => '410724',
    'parentid' => '410700',
    'parentids' => '410000,410700,410724',
    'level' => '3',
    'name' => '获嘉县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1751 => 
  array (
    'id' => '410725',
    'parentid' => '410700',
    'parentids' => '410000,410700,410725',
    'level' => '3',
    'name' => '原阳县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1752 => 
  array (
    'id' => '410726',
    'parentid' => '410700',
    'parentids' => '410000,410700,410726',
    'level' => '3',
    'name' => '延津县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1753 => 
  array (
    'id' => '410727',
    'parentid' => '410700',
    'parentids' => '410000,410700,410727',
    'level' => '3',
    'name' => '封丘县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1754 => 
  array (
    'id' => '410728',
    'parentid' => '410700',
    'parentids' => '410000,410700,410728',
    'level' => '3',
    'name' => '长垣县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1755 => 
  array (
    'id' => '410781',
    'parentid' => '410700',
    'parentids' => '410000,410700,410781',
    'level' => '3',
    'name' => '卫辉市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1756 => 
  array (
    'id' => '410782',
    'parentid' => '410700',
    'parentids' => '410000,410700,410782',
    'level' => '3',
    'name' => '辉县市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1757 => 
  array (
    'id' => '410800',
    'parentid' => '410000',
    'parentids' => '410000,410800',
    'level' => '2',
    'name' => '焦作市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1758 => 
  array (
    'id' => '410801',
    'parentid' => '410800',
    'parentids' => '410000,410800,410801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1759 => 
  array (
    'id' => '410802',
    'parentid' => '410800',
    'parentids' => '410000,410800,410802',
    'level' => '3',
    'name' => '解放区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1760 => 
  array (
    'id' => '410803',
    'parentid' => '410800',
    'parentids' => '410000,410800,410803',
    'level' => '3',
    'name' => '中站区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1761 => 
  array (
    'id' => '410804',
    'parentid' => '410800',
    'parentids' => '410000,410800,410804',
    'level' => '3',
    'name' => '马村区',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1762 => 
  array (
    'id' => '410811',
    'parentid' => '410800',
    'parentids' => '410000,410800,410811',
    'level' => '3',
    'name' => '山阳区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1763 => 
  array (
    'id' => '410821',
    'parentid' => '410800',
    'parentids' => '410000,410800,410821',
    'level' => '3',
    'name' => '修武县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1764 => 
  array (
    'id' => '410822',
    'parentid' => '410800',
    'parentids' => '410000,410800,410822',
    'level' => '3',
    'name' => '博爱县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  1765 => 
  array (
    'id' => '410823',
    'parentid' => '410800',
    'parentids' => '410000,410800,410823',
    'level' => '3',
    'name' => '武陟县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1766 => 
  array (
    'id' => '410825',
    'parentid' => '410800',
    'parentids' => '410000,410800,410825',
    'level' => '3',
    'name' => '温　县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1767 => 
  array (
    'id' => '410881',
    'parentid' => '410800',
    'parentids' => '410000,410800,410881',
    'level' => '3',
    'name' => '济源市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1768 => 
  array (
    'id' => '410882',
    'parentid' => '410800',
    'parentids' => '410000,410800,410882',
    'level' => '3',
    'name' => '沁阳市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1769 => 
  array (
    'id' => '410883',
    'parentid' => '410800',
    'parentids' => '410000,410800,410883',
    'level' => '3',
    'name' => '孟州市',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1770 => 
  array (
    'id' => '410900',
    'parentid' => '410000',
    'parentids' => '410000,410900',
    'level' => '2',
    'name' => '濮阳市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1771 => 
  array (
    'id' => '410901',
    'parentid' => '410900',
    'parentids' => '410000,410900,410901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1772 => 
  array (
    'id' => '410902',
    'parentid' => '410900',
    'parentids' => '410000,410900,410902',
    'level' => '3',
    'name' => '华龙区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1773 => 
  array (
    'id' => '410922',
    'parentid' => '410900',
    'parentids' => '410000,410900,410922',
    'level' => '3',
    'name' => '清丰县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1774 => 
  array (
    'id' => '410923',
    'parentid' => '410900',
    'parentids' => '410000,410900,410923',
    'level' => '3',
    'name' => '南乐县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1775 => 
  array (
    'id' => '410926',
    'parentid' => '410900',
    'parentids' => '410000,410900,410926',
    'level' => '3',
    'name' => '范　县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1776 => 
  array (
    'id' => '410927',
    'parentid' => '410900',
    'parentids' => '410000,410900,410927',
    'level' => '3',
    'name' => '台前县',
    'letter' => 't',
    'listorder' => '0',
  ),
  1777 => 
  array (
    'id' => '410928',
    'parentid' => '410900',
    'parentids' => '410000,410900,410928',
    'level' => '3',
    'name' => '濮阳县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1778 => 
  array (
    'id' => '411000',
    'parentid' => '410000',
    'parentids' => '410000,411000',
    'level' => '2',
    'name' => '许昌市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1779 => 
  array (
    'id' => '411001',
    'parentid' => '411000',
    'parentids' => '410000,411000,411001',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1780 => 
  array (
    'id' => '411002',
    'parentid' => '411000',
    'parentids' => '410000,411000,411002',
    'level' => '3',
    'name' => '魏都区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1781 => 
  array (
    'id' => '411023',
    'parentid' => '411000',
    'parentids' => '410000,411000,411023',
    'level' => '3',
    'name' => '许昌县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1782 => 
  array (
    'id' => '411024',
    'parentid' => '411000',
    'parentids' => '410000,411000,411024',
    'level' => '3',
    'name' => '鄢陵县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1783 => 
  array (
    'id' => '411025',
    'parentid' => '411000',
    'parentids' => '410000,411000,411025',
    'level' => '3',
    'name' => '襄城县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1784 => 
  array (
    'id' => '411081',
    'parentid' => '411000',
    'parentids' => '410000,411000,411081',
    'level' => '3',
    'name' => '禹州市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1785 => 
  array (
    'id' => '411082',
    'parentid' => '411000',
    'parentids' => '410000,411000,411082',
    'level' => '3',
    'name' => '长葛市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1786 => 
  array (
    'id' => '411100',
    'parentid' => '410000',
    'parentids' => '410000,411100',
    'level' => '2',
    'name' => '漯河市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1787 => 
  array (
    'id' => '411101',
    'parentid' => '411100',
    'parentids' => '410000,411100,411101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1788 => 
  array (
    'id' => '411102',
    'parentid' => '411100',
    'parentids' => '410000,411100,411102',
    'level' => '3',
    'name' => '源汇区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1789 => 
  array (
    'id' => '411103',
    'parentid' => '411100',
    'parentids' => '410000,411100,411103',
    'level' => '3',
    'name' => '郾城区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1790 => 
  array (
    'id' => '411104',
    'parentid' => '411100',
    'parentids' => '410000,411100,411104',
    'level' => '3',
    'name' => '召陵区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1791 => 
  array (
    'id' => '411121',
    'parentid' => '411100',
    'parentids' => '410000,411100,411121',
    'level' => '3',
    'name' => '舞阳县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1792 => 
  array (
    'id' => '411122',
    'parentid' => '411100',
    'parentids' => '410000,411100,411122',
    'level' => '3',
    'name' => '临颍县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1793 => 
  array (
    'id' => '411200',
    'parentid' => '410000',
    'parentids' => '410000,411200',
    'level' => '2',
    'name' => '三门峡市',
    'letter' => 's',
    'listorder' => '0',
  ),
  1794 => 
  array (
    'id' => '411201',
    'parentid' => '411200',
    'parentids' => '410000,411200,411201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1795 => 
  array (
    'id' => '411202',
    'parentid' => '411200',
    'parentids' => '410000,411200,411202',
    'level' => '3',
    'name' => '湖滨区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1796 => 
  array (
    'id' => '411221',
    'parentid' => '411200',
    'parentids' => '410000,411200,411221',
    'level' => '3',
    'name' => '渑池县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1797 => 
  array (
    'id' => '411222',
    'parentid' => '411200',
    'parentids' => '410000,411200,411222',
    'level' => '3',
    'name' => '陕　县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1798 => 
  array (
    'id' => '411224',
    'parentid' => '411200',
    'parentids' => '410000,411200,411224',
    'level' => '3',
    'name' => '卢氏县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1799 => 
  array (
    'id' => '411281',
    'parentid' => '411200',
    'parentids' => '410000,411200,411281',
    'level' => '3',
    'name' => '义马市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1800 => 
  array (
    'id' => '411282',
    'parentid' => '411200',
    'parentids' => '410000,411200,411282',
    'level' => '3',
    'name' => '灵宝市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1801 => 
  array (
    'id' => '411300',
    'parentid' => '410000',
    'parentids' => '410000,411300',
    'level' => '2',
    'name' => '南阳市',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1802 => 
  array (
    'id' => '411301',
    'parentid' => '411300',
    'parentids' => '410000,411300,411301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1803 => 
  array (
    'id' => '411302',
    'parentid' => '411300',
    'parentids' => '410000,411300,411302',
    'level' => '3',
    'name' => '宛城区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1804 => 
  array (
    'id' => '411303',
    'parentid' => '411300',
    'parentids' => '410000,411300,411303',
    'level' => '3',
    'name' => '卧龙区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1805 => 
  array (
    'id' => '411321',
    'parentid' => '411300',
    'parentids' => '410000,411300,411321',
    'level' => '3',
    'name' => '南召县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1806 => 
  array (
    'id' => '411322',
    'parentid' => '411300',
    'parentids' => '410000,411300,411322',
    'level' => '3',
    'name' => '方城县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1807 => 
  array (
    'id' => '411323',
    'parentid' => '411300',
    'parentids' => '410000,411300,411323',
    'level' => '3',
    'name' => '西峡县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1808 => 
  array (
    'id' => '411324',
    'parentid' => '411300',
    'parentids' => '410000,411300,411324',
    'level' => '3',
    'name' => '镇平县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1809 => 
  array (
    'id' => '411325',
    'parentid' => '411300',
    'parentids' => '410000,411300,411325',
    'level' => '3',
    'name' => '内乡县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1810 => 
  array (
    'id' => '411326',
    'parentid' => '411300',
    'parentids' => '410000,411300,411326',
    'level' => '3',
    'name' => '淅川县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1811 => 
  array (
    'id' => '411327',
    'parentid' => '411300',
    'parentids' => '410000,411300,411327',
    'level' => '3',
    'name' => '社旗县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1812 => 
  array (
    'id' => '411328',
    'parentid' => '411300',
    'parentids' => '410000,411300,411328',
    'level' => '3',
    'name' => '唐河县',
    'letter' => 't',
    'listorder' => '0',
  ),
  1813 => 
  array (
    'id' => '411329',
    'parentid' => '411300',
    'parentids' => '410000,411300,411329',
    'level' => '3',
    'name' => '新野县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1814 => 
  array (
    'id' => '411330',
    'parentid' => '411300',
    'parentids' => '410000,411300,411330',
    'level' => '3',
    'name' => '桐柏县',
    'letter' => 't',
    'listorder' => '0',
  ),
  1815 => 
  array (
    'id' => '411381',
    'parentid' => '411300',
    'parentids' => '410000,411300,411381',
    'level' => '3',
    'name' => '邓州市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1816 => 
  array (
    'id' => '411400',
    'parentid' => '410000',
    'parentids' => '410000,411400',
    'level' => '2',
    'name' => '商丘市',
    'letter' => 's',
    'listorder' => '0',
  ),
  1817 => 
  array (
    'id' => '411401',
    'parentid' => '411400',
    'parentids' => '410000,411400,411401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1818 => 
  array (
    'id' => '411402',
    'parentid' => '411400',
    'parentids' => '410000,411400,411402',
    'level' => '3',
    'name' => '梁园区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1819 => 
  array (
    'id' => '411403',
    'parentid' => '411400',
    'parentids' => '410000,411400,411403',
    'level' => '3',
    'name' => '睢阳区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1820 => 
  array (
    'id' => '411421',
    'parentid' => '411400',
    'parentids' => '410000,411400,411421',
    'level' => '3',
    'name' => '民权县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1821 => 
  array (
    'id' => '411422',
    'parentid' => '411400',
    'parentids' => '410000,411400,411422',
    'level' => '3',
    'name' => '睢　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1822 => 
  array (
    'id' => '411423',
    'parentid' => '411400',
    'parentids' => '410000,411400,411423',
    'level' => '3',
    'name' => '宁陵县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1823 => 
  array (
    'id' => '411424',
    'parentid' => '411400',
    'parentids' => '410000,411400,411424',
    'level' => '3',
    'name' => '柘城县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1824 => 
  array (
    'id' => '411425',
    'parentid' => '411400',
    'parentids' => '410000,411400,411425',
    'level' => '3',
    'name' => '虞城县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1825 => 
  array (
    'id' => '411426',
    'parentid' => '411400',
    'parentids' => '410000,411400,411426',
    'level' => '3',
    'name' => '夏邑县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1826 => 
  array (
    'id' => '411481',
    'parentid' => '411400',
    'parentids' => '410000,411400,411481',
    'level' => '3',
    'name' => '永城市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1827 => 
  array (
    'id' => '411500',
    'parentid' => '410000',
    'parentids' => '410000,411500',
    'level' => '2',
    'name' => '信阳市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1828 => 
  array (
    'id' => '411501',
    'parentid' => '411500',
    'parentids' => '410000,411500,411501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1829 => 
  array (
    'id' => '411502',
    'parentid' => '411500',
    'parentids' => '410000,411500,411502',
    'level' => '3',
    'name' => '师河区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1830 => 
  array (
    'id' => '411503',
    'parentid' => '411500',
    'parentids' => '410000,411500,411503',
    'level' => '3',
    'name' => '平桥区',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1831 => 
  array (
    'id' => '411521',
    'parentid' => '411500',
    'parentids' => '410000,411500,411521',
    'level' => '3',
    'name' => '罗山县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1832 => 
  array (
    'id' => '411522',
    'parentid' => '411500',
    'parentids' => '410000,411500,411522',
    'level' => '3',
    'name' => '光山县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1833 => 
  array (
    'id' => '411523',
    'parentid' => '411500',
    'parentids' => '410000,411500,411523',
    'level' => '3',
    'name' => '新　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1834 => 
  array (
    'id' => '411524',
    'parentid' => '411500',
    'parentids' => '410000,411500,411524',
    'level' => '3',
    'name' => '商城县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1835 => 
  array (
    'id' => '411525',
    'parentid' => '411500',
    'parentids' => '410000,411500,411525',
    'level' => '3',
    'name' => '固始县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1836 => 
  array (
    'id' => '411526',
    'parentid' => '411500',
    'parentids' => '410000,411500,411526',
    'level' => '3',
    'name' => '潢川县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1837 => 
  array (
    'id' => '411527',
    'parentid' => '411500',
    'parentids' => '410000,411500,411527',
    'level' => '3',
    'name' => '淮滨县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1838 => 
  array (
    'id' => '411528',
    'parentid' => '411500',
    'parentids' => '410000,411500,411528',
    'level' => '3',
    'name' => '息　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1839 => 
  array (
    'id' => '411600',
    'parentid' => '410000',
    'parentids' => '410000,411600',
    'level' => '2',
    'name' => '周口市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1840 => 
  array (
    'id' => '411601',
    'parentid' => '411600',
    'parentids' => '410000,411600,411601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1841 => 
  array (
    'id' => '411602',
    'parentid' => '411600',
    'parentids' => '410000,411600,411602',
    'level' => '3',
    'name' => '川汇区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1842 => 
  array (
    'id' => '411621',
    'parentid' => '411600',
    'parentids' => '410000,411600,411621',
    'level' => '3',
    'name' => '扶沟县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1843 => 
  array (
    'id' => '411622',
    'parentid' => '411600',
    'parentids' => '410000,411600,411622',
    'level' => '3',
    'name' => '西华县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1844 => 
  array (
    'id' => '411623',
    'parentid' => '411600',
    'parentids' => '410000,411600,411623',
    'level' => '3',
    'name' => '商水县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1845 => 
  array (
    'id' => '411624',
    'parentid' => '411600',
    'parentids' => '410000,411600,411624',
    'level' => '3',
    'name' => '沈丘县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1846 => 
  array (
    'id' => '411625',
    'parentid' => '411600',
    'parentids' => '410000,411600,411625',
    'level' => '3',
    'name' => '郸城县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1847 => 
  array (
    'id' => '411626',
    'parentid' => '411600',
    'parentids' => '410000,411600,411626',
    'level' => '3',
    'name' => '淮阳县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1848 => 
  array (
    'id' => '411627',
    'parentid' => '411600',
    'parentids' => '410000,411600,411627',
    'level' => '3',
    'name' => '太康县',
    'letter' => 't',
    'listorder' => '0',
  ),
  1849 => 
  array (
    'id' => '411628',
    'parentid' => '411600',
    'parentids' => '410000,411600,411628',
    'level' => '3',
    'name' => '鹿邑县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1850 => 
  array (
    'id' => '411681',
    'parentid' => '411600',
    'parentids' => '410000,411600,411681',
    'level' => '3',
    'name' => '项城市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1851 => 
  array (
    'id' => '411700',
    'parentid' => '410000',
    'parentids' => '410000,411700',
    'level' => '2',
    'name' => '驻马店市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1852 => 
  array (
    'id' => '411701',
    'parentid' => '411700',
    'parentids' => '410000,411700,411701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1853 => 
  array (
    'id' => '411702',
    'parentid' => '411700',
    'parentids' => '410000,411700,411702',
    'level' => '3',
    'name' => '驿城区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1854 => 
  array (
    'id' => '411721',
    'parentid' => '411700',
    'parentids' => '410000,411700,411721',
    'level' => '3',
    'name' => '西平县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1855 => 
  array (
    'id' => '411722',
    'parentid' => '411700',
    'parentids' => '410000,411700,411722',
    'level' => '3',
    'name' => '上蔡县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1856 => 
  array (
    'id' => '411723',
    'parentid' => '411700',
    'parentids' => '410000,411700,411723',
    'level' => '3',
    'name' => '平舆县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  1857 => 
  array (
    'id' => '411724',
    'parentid' => '411700',
    'parentids' => '410000,411700,411724',
    'level' => '3',
    'name' => '正阳县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1858 => 
  array (
    'id' => '411725',
    'parentid' => '411700',
    'parentids' => '410000,411700,411725',
    'level' => '3',
    'name' => '确山县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1859 => 
  array (
    'id' => '411726',
    'parentid' => '411700',
    'parentids' => '410000,411700,411726',
    'level' => '3',
    'name' => '泌阳县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1860 => 
  array (
    'id' => '411727',
    'parentid' => '411700',
    'parentids' => '410000,411700,411727',
    'level' => '3',
    'name' => '汝南县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  1861 => 
  array (
    'id' => '411728',
    'parentid' => '411700',
    'parentids' => '410000,411700,411728',
    'level' => '3',
    'name' => '遂平县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1862 => 
  array (
    'id' => '411729',
    'parentid' => '411700',
    'parentids' => '410000,411700,411729',
    'level' => '3',
    'name' => '新蔡县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1863 => 
  array (
    'id' => '420000',
    'parentid' => '0',
    'parentids' => '420000',
    'level' => '1',
    'name' => '湖北省',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1864 => 
  array (
    'id' => '420100',
    'parentid' => '420000',
    'parentids' => '420000,420100',
    'level' => '2',
    'name' => '武汉市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1865 => 
  array (
    'id' => '420101',
    'parentid' => '420100',
    'parentids' => '420000,420100,420101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1866 => 
  array (
    'id' => '420102',
    'parentid' => '420100',
    'parentids' => '420000,420100,420102',
    'level' => '3',
    'name' => '江岸区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1867 => 
  array (
    'id' => '420103',
    'parentid' => '420100',
    'parentids' => '420000,420100,420103',
    'level' => '3',
    'name' => '江汉区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1868 => 
  array (
    'id' => '420104',
    'parentid' => '420100',
    'parentids' => '420000,420100,420104',
    'level' => '3',
    'name' => '乔口区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1869 => 
  array (
    'id' => '420105',
    'parentid' => '420100',
    'parentids' => '420000,420100,420105',
    'level' => '3',
    'name' => '汉阳区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1870 => 
  array (
    'id' => '420106',
    'parentid' => '420100',
    'parentids' => '420000,420100,420106',
    'level' => '3',
    'name' => '武昌区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1871 => 
  array (
    'id' => '420107',
    'parentid' => '420100',
    'parentids' => '420000,420100,420107',
    'level' => '3',
    'name' => '青山区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1872 => 
  array (
    'id' => '420111',
    'parentid' => '420100',
    'parentids' => '420000,420100,420111',
    'level' => '3',
    'name' => '洪山区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1873 => 
  array (
    'id' => '420112',
    'parentid' => '420100',
    'parentids' => '420000,420100,420112',
    'level' => '3',
    'name' => '东西湖区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1874 => 
  array (
    'id' => '420113',
    'parentid' => '420100',
    'parentids' => '420000,420100,420113',
    'level' => '3',
    'name' => '汉南区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1875 => 
  array (
    'id' => '420114',
    'parentid' => '420100',
    'parentids' => '420000,420100,420114',
    'level' => '3',
    'name' => '蔡甸区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1876 => 
  array (
    'id' => '420115',
    'parentid' => '420100',
    'parentids' => '420000,420100,420115',
    'level' => '3',
    'name' => '江夏区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1877 => 
  array (
    'id' => '420116',
    'parentid' => '420100',
    'parentids' => '420000,420100,420116',
    'level' => '3',
    'name' => '黄陂区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1878 => 
  array (
    'id' => '420117',
    'parentid' => '420100',
    'parentids' => '420000,420100,420117',
    'level' => '3',
    'name' => '新洲区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1879 => 
  array (
    'id' => '420200',
    'parentid' => '420000',
    'parentids' => '420000,420200',
    'level' => '2',
    'name' => '黄石市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1880 => 
  array (
    'id' => '420201',
    'parentid' => '420200',
    'parentids' => '420000,420200,420201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1881 => 
  array (
    'id' => '420202',
    'parentid' => '420200',
    'parentids' => '420000,420200,420202',
    'level' => '3',
    'name' => '黄石港区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1882 => 
  array (
    'id' => '420203',
    'parentid' => '420200',
    'parentids' => '420000,420200,420203',
    'level' => '3',
    'name' => '西塞山区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1883 => 
  array (
    'id' => '420204',
    'parentid' => '420200',
    'parentids' => '420000,420200,420204',
    'level' => '3',
    'name' => '下陆区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1884 => 
  array (
    'id' => '420205',
    'parentid' => '420200',
    'parentids' => '420000,420200,420205',
    'level' => '3',
    'name' => '铁山区',
    'letter' => 't',
    'listorder' => '0',
  ),
  1885 => 
  array (
    'id' => '420222',
    'parentid' => '420200',
    'parentids' => '420000,420200,420222',
    'level' => '3',
    'name' => '阳新县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1886 => 
  array (
    'id' => '420281',
    'parentid' => '420200',
    'parentids' => '420000,420200,420281',
    'level' => '3',
    'name' => '大冶市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1887 => 
  array (
    'id' => '420300',
    'parentid' => '420000',
    'parentids' => '420000,420300',
    'level' => '2',
    'name' => '十堰市',
    'letter' => 's',
    'listorder' => '0',
  ),
  1888 => 
  array (
    'id' => '420301',
    'parentid' => '420300',
    'parentids' => '420000,420300,420301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1889 => 
  array (
    'id' => '420302',
    'parentid' => '420300',
    'parentids' => '420000,420300,420302',
    'level' => '3',
    'name' => '茅箭区',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1890 => 
  array (
    'id' => '420303',
    'parentid' => '420300',
    'parentids' => '420000,420300,420303',
    'level' => '3',
    'name' => '张湾区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1891 => 
  array (
    'id' => '420321',
    'parentid' => '420300',
    'parentids' => '420000,420300,420321',
    'level' => '3',
    'name' => '郧　县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1892 => 
  array (
    'id' => '420322',
    'parentid' => '420300',
    'parentids' => '420000,420300,420322',
    'level' => '3',
    'name' => '郧西县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1893 => 
  array (
    'id' => '420323',
    'parentid' => '420300',
    'parentids' => '420000,420300,420323',
    'level' => '3',
    'name' => '竹山县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1894 => 
  array (
    'id' => '420324',
    'parentid' => '420300',
    'parentids' => '420000,420300,420324',
    'level' => '3',
    'name' => '竹溪县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1895 => 
  array (
    'id' => '420325',
    'parentid' => '420300',
    'parentids' => '420000,420300,420325',
    'level' => '3',
    'name' => '房　县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1896 => 
  array (
    'id' => '420381',
    'parentid' => '420300',
    'parentids' => '420000,420300,420381',
    'level' => '3',
    'name' => '丹江口市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1897 => 
  array (
    'id' => '420500',
    'parentid' => '420000',
    'parentids' => '420000,420500',
    'level' => '2',
    'name' => '宜昌市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1898 => 
  array (
    'id' => '420501',
    'parentid' => '420500',
    'parentids' => '420000,420500,420501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1899 => 
  array (
    'id' => '420502',
    'parentid' => '420500',
    'parentids' => '420000,420500,420502',
    'level' => '3',
    'name' => '西陵区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1900 => 
  array (
    'id' => '420503',
    'parentid' => '420500',
    'parentids' => '420000,420500,420503',
    'level' => '3',
    'name' => '伍家岗区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1901 => 
  array (
    'id' => '420504',
    'parentid' => '420500',
    'parentids' => '420000,420500,420504',
    'level' => '3',
    'name' => '点军区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1902 => 
  array (
    'id' => '420505',
    'parentid' => '420500',
    'parentids' => '420000,420500,420505',
    'level' => '3',
    'name' => '猇亭区',
    'letter' => 't',
    'listorder' => '0',
  ),
  1903 => 
  array (
    'id' => '420506',
    'parentid' => '420500',
    'parentids' => '420000,420500,420506',
    'level' => '3',
    'name' => '夷陵区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1904 => 
  array (
    'id' => '420525',
    'parentid' => '420500',
    'parentids' => '420000,420500,420525',
    'level' => '3',
    'name' => '远安县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1905 => 
  array (
    'id' => '420526',
    'parentid' => '420500',
    'parentids' => '420000,420500,420526',
    'level' => '3',
    'name' => '兴山县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1906 => 
  array (
    'id' => '420527',
    'parentid' => '420500',
    'parentids' => '420000,420500,420527',
    'level' => '3',
    'name' => '秭归县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1907 => 
  array (
    'id' => '420528',
    'parentid' => '420500',
    'parentids' => '420000,420500,420528',
    'level' => '3',
    'name' => '长阳土家族自治县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1908 => 
  array (
    'id' => '420529',
    'parentid' => '420500',
    'parentids' => '420000,420500,420529',
    'level' => '3',
    'name' => '五峰土家族自治县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1909 => 
  array (
    'id' => '420581',
    'parentid' => '420500',
    'parentids' => '420000,420500,420581',
    'level' => '3',
    'name' => '宜都市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1910 => 
  array (
    'id' => '420582',
    'parentid' => '420500',
    'parentids' => '420000,420500,420582',
    'level' => '3',
    'name' => '当阳市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1911 => 
  array (
    'id' => '420583',
    'parentid' => '420500',
    'parentids' => '420000,420500,420583',
    'level' => '3',
    'name' => '枝江市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1912 => 
  array (
    'id' => '420600',
    'parentid' => '420000',
    'parentids' => '420000,420600',
    'level' => '2',
    'name' => '襄樊市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1913 => 
  array (
    'id' => '420601',
    'parentid' => '420600',
    'parentids' => '420000,420600,420601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1914 => 
  array (
    'id' => '420602',
    'parentid' => '420600',
    'parentids' => '420000,420600,420602',
    'level' => '3',
    'name' => '襄城区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1915 => 
  array (
    'id' => '420606',
    'parentid' => '420600',
    'parentids' => '420000,420600,420606',
    'level' => '3',
    'name' => '樊城区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  1916 => 
  array (
    'id' => '420607',
    'parentid' => '420600',
    'parentids' => '420000,420600,420607',
    'level' => '3',
    'name' => '襄阳区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1917 => 
  array (
    'id' => '420624',
    'parentid' => '420600',
    'parentids' => '420000,420600,420624',
    'level' => '3',
    'name' => '南漳县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  1918 => 
  array (
    'id' => '420625',
    'parentid' => '420600',
    'parentids' => '420000,420600,420625',
    'level' => '3',
    'name' => '谷城县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1919 => 
  array (
    'id' => '420626',
    'parentid' => '420600',
    'parentids' => '420000,420600,420626',
    'level' => '3',
    'name' => '保康县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  1920 => 
  array (
    'id' => '420682',
    'parentid' => '420600',
    'parentids' => '420000,420600,420682',
    'level' => '3',
    'name' => '老河口市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1921 => 
  array (
    'id' => '420683',
    'parentid' => '420600',
    'parentids' => '420000,420600,420683',
    'level' => '3',
    'name' => '枣阳市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1922 => 
  array (
    'id' => '420684',
    'parentid' => '420600',
    'parentids' => '420000,420600,420684',
    'level' => '3',
    'name' => '宜城市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1923 => 
  array (
    'id' => '420700',
    'parentid' => '420000',
    'parentids' => '420000,420700',
    'level' => '2',
    'name' => '鄂州市',
    'letter' => 'e',
    'listorder' => '0',
  ),
  1924 => 
  array (
    'id' => '420701',
    'parentid' => '420700',
    'parentids' => '420000,420700,420701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1925 => 
  array (
    'id' => '420702',
    'parentid' => '420700',
    'parentids' => '420000,420700,420702',
    'level' => '3',
    'name' => '梁子湖区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1926 => 
  array (
    'id' => '420703',
    'parentid' => '420700',
    'parentids' => '420000,420700,420703',
    'level' => '3',
    'name' => '华容区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1927 => 
  array (
    'id' => '420704',
    'parentid' => '420700',
    'parentids' => '420000,420700,420704',
    'level' => '3',
    'name' => '鄂城区',
    'letter' => 'e',
    'listorder' => '0',
  ),
  1928 => 
  array (
    'id' => '420800',
    'parentid' => '420000',
    'parentids' => '420000,420800',
    'level' => '2',
    'name' => '荆门市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1929 => 
  array (
    'id' => '420801',
    'parentid' => '420800',
    'parentids' => '420000,420800,420801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1930 => 
  array (
    'id' => '420802',
    'parentid' => '420800',
    'parentids' => '420000,420800,420802',
    'level' => '3',
    'name' => '东宝区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1931 => 
  array (
    'id' => '420804',
    'parentid' => '420800',
    'parentids' => '420000,420800,420804',
    'level' => '3',
    'name' => '掇刀区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1932 => 
  array (
    'id' => '420821',
    'parentid' => '420800',
    'parentids' => '420000,420800,420821',
    'level' => '3',
    'name' => '京山县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1933 => 
  array (
    'id' => '420822',
    'parentid' => '420800',
    'parentids' => '420000,420800,420822',
    'level' => '3',
    'name' => '沙洋县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1934 => 
  array (
    'id' => '420881',
    'parentid' => '420800',
    'parentids' => '420000,420800,420881',
    'level' => '3',
    'name' => '钟祥市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1935 => 
  array (
    'id' => '420900',
    'parentid' => '420000',
    'parentids' => '420000,420900',
    'level' => '2',
    'name' => '孝感市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1936 => 
  array (
    'id' => '420901',
    'parentid' => '420900',
    'parentids' => '420000,420900,420901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1937 => 
  array (
    'id' => '420902',
    'parentid' => '420900',
    'parentids' => '420000,420900,420902',
    'level' => '3',
    'name' => '孝南区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1938 => 
  array (
    'id' => '420921',
    'parentid' => '420900',
    'parentids' => '420000,420900,420921',
    'level' => '3',
    'name' => '孝昌县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1939 => 
  array (
    'id' => '420922',
    'parentid' => '420900',
    'parentids' => '420000,420900,420922',
    'level' => '3',
    'name' => '大悟县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  1940 => 
  array (
    'id' => '420923',
    'parentid' => '420900',
    'parentids' => '420000,420900,420923',
    'level' => '3',
    'name' => '云梦县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1941 => 
  array (
    'id' => '420981',
    'parentid' => '420900',
    'parentids' => '420000,420900,420981',
    'level' => '3',
    'name' => '应城市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1942 => 
  array (
    'id' => '420982',
    'parentid' => '420900',
    'parentids' => '420000,420900,420982',
    'level' => '3',
    'name' => '安陆市',
    'letter' => 'a',
    'listorder' => '0',
  ),
  1943 => 
  array (
    'id' => '420984',
    'parentid' => '420900',
    'parentids' => '420000,420900,420984',
    'level' => '3',
    'name' => '汉川市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1944 => 
  array (
    'id' => '421000',
    'parentid' => '420000',
    'parentids' => '420000,421000',
    'level' => '2',
    'name' => '荆州市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1945 => 
  array (
    'id' => '421001',
    'parentid' => '421000',
    'parentids' => '420000,421000,421001',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1946 => 
  array (
    'id' => '421002',
    'parentid' => '421000',
    'parentids' => '420000,421000,421002',
    'level' => '3',
    'name' => '沙市区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1947 => 
  array (
    'id' => '421003',
    'parentid' => '421000',
    'parentids' => '420000,421000,421003',
    'level' => '3',
    'name' => '荆州区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1948 => 
  array (
    'id' => '421022',
    'parentid' => '421000',
    'parentids' => '420000,421000,421022',
    'level' => '3',
    'name' => '公安县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1949 => 
  array (
    'id' => '421023',
    'parentid' => '421000',
    'parentids' => '420000,421000,421023',
    'level' => '3',
    'name' => '监利县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1950 => 
  array (
    'id' => '421024',
    'parentid' => '421000',
    'parentids' => '420000,421000,421024',
    'level' => '3',
    'name' => '江陵县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1951 => 
  array (
    'id' => '421081',
    'parentid' => '421000',
    'parentids' => '420000,421000,421081',
    'level' => '3',
    'name' => '石首市',
    'letter' => 's',
    'listorder' => '0',
  ),
  1952 => 
  array (
    'id' => '421083',
    'parentid' => '421000',
    'parentids' => '420000,421000,421083',
    'level' => '3',
    'name' => '洪湖市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1953 => 
  array (
    'id' => '421087',
    'parentid' => '421000',
    'parentids' => '420000,421000,421087',
    'level' => '3',
    'name' => '松滋市',
    'letter' => 's',
    'listorder' => '0',
  ),
  1954 => 
  array (
    'id' => '421100',
    'parentid' => '420000',
    'parentids' => '420000,421100',
    'level' => '2',
    'name' => '黄冈市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1955 => 
  array (
    'id' => '421101',
    'parentid' => '421100',
    'parentids' => '420000,421100,421101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1956 => 
  array (
    'id' => '421102',
    'parentid' => '421100',
    'parentids' => '420000,421100,421102',
    'level' => '3',
    'name' => '黄州区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1957 => 
  array (
    'id' => '421121',
    'parentid' => '421100',
    'parentids' => '420000,421100,421121',
    'level' => '3',
    'name' => '团风县',
    'letter' => 't',
    'listorder' => '0',
  ),
  1958 => 
  array (
    'id' => '421122',
    'parentid' => '421100',
    'parentids' => '420000,421100,421122',
    'level' => '3',
    'name' => '红安县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1959 => 
  array (
    'id' => '421123',
    'parentid' => '421100',
    'parentids' => '420000,421100,421123',
    'level' => '3',
    'name' => '罗田县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1960 => 
  array (
    'id' => '421124',
    'parentid' => '421100',
    'parentids' => '420000,421100,421124',
    'level' => '3',
    'name' => '英山县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1961 => 
  array (
    'id' => '421125',
    'parentid' => '421100',
    'parentids' => '420000,421100,421125',
    'level' => '3',
    'name' => '浠水县',
    'letter' => 's',
    'listorder' => '0',
  ),
  1962 => 
  array (
    'id' => '421126',
    'parentid' => '421100',
    'parentids' => '420000,421100,421126',
    'level' => '3',
    'name' => '蕲春县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1963 => 
  array (
    'id' => '421127',
    'parentid' => '421100',
    'parentids' => '420000,421100,421127',
    'level' => '3',
    'name' => '黄梅县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1964 => 
  array (
    'id' => '421181',
    'parentid' => '421100',
    'parentids' => '420000,421100,421181',
    'level' => '3',
    'name' => '麻城市',
    'letter' => 'm',
    'listorder' => '0',
  ),
  1965 => 
  array (
    'id' => '421182',
    'parentid' => '421100',
    'parentids' => '420000,421100,421182',
    'level' => '3',
    'name' => '武穴市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  1966 => 
  array (
    'id' => '421200',
    'parentid' => '420000',
    'parentids' => '420000,421200',
    'level' => '2',
    'name' => '咸宁市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1967 => 
  array (
    'id' => '421201',
    'parentid' => '421200',
    'parentids' => '420000,421200,421201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1968 => 
  array (
    'id' => '421202',
    'parentid' => '421200',
    'parentids' => '420000,421200,421202',
    'level' => '3',
    'name' => '咸安区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1969 => 
  array (
    'id' => '421221',
    'parentid' => '421200',
    'parentids' => '420000,421200,421221',
    'level' => '3',
    'name' => '嘉鱼县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1970 => 
  array (
    'id' => '421222',
    'parentid' => '421200',
    'parentids' => '420000,421200,421222',
    'level' => '3',
    'name' => '通城县',
    'letter' => 't',
    'listorder' => '0',
  ),
  1971 => 
  array (
    'id' => '421223',
    'parentid' => '421200',
    'parentids' => '420000,421200,421223',
    'level' => '3',
    'name' => '崇阳县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1972 => 
  array (
    'id' => '421224',
    'parentid' => '421200',
    'parentids' => '420000,421200,421224',
    'level' => '3',
    'name' => '通山县',
    'letter' => 't',
    'listorder' => '0',
  ),
  1973 => 
  array (
    'id' => '421281',
    'parentid' => '421200',
    'parentids' => '420000,421200,421281',
    'level' => '3',
    'name' => '赤壁市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1974 => 
  array (
    'id' => '421300',
    'parentid' => '420000',
    'parentids' => '420000,421300',
    'level' => '2',
    'name' => '随州市',
    'letter' => 's',
    'listorder' => '0',
  ),
  1975 => 
  array (
    'id' => '421301',
    'parentid' => '421300',
    'parentids' => '420000,421300,421301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1976 => 
  array (
    'id' => '421302',
    'parentid' => '421300',
    'parentids' => '420000,421300,421302',
    'level' => '3',
    'name' => '曾都区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  1977 => 
  array (
    'id' => '421381',
    'parentid' => '421300',
    'parentids' => '420000,421300,421381',
    'level' => '3',
    'name' => '广水市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  1978 => 
  array (
    'id' => '422800',
    'parentid' => '420000',
    'parentids' => '420000,422800',
    'level' => '2',
    'name' => '恩施土家族苗族自治州',
    'letter' => 'e',
    'listorder' => '0',
  ),
  1979 => 
  array (
    'id' => '422801',
    'parentid' => '422800',
    'parentids' => '420000,422800,422801',
    'level' => '3',
    'name' => '恩施市',
    'letter' => 'e',
    'listorder' => '0',
  ),
  1980 => 
  array (
    'id' => '422802',
    'parentid' => '422800',
    'parentids' => '420000,422800,422802',
    'level' => '3',
    'name' => '利川市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1981 => 
  array (
    'id' => '422822',
    'parentid' => '422800',
    'parentids' => '420000,422800,422822',
    'level' => '3',
    'name' => '建始县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  1982 => 
  array (
    'id' => '422823',
    'parentid' => '422800',
    'parentids' => '420000,422800,422823',
    'level' => '3',
    'name' => '巴东县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  1983 => 
  array (
    'id' => '422825',
    'parentid' => '422800',
    'parentids' => '420000,422800,422825',
    'level' => '3',
    'name' => '宣恩县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1984 => 
  array (
    'id' => '422826',
    'parentid' => '422800',
    'parentids' => '420000,422800,422826',
    'level' => '3',
    'name' => '咸丰县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1985 => 
  array (
    'id' => '422827',
    'parentid' => '422800',
    'parentids' => '420000,422800,422827',
    'level' => '3',
    'name' => '来凤县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  1986 => 
  array (
    'id' => '422828',
    'parentid' => '422800',
    'parentids' => '420000,422800,422828',
    'level' => '3',
    'name' => '鹤峰县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1987 => 
  array (
    'id' => '429000',
    'parentid' => '420000',
    'parentids' => '420000,429000',
    'level' => '2',
    'name' => '省直辖行政单位',
    'letter' => 's',
    'listorder' => '0',
  ),
  1988 => 
  array (
    'id' => '429004',
    'parentid' => '429000',
    'parentids' => '420000,429000,429004',
    'level' => '3',
    'name' => '仙桃市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  1989 => 
  array (
    'id' => '429005',
    'parentid' => '429000',
    'parentids' => '420000,429000,429005',
    'level' => '3',
    'name' => '潜江市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  1990 => 
  array (
    'id' => '429006',
    'parentid' => '429000',
    'parentids' => '420000,429000,429006',
    'level' => '3',
    'name' => '天门市',
    'letter' => 't',
    'listorder' => '0',
  ),
  1991 => 
  array (
    'id' => '429021',
    'parentid' => '429000',
    'parentids' => '420000,429000,429021',
    'level' => '3',
    'name' => '神农架林区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1992 => 
  array (
    'id' => '430000',
    'parentid' => '0',
    'parentids' => '430000',
    'level' => '1',
    'name' => '湖南省',
    'letter' => 'h',
    'listorder' => '0',
  ),
  1993 => 
  array (
    'id' => '430100',
    'parentid' => '430000',
    'parentids' => '430000,430100',
    'level' => '2',
    'name' => '长沙市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  1994 => 
  array (
    'id' => '430101',
    'parentid' => '430100',
    'parentids' => '430000,430100,430101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  1995 => 
  array (
    'id' => '430102',
    'parentid' => '430100',
    'parentids' => '430000,430100,430102',
    'level' => '3',
    'name' => '芙蓉区',
    'letter' => 'r',
    'listorder' => '0',
  ),
  1996 => 
  array (
    'id' => '430103',
    'parentid' => '430100',
    'parentids' => '430000,430100,430103',
    'level' => '3',
    'name' => '天心区',
    'letter' => 't',
    'listorder' => '0',
  ),
  1997 => 
  array (
    'id' => '430104',
    'parentid' => '430100',
    'parentids' => '430000,430100,430104',
    'level' => '3',
    'name' => '岳麓区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  1998 => 
  array (
    'id' => '430105',
    'parentid' => '430100',
    'parentids' => '430000,430100,430105',
    'level' => '3',
    'name' => '开福区',
    'letter' => 'k',
    'listorder' => '0',
  ),
  1999 => 
  array (
    'id' => '430111',
    'parentid' => '430100',
    'parentids' => '430000,430100,430111',
    'level' => '3',
    'name' => '雨花区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2000 => 
  array (
    'id' => '430121',
    'parentid' => '430100',
    'parentids' => '430000,430100,430121',
    'level' => '3',
    'name' => '长沙县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2001 => 
  array (
    'id' => '430122',
    'parentid' => '430100',
    'parentids' => '430000,430100,430122',
    'level' => '3',
    'name' => '望城县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2002 => 
  array (
    'id' => '430124',
    'parentid' => '430100',
    'parentids' => '430000,430100,430124',
    'level' => '3',
    'name' => '宁乡县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2003 => 
  array (
    'id' => '430181',
    'parentid' => '430100',
    'parentids' => '430000,430100,430181',
    'level' => '3',
    'name' => '浏阳市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2004 => 
  array (
    'id' => '430200',
    'parentid' => '430000',
    'parentids' => '430000,430200',
    'level' => '2',
    'name' => '株洲市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2005 => 
  array (
    'id' => '430201',
    'parentid' => '430200',
    'parentids' => '430000,430200,430201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2006 => 
  array (
    'id' => '430202',
    'parentid' => '430200',
    'parentids' => '430000,430200,430202',
    'level' => '3',
    'name' => '荷塘区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2007 => 
  array (
    'id' => '430203',
    'parentid' => '430200',
    'parentids' => '430000,430200,430203',
    'level' => '3',
    'name' => '芦淞区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2008 => 
  array (
    'id' => '430204',
    'parentid' => '430200',
    'parentids' => '430000,430200,430204',
    'level' => '3',
    'name' => '石峰区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2009 => 
  array (
    'id' => '430211',
    'parentid' => '430200',
    'parentids' => '430000,430200,430211',
    'level' => '3',
    'name' => '天元区',
    'letter' => 't',
    'listorder' => '0',
  ),
  2010 => 
  array (
    'id' => '430221',
    'parentid' => '430200',
    'parentids' => '430000,430200,430221',
    'level' => '3',
    'name' => '株洲县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2011 => 
  array (
    'id' => '430223',
    'parentid' => '430200',
    'parentids' => '430000,430200,430223',
    'level' => '3',
    'name' => '攸　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2012 => 
  array (
    'id' => '430224',
    'parentid' => '430200',
    'parentids' => '430000,430200,430224',
    'level' => '3',
    'name' => '茶陵县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2013 => 
  array (
    'id' => '430225',
    'parentid' => '430200',
    'parentids' => '430000,430200,430225',
    'level' => '3',
    'name' => '炎陵县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2014 => 
  array (
    'id' => '430281',
    'parentid' => '430200',
    'parentids' => '430000,430200,430281',
    'level' => '3',
    'name' => '醴陵市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2015 => 
  array (
    'id' => '430300',
    'parentid' => '430000',
    'parentids' => '430000,430300',
    'level' => '2',
    'name' => '湘潭市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2016 => 
  array (
    'id' => '430301',
    'parentid' => '430300',
    'parentids' => '430000,430300,430301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2017 => 
  array (
    'id' => '430302',
    'parentid' => '430300',
    'parentids' => '430000,430300,430302',
    'level' => '3',
    'name' => '雨湖区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2018 => 
  array (
    'id' => '430304',
    'parentid' => '430300',
    'parentids' => '430000,430300,430304',
    'level' => '3',
    'name' => '岳塘区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2019 => 
  array (
    'id' => '430321',
    'parentid' => '430300',
    'parentids' => '430000,430300,430321',
    'level' => '3',
    'name' => '湘潭县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2020 => 
  array (
    'id' => '430381',
    'parentid' => '430300',
    'parentids' => '430000,430300,430381',
    'level' => '3',
    'name' => '湘乡市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2021 => 
  array (
    'id' => '430382',
    'parentid' => '430300',
    'parentids' => '430000,430300,430382',
    'level' => '3',
    'name' => '韶山市',
    'letter' => 's',
    'listorder' => '0',
  ),
  2022 => 
  array (
    'id' => '430400',
    'parentid' => '430000',
    'parentids' => '430000,430400',
    'level' => '2',
    'name' => '衡阳市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2023 => 
  array (
    'id' => '430401',
    'parentid' => '430400',
    'parentids' => '430000,430400,430401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2024 => 
  array (
    'id' => '430405',
    'parentid' => '430400',
    'parentids' => '430000,430400,430405',
    'level' => '3',
    'name' => '珠晖区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2025 => 
  array (
    'id' => '430406',
    'parentid' => '430400',
    'parentids' => '430000,430400,430406',
    'level' => '3',
    'name' => '雁峰区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2026 => 
  array (
    'id' => '430407',
    'parentid' => '430400',
    'parentids' => '430000,430400,430407',
    'level' => '3',
    'name' => '石鼓区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2027 => 
  array (
    'id' => '430408',
    'parentid' => '430400',
    'parentids' => '430000,430400,430408',
    'level' => '3',
    'name' => '蒸湘区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2028 => 
  array (
    'id' => '430412',
    'parentid' => '430400',
    'parentids' => '430000,430400,430412',
    'level' => '3',
    'name' => '南岳区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2029 => 
  array (
    'id' => '430421',
    'parentid' => '430400',
    'parentids' => '430000,430400,430421',
    'level' => '3',
    'name' => '衡阳县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2030 => 
  array (
    'id' => '430422',
    'parentid' => '430400',
    'parentids' => '430000,430400,430422',
    'level' => '3',
    'name' => '衡南县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2031 => 
  array (
    'id' => '430423',
    'parentid' => '430400',
    'parentids' => '430000,430400,430423',
    'level' => '3',
    'name' => '衡山县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2032 => 
  array (
    'id' => '430424',
    'parentid' => '430400',
    'parentids' => '430000,430400,430424',
    'level' => '3',
    'name' => '衡东县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2033 => 
  array (
    'id' => '430426',
    'parentid' => '430400',
    'parentids' => '430000,430400,430426',
    'level' => '3',
    'name' => '祁东县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2034 => 
  array (
    'id' => '430481',
    'parentid' => '430400',
    'parentids' => '430000,430400,430481',
    'level' => '3',
    'name' => '耒阳市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2035 => 
  array (
    'id' => '430482',
    'parentid' => '430400',
    'parentids' => '430000,430400,430482',
    'level' => '3',
    'name' => '常宁市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2036 => 
  array (
    'id' => '430500',
    'parentid' => '430000',
    'parentids' => '430000,430500',
    'level' => '2',
    'name' => '邵阳市',
    'letter' => 's',
    'listorder' => '0',
  ),
  2037 => 
  array (
    'id' => '430501',
    'parentid' => '430500',
    'parentids' => '430000,430500,430501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2038 => 
  array (
    'id' => '430502',
    'parentid' => '430500',
    'parentids' => '430000,430500,430502',
    'level' => '3',
    'name' => '双清区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2039 => 
  array (
    'id' => '430503',
    'parentid' => '430500',
    'parentids' => '430000,430500,430503',
    'level' => '3',
    'name' => '大祥区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2040 => 
  array (
    'id' => '430511',
    'parentid' => '430500',
    'parentids' => '430000,430500,430511',
    'level' => '3',
    'name' => '北塔区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2041 => 
  array (
    'id' => '430521',
    'parentid' => '430500',
    'parentids' => '430000,430500,430521',
    'level' => '3',
    'name' => '邵东县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2042 => 
  array (
    'id' => '430522',
    'parentid' => '430500',
    'parentids' => '430000,430500,430522',
    'level' => '3',
    'name' => '新邵县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2043 => 
  array (
    'id' => '430523',
    'parentid' => '430500',
    'parentids' => '430000,430500,430523',
    'level' => '3',
    'name' => '邵阳县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2044 => 
  array (
    'id' => '430524',
    'parentid' => '430500',
    'parentids' => '430000,430500,430524',
    'level' => '3',
    'name' => '隆回县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2045 => 
  array (
    'id' => '430525',
    'parentid' => '430500',
    'parentids' => '430000,430500,430525',
    'level' => '3',
    'name' => '洞口县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2046 => 
  array (
    'id' => '430527',
    'parentid' => '430500',
    'parentids' => '430000,430500,430527',
    'level' => '3',
    'name' => '绥宁县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2047 => 
  array (
    'id' => '430528',
    'parentid' => '430500',
    'parentids' => '430000,430500,430528',
    'level' => '3',
    'name' => '新宁县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2048 => 
  array (
    'id' => '430529',
    'parentid' => '430500',
    'parentids' => '430000,430500,430529',
    'level' => '3',
    'name' => '城步苗族自治县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2049 => 
  array (
    'id' => '430581',
    'parentid' => '430500',
    'parentids' => '430000,430500,430581',
    'level' => '3',
    'name' => '武冈市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2050 => 
  array (
    'id' => '430600',
    'parentid' => '430000',
    'parentids' => '430000,430600',
    'level' => '2',
    'name' => '岳阳市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2051 => 
  array (
    'id' => '430601',
    'parentid' => '430600',
    'parentids' => '430000,430600,430601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2052 => 
  array (
    'id' => '430602',
    'parentid' => '430600',
    'parentids' => '430000,430600,430602',
    'level' => '3',
    'name' => '岳阳楼区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2053 => 
  array (
    'id' => '430603',
    'parentid' => '430600',
    'parentids' => '430000,430600,430603',
    'level' => '3',
    'name' => '云溪区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2054 => 
  array (
    'id' => '430611',
    'parentid' => '430600',
    'parentids' => '430000,430600,430611',
    'level' => '3',
    'name' => '君山区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2055 => 
  array (
    'id' => '430621',
    'parentid' => '430600',
    'parentids' => '430000,430600,430621',
    'level' => '3',
    'name' => '岳阳县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2056 => 
  array (
    'id' => '430623',
    'parentid' => '430600',
    'parentids' => '430000,430600,430623',
    'level' => '3',
    'name' => '华容县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2057 => 
  array (
    'id' => '430624',
    'parentid' => '430600',
    'parentids' => '430000,430600,430624',
    'level' => '3',
    'name' => '湘阴县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2058 => 
  array (
    'id' => '430626',
    'parentid' => '430600',
    'parentids' => '430000,430600,430626',
    'level' => '3',
    'name' => '平江县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2059 => 
  array (
    'id' => '430681',
    'parentid' => '430600',
    'parentids' => '430000,430600,430681',
    'level' => '3',
    'name' => '汨罗市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2060 => 
  array (
    'id' => '430682',
    'parentid' => '430600',
    'parentids' => '430000,430600,430682',
    'level' => '3',
    'name' => '临湘市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2061 => 
  array (
    'id' => '430700',
    'parentid' => '430000',
    'parentids' => '430000,430700',
    'level' => '2',
    'name' => '常德市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2062 => 
  array (
    'id' => '430701',
    'parentid' => '430700',
    'parentids' => '430000,430700,430701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2063 => 
  array (
    'id' => '430702',
    'parentid' => '430700',
    'parentids' => '430000,430700,430702',
    'level' => '3',
    'name' => '武陵区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2064 => 
  array (
    'id' => '430703',
    'parentid' => '430700',
    'parentids' => '430000,430700,430703',
    'level' => '3',
    'name' => '鼎城区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2065 => 
  array (
    'id' => '430721',
    'parentid' => '430700',
    'parentids' => '430000,430700,430721',
    'level' => '3',
    'name' => '安乡县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  2066 => 
  array (
    'id' => '430722',
    'parentid' => '430700',
    'parentids' => '430000,430700,430722',
    'level' => '3',
    'name' => '汉寿县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2067 => 
  array (
    'id' => '430723',
    'parentid' => '430700',
    'parentids' => '430000,430700,430723',
    'level' => '3',
    'name' => '澧　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2068 => 
  array (
    'id' => '430724',
    'parentid' => '430700',
    'parentids' => '430000,430700,430724',
    'level' => '3',
    'name' => '临澧县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2069 => 
  array (
    'id' => '430725',
    'parentid' => '430700',
    'parentids' => '430000,430700,430725',
    'level' => '3',
    'name' => '桃源县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2070 => 
  array (
    'id' => '430726',
    'parentid' => '430700',
    'parentids' => '430000,430700,430726',
    'level' => '3',
    'name' => '石门县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2071 => 
  array (
    'id' => '430781',
    'parentid' => '430700',
    'parentids' => '430000,430700,430781',
    'level' => '3',
    'name' => '津市市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2072 => 
  array (
    'id' => '430800',
    'parentid' => '430000',
    'parentids' => '430000,430800',
    'level' => '2',
    'name' => '张家界市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2073 => 
  array (
    'id' => '430801',
    'parentid' => '430800',
    'parentids' => '430000,430800,430801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2074 => 
  array (
    'id' => '430802',
    'parentid' => '430800',
    'parentids' => '430000,430800,430802',
    'level' => '3',
    'name' => '永定区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2075 => 
  array (
    'id' => '430811',
    'parentid' => '430800',
    'parentids' => '430000,430800,430811',
    'level' => '3',
    'name' => '武陵源区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2076 => 
  array (
    'id' => '430821',
    'parentid' => '430800',
    'parentids' => '430000,430800,430821',
    'level' => '3',
    'name' => '慈利县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2077 => 
  array (
    'id' => '430822',
    'parentid' => '430800',
    'parentids' => '430000,430800,430822',
    'level' => '3',
    'name' => '桑植县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2078 => 
  array (
    'id' => '430900',
    'parentid' => '430000',
    'parentids' => '430000,430900',
    'level' => '2',
    'name' => '益阳市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2079 => 
  array (
    'id' => '430901',
    'parentid' => '430900',
    'parentids' => '430000,430900,430901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2080 => 
  array (
    'id' => '430902',
    'parentid' => '430900',
    'parentids' => '430000,430900,430902',
    'level' => '3',
    'name' => '资阳区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2081 => 
  array (
    'id' => '430903',
    'parentid' => '430900',
    'parentids' => '430000,430900,430903',
    'level' => '3',
    'name' => '赫山区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2082 => 
  array (
    'id' => '430921',
    'parentid' => '430900',
    'parentids' => '430000,430900,430921',
    'level' => '3',
    'name' => '南　县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2083 => 
  array (
    'id' => '430922',
    'parentid' => '430900',
    'parentids' => '430000,430900,430922',
    'level' => '3',
    'name' => '桃江县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2084 => 
  array (
    'id' => '430923',
    'parentid' => '430900',
    'parentids' => '430000,430900,430923',
    'level' => '3',
    'name' => '安化县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  2085 => 
  array (
    'id' => '430981',
    'parentid' => '430900',
    'parentids' => '430000,430900,430981',
    'level' => '3',
    'name' => '沅江市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2086 => 
  array (
    'id' => '431000',
    'parentid' => '430000',
    'parentids' => '430000,431000',
    'level' => '2',
    'name' => '郴州市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2087 => 
  array (
    'id' => '431001',
    'parentid' => '431000',
    'parentids' => '430000,431000,431001',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2088 => 
  array (
    'id' => '431002',
    'parentid' => '431000',
    'parentids' => '430000,431000,431002',
    'level' => '3',
    'name' => '北湖区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2089 => 
  array (
    'id' => '431003',
    'parentid' => '431000',
    'parentids' => '430000,431000,431003',
    'level' => '3',
    'name' => '苏仙区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2090 => 
  array (
    'id' => '431021',
    'parentid' => '431000',
    'parentids' => '430000,431000,431021',
    'level' => '3',
    'name' => '桂阳县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2091 => 
  array (
    'id' => '431022',
    'parentid' => '431000',
    'parentids' => '430000,431000,431022',
    'level' => '3',
    'name' => '宜章县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2092 => 
  array (
    'id' => '431023',
    'parentid' => '431000',
    'parentids' => '430000,431000,431023',
    'level' => '3',
    'name' => '永兴县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2093 => 
  array (
    'id' => '431024',
    'parentid' => '431000',
    'parentids' => '430000,431000,431024',
    'level' => '3',
    'name' => '嘉禾县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2094 => 
  array (
    'id' => '431025',
    'parentid' => '431000',
    'parentids' => '430000,431000,431025',
    'level' => '3',
    'name' => '临武县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2095 => 
  array (
    'id' => '431026',
    'parentid' => '431000',
    'parentids' => '430000,431000,431026',
    'level' => '3',
    'name' => '汝城县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  2096 => 
  array (
    'id' => '431027',
    'parentid' => '431000',
    'parentids' => '430000,431000,431027',
    'level' => '3',
    'name' => '桂东县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2097 => 
  array (
    'id' => '431028',
    'parentid' => '431000',
    'parentids' => '430000,431000,431028',
    'level' => '3',
    'name' => '安仁县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  2098 => 
  array (
    'id' => '431081',
    'parentid' => '431000',
    'parentids' => '430000,431000,431081',
    'level' => '3',
    'name' => '资兴市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2099 => 
  array (
    'id' => '431100',
    'parentid' => '430000',
    'parentids' => '430000,431100',
    'level' => '2',
    'name' => '永州市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2100 => 
  array (
    'id' => '431101',
    'parentid' => '431100',
    'parentids' => '430000,431100,431101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2101 => 
  array (
    'id' => '431102',
    'parentid' => '431100',
    'parentids' => '430000,431100,431102',
    'level' => '3',
    'name' => '芝山区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2102 => 
  array (
    'id' => '431103',
    'parentid' => '431100',
    'parentids' => '430000,431100,431103',
    'level' => '3',
    'name' => '冷水滩区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2103 => 
  array (
    'id' => '431121',
    'parentid' => '431100',
    'parentids' => '430000,431100,431121',
    'level' => '3',
    'name' => '祁阳县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2104 => 
  array (
    'id' => '431122',
    'parentid' => '431100',
    'parentids' => '430000,431100,431122',
    'level' => '3',
    'name' => '东安县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2105 => 
  array (
    'id' => '431123',
    'parentid' => '431100',
    'parentids' => '430000,431100,431123',
    'level' => '3',
    'name' => '双牌县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2106 => 
  array (
    'id' => '431124',
    'parentid' => '431100',
    'parentids' => '430000,431100,431124',
    'level' => '3',
    'name' => '道　县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2107 => 
  array (
    'id' => '431125',
    'parentid' => '431100',
    'parentids' => '430000,431100,431125',
    'level' => '3',
    'name' => '江永县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2108 => 
  array (
    'id' => '431126',
    'parentid' => '431100',
    'parentids' => '430000,431100,431126',
    'level' => '3',
    'name' => '宁远县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2109 => 
  array (
    'id' => '431127',
    'parentid' => '431100',
    'parentids' => '430000,431100,431127',
    'level' => '3',
    'name' => '蓝山县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2110 => 
  array (
    'id' => '431128',
    'parentid' => '431100',
    'parentids' => '430000,431100,431128',
    'level' => '3',
    'name' => '新田县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2111 => 
  array (
    'id' => '431129',
    'parentid' => '431100',
    'parentids' => '430000,431100,431129',
    'level' => '3',
    'name' => '江华瑶族自治县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2112 => 
  array (
    'id' => '431200',
    'parentid' => '430000',
    'parentids' => '430000,431200',
    'level' => '2',
    'name' => '怀化市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2113 => 
  array (
    'id' => '431201',
    'parentid' => '431200',
    'parentids' => '430000,431200,431201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2114 => 
  array (
    'id' => '431202',
    'parentid' => '431200',
    'parentids' => '430000,431200,431202',
    'level' => '3',
    'name' => '鹤城区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2115 => 
  array (
    'id' => '431221',
    'parentid' => '431200',
    'parentids' => '430000,431200,431221',
    'level' => '3',
    'name' => '中方县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2116 => 
  array (
    'id' => '431222',
    'parentid' => '431200',
    'parentids' => '430000,431200,431222',
    'level' => '3',
    'name' => '沅陵县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2117 => 
  array (
    'id' => '431223',
    'parentid' => '431200',
    'parentids' => '430000,431200,431223',
    'level' => '3',
    'name' => '辰溪县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2118 => 
  array (
    'id' => '431224',
    'parentid' => '431200',
    'parentids' => '430000,431200,431224',
    'level' => '3',
    'name' => '溆浦县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2119 => 
  array (
    'id' => '431225',
    'parentid' => '431200',
    'parentids' => '430000,431200,431225',
    'level' => '3',
    'name' => '会同县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2120 => 
  array (
    'id' => '431226',
    'parentid' => '431200',
    'parentids' => '430000,431200,431226',
    'level' => '3',
    'name' => '麻阳苗族自治县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2121 => 
  array (
    'id' => '431227',
    'parentid' => '431200',
    'parentids' => '430000,431200,431227',
    'level' => '3',
    'name' => '新晃侗族自治县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2122 => 
  array (
    'id' => '431228',
    'parentid' => '431200',
    'parentids' => '430000,431200,431228',
    'level' => '3',
    'name' => '芷江侗族自治县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2123 => 
  array (
    'id' => '431229',
    'parentid' => '431200',
    'parentids' => '430000,431200,431229',
    'level' => '3',
    'name' => '靖州苗族侗族自治县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2124 => 
  array (
    'id' => '431230',
    'parentid' => '431200',
    'parentids' => '430000,431200,431230',
    'level' => '3',
    'name' => '通道侗族自治县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2125 => 
  array (
    'id' => '431281',
    'parentid' => '431200',
    'parentids' => '430000,431200,431281',
    'level' => '3',
    'name' => '洪江市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2126 => 
  array (
    'id' => '431300',
    'parentid' => '430000',
    'parentids' => '430000,431300',
    'level' => '2',
    'name' => '娄底市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2127 => 
  array (
    'id' => '431301',
    'parentid' => '431300',
    'parentids' => '430000,431300,431301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2128 => 
  array (
    'id' => '431302',
    'parentid' => '431300',
    'parentids' => '430000,431300,431302',
    'level' => '3',
    'name' => '娄星区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2129 => 
  array (
    'id' => '431321',
    'parentid' => '431300',
    'parentids' => '430000,431300,431321',
    'level' => '3',
    'name' => '双峰县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2130 => 
  array (
    'id' => '431322',
    'parentid' => '431300',
    'parentids' => '430000,431300,431322',
    'level' => '3',
    'name' => '新化县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2131 => 
  array (
    'id' => '431381',
    'parentid' => '431300',
    'parentids' => '430000,431300,431381',
    'level' => '3',
    'name' => '冷水江市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2132 => 
  array (
    'id' => '431382',
    'parentid' => '431300',
    'parentids' => '430000,431300,431382',
    'level' => '3',
    'name' => '涟源市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2133 => 
  array (
    'id' => '433100',
    'parentid' => '430000',
    'parentids' => '430000,433100',
    'level' => '2',
    'name' => '湘西土家族苗族自治州',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2134 => 
  array (
    'id' => '433101',
    'parentid' => '433100',
    'parentids' => '430000,433100,433101',
    'level' => '3',
    'name' => '吉首市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2135 => 
  array (
    'id' => '433122',
    'parentid' => '433100',
    'parentids' => '430000,433100,433122',
    'level' => '3',
    'name' => '泸溪县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2136 => 
  array (
    'id' => '433123',
    'parentid' => '433100',
    'parentids' => '430000,433100,433123',
    'level' => '3',
    'name' => '凤凰县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2137 => 
  array (
    'id' => '433124',
    'parentid' => '433100',
    'parentids' => '430000,433100,433124',
    'level' => '3',
    'name' => '花垣县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2138 => 
  array (
    'id' => '433125',
    'parentid' => '433100',
    'parentids' => '430000,433100,433125',
    'level' => '3',
    'name' => '保靖县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2139 => 
  array (
    'id' => '433126',
    'parentid' => '433100',
    'parentids' => '430000,433100,433126',
    'level' => '3',
    'name' => '古丈县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2140 => 
  array (
    'id' => '433127',
    'parentid' => '433100',
    'parentids' => '430000,433100,433127',
    'level' => '3',
    'name' => '永顺县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2141 => 
  array (
    'id' => '433130',
    'parentid' => '433100',
    'parentids' => '430000,433100,433130',
    'level' => '3',
    'name' => '龙山县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2142 => 
  array (
    'id' => '440000',
    'parentid' => '0',
    'parentids' => '440000',
    'level' => '1',
    'name' => '广东省',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2143 => 
  array (
    'id' => '440100',
    'parentid' => '440000',
    'parentids' => '440000,440100',
    'level' => '2',
    'name' => '广州市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2144 => 
  array (
    'id' => '440101',
    'parentid' => '440100',
    'parentids' => '440000,440100,440101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2145 => 
  array (
    'id' => '440102',
    'parentid' => '440100',
    'parentids' => '440000,440100,440102',
    'level' => '3',
    'name' => '东山区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2146 => 
  array (
    'id' => '440103',
    'parentid' => '440100',
    'parentids' => '440000,440100,440103',
    'level' => '3',
    'name' => '荔湾区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2147 => 
  array (
    'id' => '440104',
    'parentid' => '440100',
    'parentids' => '440000,440100,440104',
    'level' => '3',
    'name' => '越秀区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2148 => 
  array (
    'id' => '440105',
    'parentid' => '440100',
    'parentids' => '440000,440100,440105',
    'level' => '3',
    'name' => '海珠区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2149 => 
  array (
    'id' => '440106',
    'parentid' => '440100',
    'parentids' => '440000,440100,440106',
    'level' => '3',
    'name' => '天河区',
    'letter' => 't',
    'listorder' => '0',
  ),
  2150 => 
  array (
    'id' => '440107',
    'parentid' => '440100',
    'parentids' => '440000,440100,440107',
    'level' => '3',
    'name' => '芳村区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2151 => 
  array (
    'id' => '440111',
    'parentid' => '440100',
    'parentids' => '440000,440100,440111',
    'level' => '3',
    'name' => '白云区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2152 => 
  array (
    'id' => '440112',
    'parentid' => '440100',
    'parentids' => '440000,440100,440112',
    'level' => '3',
    'name' => '黄埔区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2153 => 
  array (
    'id' => '440113',
    'parentid' => '440100',
    'parentids' => '440000,440100,440113',
    'level' => '3',
    'name' => '番禺区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2154 => 
  array (
    'id' => '440114',
    'parentid' => '440100',
    'parentids' => '440000,440100,440114',
    'level' => '3',
    'name' => '花都区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2155 => 
  array (
    'id' => '440183',
    'parentid' => '440100',
    'parentids' => '440000,440100,440183',
    'level' => '3',
    'name' => '增城市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2156 => 
  array (
    'id' => '440184',
    'parentid' => '440100',
    'parentids' => '440000,440100,440184',
    'level' => '3',
    'name' => '从化市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2157 => 
  array (
    'id' => '440200',
    'parentid' => '440000',
    'parentids' => '440000,440200',
    'level' => '2',
    'name' => '韶关市',
    'letter' => 's',
    'listorder' => '0',
  ),
  2158 => 
  array (
    'id' => '440201',
    'parentid' => '440200',
    'parentids' => '440000,440200,440201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2159 => 
  array (
    'id' => '440203',
    'parentid' => '440200',
    'parentids' => '440000,440200,440203',
    'level' => '3',
    'name' => '武江区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2160 => 
  array (
    'id' => '440204',
    'parentid' => '440200',
    'parentids' => '440000,440200,440204',
    'level' => '3',
    'name' => '浈江区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2161 => 
  array (
    'id' => '440205',
    'parentid' => '440200',
    'parentids' => '440000,440200,440205',
    'level' => '3',
    'name' => '曲江区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2162 => 
  array (
    'id' => '440222',
    'parentid' => '440200',
    'parentids' => '440000,440200,440222',
    'level' => '3',
    'name' => '始兴县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2163 => 
  array (
    'id' => '440224',
    'parentid' => '440200',
    'parentids' => '440000,440200,440224',
    'level' => '3',
    'name' => '仁化县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  2164 => 
  array (
    'id' => '440229',
    'parentid' => '440200',
    'parentids' => '440000,440200,440229',
    'level' => '3',
    'name' => '翁源县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2165 => 
  array (
    'id' => '440232',
    'parentid' => '440200',
    'parentids' => '440000,440200,440232',
    'level' => '3',
    'name' => '乳源瑶族自治县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  2166 => 
  array (
    'id' => '440233',
    'parentid' => '440200',
    'parentids' => '440000,440200,440233',
    'level' => '3',
    'name' => '新丰县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2167 => 
  array (
    'id' => '440281',
    'parentid' => '440200',
    'parentids' => '440000,440200,440281',
    'level' => '3',
    'name' => '乐昌市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2168 => 
  array (
    'id' => '440282',
    'parentid' => '440200',
    'parentids' => '440000,440200,440282',
    'level' => '3',
    'name' => '南雄市',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2169 => 
  array (
    'id' => '440300',
    'parentid' => '440000',
    'parentids' => '440000,440300',
    'level' => '2',
    'name' => '深圳市',
    'letter' => 's',
    'listorder' => '0',
  ),
  2170 => 
  array (
    'id' => '440301',
    'parentid' => '440300',
    'parentids' => '440000,440300,440301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2171 => 
  array (
    'id' => '440303',
    'parentid' => '440300',
    'parentids' => '440000,440300,440303',
    'level' => '3',
    'name' => '罗湖区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2172 => 
  array (
    'id' => '440304',
    'parentid' => '440300',
    'parentids' => '440000,440300,440304',
    'level' => '3',
    'name' => '福田区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2173 => 
  array (
    'id' => '440305',
    'parentid' => '440300',
    'parentids' => '440000,440300,440305',
    'level' => '3',
    'name' => '南山区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2174 => 
  array (
    'id' => '440306',
    'parentid' => '440300',
    'parentids' => '440000,440300,440306',
    'level' => '3',
    'name' => '宝安区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2175 => 
  array (
    'id' => '440307',
    'parentid' => '440300',
    'parentids' => '440000,440300,440307',
    'level' => '3',
    'name' => '龙岗区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2176 => 
  array (
    'id' => '440308',
    'parentid' => '440300',
    'parentids' => '440000,440300,440308',
    'level' => '3',
    'name' => '盐田区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2177 => 
  array (
    'id' => '440400',
    'parentid' => '440000',
    'parentids' => '440000,440400',
    'level' => '2',
    'name' => '珠海市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2178 => 
  array (
    'id' => '440401',
    'parentid' => '440400',
    'parentids' => '440000,440400,440401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2179 => 
  array (
    'id' => '440402',
    'parentid' => '440400',
    'parentids' => '440000,440400,440402',
    'level' => '3',
    'name' => '香洲区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2180 => 
  array (
    'id' => '440403',
    'parentid' => '440400',
    'parentids' => '440000,440400,440403',
    'level' => '3',
    'name' => '斗门区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2181 => 
  array (
    'id' => '440404',
    'parentid' => '440400',
    'parentids' => '440000,440400,440404',
    'level' => '3',
    'name' => '金湾区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2182 => 
  array (
    'id' => '440500',
    'parentid' => '440000',
    'parentids' => '440000,440500',
    'level' => '2',
    'name' => '汕头市',
    'letter' => 's',
    'listorder' => '0',
  ),
  2183 => 
  array (
    'id' => '440501',
    'parentid' => '440500',
    'parentids' => '440000,440500,440501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2184 => 
  array (
    'id' => '440507',
    'parentid' => '440500',
    'parentids' => '440000,440500,440507',
    'level' => '3',
    'name' => '龙湖区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2185 => 
  array (
    'id' => '440511',
    'parentid' => '440500',
    'parentids' => '440000,440500,440511',
    'level' => '3',
    'name' => '金平区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2186 => 
  array (
    'id' => '440512',
    'parentid' => '440500',
    'parentids' => '440000,440500,440512',
    'level' => '3',
    'name' => '濠江区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2187 => 
  array (
    'id' => '440513',
    'parentid' => '440500',
    'parentids' => '440000,440500,440513',
    'level' => '3',
    'name' => '潮阳区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2188 => 
  array (
    'id' => '440514',
    'parentid' => '440500',
    'parentids' => '440000,440500,440514',
    'level' => '3',
    'name' => '潮南区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2189 => 
  array (
    'id' => '440515',
    'parentid' => '440500',
    'parentids' => '440000,440500,440515',
    'level' => '3',
    'name' => '澄海区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2190 => 
  array (
    'id' => '440523',
    'parentid' => '440500',
    'parentids' => '440000,440500,440523',
    'level' => '3',
    'name' => '南澳县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2191 => 
  array (
    'id' => '440600',
    'parentid' => '440000',
    'parentids' => '440000,440600',
    'level' => '2',
    'name' => '佛山市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2192 => 
  array (
    'id' => '440601',
    'parentid' => '440600',
    'parentids' => '440000,440600,440601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2193 => 
  array (
    'id' => '440604',
    'parentid' => '440600',
    'parentids' => '440000,440600,440604',
    'level' => '3',
    'name' => '禅城区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2194 => 
  array (
    'id' => '440605',
    'parentid' => '440600',
    'parentids' => '440000,440600,440605',
    'level' => '3',
    'name' => '南海区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2195 => 
  array (
    'id' => '440606',
    'parentid' => '440600',
    'parentids' => '440000,440600,440606',
    'level' => '3',
    'name' => '顺德区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2196 => 
  array (
    'id' => '440607',
    'parentid' => '440600',
    'parentids' => '440000,440600,440607',
    'level' => '3',
    'name' => '三水区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2197 => 
  array (
    'id' => '440608',
    'parentid' => '440600',
    'parentids' => '440000,440600,440608',
    'level' => '3',
    'name' => '高明区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2198 => 
  array (
    'id' => '440700',
    'parentid' => '440000',
    'parentids' => '440000,440700',
    'level' => '2',
    'name' => '江门市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2199 => 
  array (
    'id' => '440701',
    'parentid' => '440700',
    'parentids' => '440000,440700,440701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2200 => 
  array (
    'id' => '440703',
    'parentid' => '440700',
    'parentids' => '440000,440700,440703',
    'level' => '3',
    'name' => '蓬江区',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2201 => 
  array (
    'id' => '440704',
    'parentid' => '440700',
    'parentids' => '440000,440700,440704',
    'level' => '3',
    'name' => '江海区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2202 => 
  array (
    'id' => '440705',
    'parentid' => '440700',
    'parentids' => '440000,440700,440705',
    'level' => '3',
    'name' => '新会区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2203 => 
  array (
    'id' => '440781',
    'parentid' => '440700',
    'parentids' => '440000,440700,440781',
    'level' => '3',
    'name' => '台山市',
    'letter' => 't',
    'listorder' => '0',
  ),
  2204 => 
  array (
    'id' => '440783',
    'parentid' => '440700',
    'parentids' => '440000,440700,440783',
    'level' => '3',
    'name' => '开平市',
    'letter' => 'k',
    'listorder' => '0',
  ),
  2205 => 
  array (
    'id' => '440784',
    'parentid' => '440700',
    'parentids' => '440000,440700,440784',
    'level' => '3',
    'name' => '鹤山市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2206 => 
  array (
    'id' => '440785',
    'parentid' => '440700',
    'parentids' => '440000,440700,440785',
    'level' => '3',
    'name' => '恩平市',
    'letter' => 'e',
    'listorder' => '0',
  ),
  2207 => 
  array (
    'id' => '440800',
    'parentid' => '440000',
    'parentids' => '440000,440800',
    'level' => '2',
    'name' => '湛江市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2208 => 
  array (
    'id' => '440801',
    'parentid' => '440800',
    'parentids' => '440000,440800,440801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2209 => 
  array (
    'id' => '440802',
    'parentid' => '440800',
    'parentids' => '440000,440800,440802',
    'level' => '3',
    'name' => '赤坎区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2210 => 
  array (
    'id' => '440803',
    'parentid' => '440800',
    'parentids' => '440000,440800,440803',
    'level' => '3',
    'name' => '霞山区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2211 => 
  array (
    'id' => '440804',
    'parentid' => '440800',
    'parentids' => '440000,440800,440804',
    'level' => '3',
    'name' => '坡头区',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2212 => 
  array (
    'id' => '440811',
    'parentid' => '440800',
    'parentids' => '440000,440800,440811',
    'level' => '3',
    'name' => '麻章区',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2213 => 
  array (
    'id' => '440823',
    'parentid' => '440800',
    'parentids' => '440000,440800,440823',
    'level' => '3',
    'name' => '遂溪县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2214 => 
  array (
    'id' => '440825',
    'parentid' => '440800',
    'parentids' => '440000,440800,440825',
    'level' => '3',
    'name' => '徐闻县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2215 => 
  array (
    'id' => '440881',
    'parentid' => '440800',
    'parentids' => '440000,440800,440881',
    'level' => '3',
    'name' => '廉江市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2216 => 
  array (
    'id' => '440882',
    'parentid' => '440800',
    'parentids' => '440000,440800,440882',
    'level' => '3',
    'name' => '雷州市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2217 => 
  array (
    'id' => '440883',
    'parentid' => '440800',
    'parentids' => '440000,440800,440883',
    'level' => '3',
    'name' => '吴川市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2218 => 
  array (
    'id' => '440900',
    'parentid' => '440000',
    'parentids' => '440000,440900',
    'level' => '2',
    'name' => '茂名市',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2219 => 
  array (
    'id' => '440901',
    'parentid' => '440900',
    'parentids' => '440000,440900,440901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2220 => 
  array (
    'id' => '440902',
    'parentid' => '440900',
    'parentids' => '440000,440900,440902',
    'level' => '3',
    'name' => '茂南区',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2221 => 
  array (
    'id' => '440903',
    'parentid' => '440900',
    'parentids' => '440000,440900,440903',
    'level' => '3',
    'name' => '茂港区',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2222 => 
  array (
    'id' => '440923',
    'parentid' => '440900',
    'parentids' => '440000,440900,440923',
    'level' => '3',
    'name' => '电白县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2223 => 
  array (
    'id' => '440981',
    'parentid' => '440900',
    'parentids' => '440000,440900,440981',
    'level' => '3',
    'name' => '高州市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2224 => 
  array (
    'id' => '440982',
    'parentid' => '440900',
    'parentids' => '440000,440900,440982',
    'level' => '3',
    'name' => '化州市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2225 => 
  array (
    'id' => '440983',
    'parentid' => '440900',
    'parentids' => '440000,440900,440983',
    'level' => '3',
    'name' => '信宜市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2226 => 
  array (
    'id' => '441200',
    'parentid' => '440000',
    'parentids' => '440000,441200',
    'level' => '2',
    'name' => '肇庆市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2227 => 
  array (
    'id' => '441201',
    'parentid' => '441200',
    'parentids' => '440000,441200,441201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2228 => 
  array (
    'id' => '441202',
    'parentid' => '441200',
    'parentids' => '440000,441200,441202',
    'level' => '3',
    'name' => '端州区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2229 => 
  array (
    'id' => '441203',
    'parentid' => '441200',
    'parentids' => '440000,441200,441203',
    'level' => '3',
    'name' => '鼎湖区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2230 => 
  array (
    'id' => '441223',
    'parentid' => '441200',
    'parentids' => '440000,441200,441223',
    'level' => '3',
    'name' => '广宁县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2231 => 
  array (
    'id' => '441224',
    'parentid' => '441200',
    'parentids' => '440000,441200,441224',
    'level' => '3',
    'name' => '怀集县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2232 => 
  array (
    'id' => '441225',
    'parentid' => '441200',
    'parentids' => '440000,441200,441225',
    'level' => '3',
    'name' => '封开县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2233 => 
  array (
    'id' => '441226',
    'parentid' => '441200',
    'parentids' => '440000,441200,441226',
    'level' => '3',
    'name' => '德庆县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2234 => 
  array (
    'id' => '441283',
    'parentid' => '441200',
    'parentids' => '440000,441200,441283',
    'level' => '3',
    'name' => '高要市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2235 => 
  array (
    'id' => '441284',
    'parentid' => '441200',
    'parentids' => '440000,441200,441284',
    'level' => '3',
    'name' => '四会市',
    'letter' => 's',
    'listorder' => '0',
  ),
  2236 => 
  array (
    'id' => '441300',
    'parentid' => '440000',
    'parentids' => '440000,441300',
    'level' => '2',
    'name' => '惠州市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2237 => 
  array (
    'id' => '441301',
    'parentid' => '441300',
    'parentids' => '440000,441300,441301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2238 => 
  array (
    'id' => '441302',
    'parentid' => '441300',
    'parentids' => '440000,441300,441302',
    'level' => '3',
    'name' => '惠城区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2239 => 
  array (
    'id' => '441303',
    'parentid' => '441300',
    'parentids' => '440000,441300,441303',
    'level' => '3',
    'name' => '惠阳区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2240 => 
  array (
    'id' => '441322',
    'parentid' => '441300',
    'parentids' => '440000,441300,441322',
    'level' => '3',
    'name' => '博罗县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2241 => 
  array (
    'id' => '441323',
    'parentid' => '441300',
    'parentids' => '440000,441300,441323',
    'level' => '3',
    'name' => '惠东县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2242 => 
  array (
    'id' => '441324',
    'parentid' => '441300',
    'parentids' => '440000,441300,441324',
    'level' => '3',
    'name' => '龙门县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2243 => 
  array (
    'id' => '441400',
    'parentid' => '440000',
    'parentids' => '440000,441400',
    'level' => '2',
    'name' => '梅州市',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2244 => 
  array (
    'id' => '441401',
    'parentid' => '441400',
    'parentids' => '440000,441400,441401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2245 => 
  array (
    'id' => '441402',
    'parentid' => '441400',
    'parentids' => '440000,441400,441402',
    'level' => '3',
    'name' => '梅江区',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2246 => 
  array (
    'id' => '441421',
    'parentid' => '441400',
    'parentids' => '440000,441400,441421',
    'level' => '3',
    'name' => '梅　县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2247 => 
  array (
    'id' => '441422',
    'parentid' => '441400',
    'parentids' => '440000,441400,441422',
    'level' => '3',
    'name' => '大埔县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2248 => 
  array (
    'id' => '441423',
    'parentid' => '441400',
    'parentids' => '440000,441400,441423',
    'level' => '3',
    'name' => '丰顺县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2249 => 
  array (
    'id' => '441424',
    'parentid' => '441400',
    'parentids' => '440000,441400,441424',
    'level' => '3',
    'name' => '五华县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2250 => 
  array (
    'id' => '441426',
    'parentid' => '441400',
    'parentids' => '440000,441400,441426',
    'level' => '3',
    'name' => '平远县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2251 => 
  array (
    'id' => '441427',
    'parentid' => '441400',
    'parentids' => '440000,441400,441427',
    'level' => '3',
    'name' => '蕉岭县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2252 => 
  array (
    'id' => '441481',
    'parentid' => '441400',
    'parentids' => '440000,441400,441481',
    'level' => '3',
    'name' => '兴宁市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2253 => 
  array (
    'id' => '441500',
    'parentid' => '440000',
    'parentids' => '440000,441500',
    'level' => '2',
    'name' => '汕尾市',
    'letter' => 's',
    'listorder' => '0',
  ),
  2254 => 
  array (
    'id' => '441501',
    'parentid' => '441500',
    'parentids' => '440000,441500,441501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2255 => 
  array (
    'id' => '441502',
    'parentid' => '441500',
    'parentids' => '440000,441500,441502',
    'level' => '3',
    'name' => '城　区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2256 => 
  array (
    'id' => '441521',
    'parentid' => '441500',
    'parentids' => '440000,441500,441521',
    'level' => '3',
    'name' => '海丰县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2257 => 
  array (
    'id' => '441523',
    'parentid' => '441500',
    'parentids' => '440000,441500,441523',
    'level' => '3',
    'name' => '陆河县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2258 => 
  array (
    'id' => '441581',
    'parentid' => '441500',
    'parentids' => '440000,441500,441581',
    'level' => '3',
    'name' => '陆丰市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2259 => 
  array (
    'id' => '441600',
    'parentid' => '440000',
    'parentids' => '440000,441600',
    'level' => '2',
    'name' => '河源市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2260 => 
  array (
    'id' => '441601',
    'parentid' => '441600',
    'parentids' => '440000,441600,441601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2261 => 
  array (
    'id' => '441602',
    'parentid' => '441600',
    'parentids' => '440000,441600,441602',
    'level' => '3',
    'name' => '源城区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2262 => 
  array (
    'id' => '441621',
    'parentid' => '441600',
    'parentids' => '440000,441600,441621',
    'level' => '3',
    'name' => '紫金县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2263 => 
  array (
    'id' => '441622',
    'parentid' => '441600',
    'parentids' => '440000,441600,441622',
    'level' => '3',
    'name' => '龙川县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2264 => 
  array (
    'id' => '441623',
    'parentid' => '441600',
    'parentids' => '440000,441600,441623',
    'level' => '3',
    'name' => '连平县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2265 => 
  array (
    'id' => '441624',
    'parentid' => '441600',
    'parentids' => '440000,441600,441624',
    'level' => '3',
    'name' => '和平县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2266 => 
  array (
    'id' => '441625',
    'parentid' => '441600',
    'parentids' => '440000,441600,441625',
    'level' => '3',
    'name' => '东源县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2267 => 
  array (
    'id' => '441700',
    'parentid' => '440000',
    'parentids' => '440000,441700',
    'level' => '2',
    'name' => '阳江市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2268 => 
  array (
    'id' => '441701',
    'parentid' => '441700',
    'parentids' => '440000,441700,441701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2269 => 
  array (
    'id' => '441702',
    'parentid' => '441700',
    'parentids' => '440000,441700,441702',
    'level' => '3',
    'name' => '江城区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2270 => 
  array (
    'id' => '441721',
    'parentid' => '441700',
    'parentids' => '440000,441700,441721',
    'level' => '3',
    'name' => '阳西县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2271 => 
  array (
    'id' => '441723',
    'parentid' => '441700',
    'parentids' => '440000,441700,441723',
    'level' => '3',
    'name' => '阳东县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2272 => 
  array (
    'id' => '441781',
    'parentid' => '441700',
    'parentids' => '440000,441700,441781',
    'level' => '3',
    'name' => '阳春市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2273 => 
  array (
    'id' => '441800',
    'parentid' => '440000',
    'parentids' => '440000,441800',
    'level' => '2',
    'name' => '清远市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2274 => 
  array (
    'id' => '441801',
    'parentid' => '441800',
    'parentids' => '440000,441800,441801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2275 => 
  array (
    'id' => '441802',
    'parentid' => '441800',
    'parentids' => '440000,441800,441802',
    'level' => '3',
    'name' => '清城区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2276 => 
  array (
    'id' => '441821',
    'parentid' => '441800',
    'parentids' => '440000,441800,441821',
    'level' => '3',
    'name' => '佛冈县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2277 => 
  array (
    'id' => '441823',
    'parentid' => '441800',
    'parentids' => '440000,441800,441823',
    'level' => '3',
    'name' => '阳山县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2278 => 
  array (
    'id' => '441825',
    'parentid' => '441800',
    'parentids' => '440000,441800,441825',
    'level' => '3',
    'name' => '连山壮族瑶族自治县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2279 => 
  array (
    'id' => '441826',
    'parentid' => '441800',
    'parentids' => '440000,441800,441826',
    'level' => '3',
    'name' => '连南瑶族自治县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2280 => 
  array (
    'id' => '441827',
    'parentid' => '441800',
    'parentids' => '440000,441800,441827',
    'level' => '3',
    'name' => '清新县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2281 => 
  array (
    'id' => '441881',
    'parentid' => '441800',
    'parentids' => '440000,441800,441881',
    'level' => '3',
    'name' => '英德市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2282 => 
  array (
    'id' => '441882',
    'parentid' => '441800',
    'parentids' => '440000,441800,441882',
    'level' => '3',
    'name' => '连州市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2283 => 
  array (
    'id' => '441900',
    'parentid' => '440000',
    'parentids' => '440000,441900',
    'level' => '2',
    'name' => '东莞市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2284 => 
  array (
    'id' => '442000',
    'parentid' => '440000',
    'parentids' => '440000,442000',
    'level' => '2',
    'name' => '中山市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2285 => 
  array (
    'id' => '445100',
    'parentid' => '440000',
    'parentids' => '440000,445100',
    'level' => '2',
    'name' => '潮州市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2286 => 
  array (
    'id' => '445101',
    'parentid' => '445100',
    'parentids' => '440000,445100,445101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2287 => 
  array (
    'id' => '445102',
    'parentid' => '445100',
    'parentids' => '440000,445100,445102',
    'level' => '3',
    'name' => '湘桥区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2288 => 
  array (
    'id' => '445121',
    'parentid' => '445100',
    'parentids' => '440000,445100,445121',
    'level' => '3',
    'name' => '潮安县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2289 => 
  array (
    'id' => '445122',
    'parentid' => '445100',
    'parentids' => '440000,445100,445122',
    'level' => '3',
    'name' => '饶平县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  2290 => 
  array (
    'id' => '445200',
    'parentid' => '440000',
    'parentids' => '440000,445200',
    'level' => '2',
    'name' => '揭阳市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2291 => 
  array (
    'id' => '445201',
    'parentid' => '445200',
    'parentids' => '440000,445200,445201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2292 => 
  array (
    'id' => '445202',
    'parentid' => '445200',
    'parentids' => '440000,445200,445202',
    'level' => '3',
    'name' => '榕城区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2293 => 
  array (
    'id' => '445221',
    'parentid' => '445200',
    'parentids' => '440000,445200,445221',
    'level' => '3',
    'name' => '揭东县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2294 => 
  array (
    'id' => '445222',
    'parentid' => '445200',
    'parentids' => '440000,445200,445222',
    'level' => '3',
    'name' => '揭西县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2295 => 
  array (
    'id' => '445224',
    'parentid' => '445200',
    'parentids' => '440000,445200,445224',
    'level' => '3',
    'name' => '惠来县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2296 => 
  array (
    'id' => '445281',
    'parentid' => '445200',
    'parentids' => '440000,445200,445281',
    'level' => '3',
    'name' => '普宁市',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2297 => 
  array (
    'id' => '445300',
    'parentid' => '440000',
    'parentids' => '440000,445300',
    'level' => '2',
    'name' => '云浮市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2298 => 
  array (
    'id' => '445301',
    'parentid' => '445300',
    'parentids' => '440000,445300,445301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2299 => 
  array (
    'id' => '445302',
    'parentid' => '445300',
    'parentids' => '440000,445300,445302',
    'level' => '3',
    'name' => '云城区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2300 => 
  array (
    'id' => '445321',
    'parentid' => '445300',
    'parentids' => '440000,445300,445321',
    'level' => '3',
    'name' => '新兴县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2301 => 
  array (
    'id' => '445322',
    'parentid' => '445300',
    'parentids' => '440000,445300,445322',
    'level' => '3',
    'name' => '郁南县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2302 => 
  array (
    'id' => '445323',
    'parentid' => '445300',
    'parentids' => '440000,445300,445323',
    'level' => '3',
    'name' => '云安县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2303 => 
  array (
    'id' => '445381',
    'parentid' => '445300',
    'parentids' => '440000,445300,445381',
    'level' => '3',
    'name' => '罗定市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2304 => 
  array (
    'id' => '450000',
    'parentid' => '0',
    'parentids' => '450000',
    'level' => '1',
    'name' => '广西壮族自治区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2305 => 
  array (
    'id' => '450100',
    'parentid' => '450000',
    'parentids' => '450000,450100',
    'level' => '2',
    'name' => '南宁市',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2306 => 
  array (
    'id' => '450101',
    'parentid' => '450100',
    'parentids' => '450000,450100,450101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2307 => 
  array (
    'id' => '450102',
    'parentid' => '450100',
    'parentids' => '450000,450100,450102',
    'level' => '3',
    'name' => '兴宁区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2308 => 
  array (
    'id' => '450103',
    'parentid' => '450100',
    'parentids' => '450000,450100,450103',
    'level' => '3',
    'name' => '青秀区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2309 => 
  array (
    'id' => '450105',
    'parentid' => '450100',
    'parentids' => '450000,450100,450105',
    'level' => '3',
    'name' => '江南区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2310 => 
  array (
    'id' => '450107',
    'parentid' => '450100',
    'parentids' => '450000,450100,450107',
    'level' => '3',
    'name' => '西乡塘区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2311 => 
  array (
    'id' => '450108',
    'parentid' => '450100',
    'parentids' => '450000,450100,450108',
    'level' => '3',
    'name' => '良庆区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2312 => 
  array (
    'id' => '450109',
    'parentid' => '450100',
    'parentids' => '450000,450100,450109',
    'level' => '3',
    'name' => '邕宁区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2313 => 
  array (
    'id' => '450122',
    'parentid' => '450100',
    'parentids' => '450000,450100,450122',
    'level' => '3',
    'name' => '武鸣县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2314 => 
  array (
    'id' => '450123',
    'parentid' => '450100',
    'parentids' => '450000,450100,450123',
    'level' => '3',
    'name' => '隆安县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2315 => 
  array (
    'id' => '450124',
    'parentid' => '450100',
    'parentids' => '450000,450100,450124',
    'level' => '3',
    'name' => '马山县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2316 => 
  array (
    'id' => '450125',
    'parentid' => '450100',
    'parentids' => '450000,450100,450125',
    'level' => '3',
    'name' => '上林县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2317 => 
  array (
    'id' => '450126',
    'parentid' => '450100',
    'parentids' => '450000,450100,450126',
    'level' => '3',
    'name' => '宾阳县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2318 => 
  array (
    'id' => '450127',
    'parentid' => '450100',
    'parentids' => '450000,450100,450127',
    'level' => '3',
    'name' => '横　县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2319 => 
  array (
    'id' => '450200',
    'parentid' => '450000',
    'parentids' => '450000,450200',
    'level' => '2',
    'name' => '柳州市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2320 => 
  array (
    'id' => '450201',
    'parentid' => '450200',
    'parentids' => '450000,450200,450201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2321 => 
  array (
    'id' => '450202',
    'parentid' => '450200',
    'parentids' => '450000,450200,450202',
    'level' => '3',
    'name' => '城中区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2322 => 
  array (
    'id' => '450203',
    'parentid' => '450200',
    'parentids' => '450000,450200,450203',
    'level' => '3',
    'name' => '鱼峰区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2323 => 
  array (
    'id' => '450204',
    'parentid' => '450200',
    'parentids' => '450000,450200,450204',
    'level' => '3',
    'name' => '柳南区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2324 => 
  array (
    'id' => '450205',
    'parentid' => '450200',
    'parentids' => '450000,450200,450205',
    'level' => '3',
    'name' => '柳北区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2325 => 
  array (
    'id' => '450221',
    'parentid' => '450200',
    'parentids' => '450000,450200,450221',
    'level' => '3',
    'name' => '柳江县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2326 => 
  array (
    'id' => '450222',
    'parentid' => '450200',
    'parentids' => '450000,450200,450222',
    'level' => '3',
    'name' => '柳城县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2327 => 
  array (
    'id' => '450223',
    'parentid' => '450200',
    'parentids' => '450000,450200,450223',
    'level' => '3',
    'name' => '鹿寨县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2328 => 
  array (
    'id' => '450224',
    'parentid' => '450200',
    'parentids' => '450000,450200,450224',
    'level' => '3',
    'name' => '融安县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  2329 => 
  array (
    'id' => '450225',
    'parentid' => '450200',
    'parentids' => '450000,450200,450225',
    'level' => '3',
    'name' => '融水苗族自治县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  2330 => 
  array (
    'id' => '450226',
    'parentid' => '450200',
    'parentids' => '450000,450200,450226',
    'level' => '3',
    'name' => '三江侗族自治县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2331 => 
  array (
    'id' => '450300',
    'parentid' => '450000',
    'parentids' => '450000,450300',
    'level' => '2',
    'name' => '桂林市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2332 => 
  array (
    'id' => '450301',
    'parentid' => '450300',
    'parentids' => '450000,450300,450301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2333 => 
  array (
    'id' => '450302',
    'parentid' => '450300',
    'parentids' => '450000,450300,450302',
    'level' => '3',
    'name' => '秀峰区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2334 => 
  array (
    'id' => '450303',
    'parentid' => '450300',
    'parentids' => '450000,450300,450303',
    'level' => '3',
    'name' => '叠彩区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2335 => 
  array (
    'id' => '450304',
    'parentid' => '450300',
    'parentids' => '450000,450300,450304',
    'level' => '3',
    'name' => '象山区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2336 => 
  array (
    'id' => '450305',
    'parentid' => '450300',
    'parentids' => '450000,450300,450305',
    'level' => '3',
    'name' => '七星区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2337 => 
  array (
    'id' => '450311',
    'parentid' => '450300',
    'parentids' => '450000,450300,450311',
    'level' => '3',
    'name' => '雁山区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2338 => 
  array (
    'id' => '450321',
    'parentid' => '450300',
    'parentids' => '450000,450300,450321',
    'level' => '3',
    'name' => '阳朔县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2339 => 
  array (
    'id' => '450322',
    'parentid' => '450300',
    'parentids' => '450000,450300,450322',
    'level' => '3',
    'name' => '临桂县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2340 => 
  array (
    'id' => '450323',
    'parentid' => '450300',
    'parentids' => '450000,450300,450323',
    'level' => '3',
    'name' => '灵川县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2341 => 
  array (
    'id' => '450324',
    'parentid' => '450300',
    'parentids' => '450000,450300,450324',
    'level' => '3',
    'name' => '全州县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2342 => 
  array (
    'id' => '450325',
    'parentid' => '450300',
    'parentids' => '450000,450300,450325',
    'level' => '3',
    'name' => '兴安县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2343 => 
  array (
    'id' => '450326',
    'parentid' => '450300',
    'parentids' => '450000,450300,450326',
    'level' => '3',
    'name' => '永福县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2344 => 
  array (
    'id' => '450327',
    'parentid' => '450300',
    'parentids' => '450000,450300,450327',
    'level' => '3',
    'name' => '灌阳县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2345 => 
  array (
    'id' => '450328',
    'parentid' => '450300',
    'parentids' => '450000,450300,450328',
    'level' => '3',
    'name' => '龙胜各族自治县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2346 => 
  array (
    'id' => '450329',
    'parentid' => '450300',
    'parentids' => '450000,450300,450329',
    'level' => '3',
    'name' => '资源县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2347 => 
  array (
    'id' => '450330',
    'parentid' => '450300',
    'parentids' => '450000,450300,450330',
    'level' => '3',
    'name' => '平乐县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2348 => 
  array (
    'id' => '450331',
    'parentid' => '450300',
    'parentids' => '450000,450300,450331',
    'level' => '3',
    'name' => '荔蒲县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2349 => 
  array (
    'id' => '450332',
    'parentid' => '450300',
    'parentids' => '450000,450300,450332',
    'level' => '3',
    'name' => '恭城瑶族自治县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2350 => 
  array (
    'id' => '450400',
    'parentid' => '450000',
    'parentids' => '450000,450400',
    'level' => '2',
    'name' => '梧州市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2351 => 
  array (
    'id' => '450401',
    'parentid' => '450400',
    'parentids' => '450000,450400,450401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2352 => 
  array (
    'id' => '450403',
    'parentid' => '450400',
    'parentids' => '450000,450400,450403',
    'level' => '3',
    'name' => '万秀区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2353 => 
  array (
    'id' => '450404',
    'parentid' => '450400',
    'parentids' => '450000,450400,450404',
    'level' => '3',
    'name' => '蝶山区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2354 => 
  array (
    'id' => '450405',
    'parentid' => '450400',
    'parentids' => '450000,450400,450405',
    'level' => '3',
    'name' => '长洲区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2355 => 
  array (
    'id' => '450421',
    'parentid' => '450400',
    'parentids' => '450000,450400,450421',
    'level' => '3',
    'name' => '苍梧县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2356 => 
  array (
    'id' => '450422',
    'parentid' => '450400',
    'parentids' => '450000,450400,450422',
    'level' => '3',
    'name' => '藤　县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2357 => 
  array (
    'id' => '450423',
    'parentid' => '450400',
    'parentids' => '450000,450400,450423',
    'level' => '3',
    'name' => '蒙山县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2358 => 
  array (
    'id' => '450481',
    'parentid' => '450400',
    'parentids' => '450000,450400,450481',
    'level' => '3',
    'name' => '岑溪市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2359 => 
  array (
    'id' => '450500',
    'parentid' => '450000',
    'parentids' => '450000,450500',
    'level' => '2',
    'name' => '北海市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2360 => 
  array (
    'id' => '450501',
    'parentid' => '450500',
    'parentids' => '450000,450500,450501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2361 => 
  array (
    'id' => '450502',
    'parentid' => '450500',
    'parentids' => '450000,450500,450502',
    'level' => '3',
    'name' => '海城区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2362 => 
  array (
    'id' => '450503',
    'parentid' => '450500',
    'parentids' => '450000,450500,450503',
    'level' => '3',
    'name' => '银海区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2363 => 
  array (
    'id' => '450512',
    'parentid' => '450500',
    'parentids' => '450000,450500,450512',
    'level' => '3',
    'name' => '铁山港区',
    'letter' => 't',
    'listorder' => '0',
  ),
  2364 => 
  array (
    'id' => '450521',
    'parentid' => '450500',
    'parentids' => '450000,450500,450521',
    'level' => '3',
    'name' => '合浦县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2365 => 
  array (
    'id' => '450600',
    'parentid' => '450000',
    'parentids' => '450000,450600',
    'level' => '2',
    'name' => '防城港市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2366 => 
  array (
    'id' => '450601',
    'parentid' => '450600',
    'parentids' => '450000,450600,450601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2367 => 
  array (
    'id' => '450602',
    'parentid' => '450600',
    'parentids' => '450000,450600,450602',
    'level' => '3',
    'name' => '港口区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2368 => 
  array (
    'id' => '450603',
    'parentid' => '450600',
    'parentids' => '450000,450600,450603',
    'level' => '3',
    'name' => '防城区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2369 => 
  array (
    'id' => '450621',
    'parentid' => '450600',
    'parentids' => '450000,450600,450621',
    'level' => '3',
    'name' => '上思县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2370 => 
  array (
    'id' => '450681',
    'parentid' => '450600',
    'parentids' => '450000,450600,450681',
    'level' => '3',
    'name' => '东兴市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2371 => 
  array (
    'id' => '450700',
    'parentid' => '450000',
    'parentids' => '450000,450700',
    'level' => '2',
    'name' => '钦州市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2372 => 
  array (
    'id' => '450701',
    'parentid' => '450700',
    'parentids' => '450000,450700,450701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2373 => 
  array (
    'id' => '450702',
    'parentid' => '450700',
    'parentids' => '450000,450700,450702',
    'level' => '3',
    'name' => '钦南区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2374 => 
  array (
    'id' => '450703',
    'parentid' => '450700',
    'parentids' => '450000,450700,450703',
    'level' => '3',
    'name' => '钦北区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2375 => 
  array (
    'id' => '450721',
    'parentid' => '450700',
    'parentids' => '450000,450700,450721',
    'level' => '3',
    'name' => '灵山县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2376 => 
  array (
    'id' => '450722',
    'parentid' => '450700',
    'parentids' => '450000,450700,450722',
    'level' => '3',
    'name' => '浦北县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2377 => 
  array (
    'id' => '450800',
    'parentid' => '450000',
    'parentids' => '450000,450800',
    'level' => '2',
    'name' => '贵港市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2378 => 
  array (
    'id' => '450801',
    'parentid' => '450800',
    'parentids' => '450000,450800,450801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2379 => 
  array (
    'id' => '450802',
    'parentid' => '450800',
    'parentids' => '450000,450800,450802',
    'level' => '3',
    'name' => '港北区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2380 => 
  array (
    'id' => '450803',
    'parentid' => '450800',
    'parentids' => '450000,450800,450803',
    'level' => '3',
    'name' => '港南区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2381 => 
  array (
    'id' => '450804',
    'parentid' => '450800',
    'parentids' => '450000,450800,450804',
    'level' => '3',
    'name' => '覃塘区',
    'letter' => 't',
    'listorder' => '0',
  ),
  2382 => 
  array (
    'id' => '450821',
    'parentid' => '450800',
    'parentids' => '450000,450800,450821',
    'level' => '3',
    'name' => '平南县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2383 => 
  array (
    'id' => '450881',
    'parentid' => '450800',
    'parentids' => '450000,450800,450881',
    'level' => '3',
    'name' => '桂平市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2384 => 
  array (
    'id' => '450900',
    'parentid' => '450000',
    'parentids' => '450000,450900',
    'level' => '2',
    'name' => '玉林市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2385 => 
  array (
    'id' => '450901',
    'parentid' => '450900',
    'parentids' => '450000,450900,450901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2386 => 
  array (
    'id' => '450902',
    'parentid' => '450900',
    'parentids' => '450000,450900,450902',
    'level' => '3',
    'name' => '玉州区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2387 => 
  array (
    'id' => '450921',
    'parentid' => '450900',
    'parentids' => '450000,450900,450921',
    'level' => '3',
    'name' => '容　县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  2388 => 
  array (
    'id' => '450922',
    'parentid' => '450900',
    'parentids' => '450000,450900,450922',
    'level' => '3',
    'name' => '陆川县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2389 => 
  array (
    'id' => '450923',
    'parentid' => '450900',
    'parentids' => '450000,450900,450923',
    'level' => '3',
    'name' => '博白县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2390 => 
  array (
    'id' => '450924',
    'parentid' => '450900',
    'parentids' => '450000,450900,450924',
    'level' => '3',
    'name' => '兴业县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2391 => 
  array (
    'id' => '450981',
    'parentid' => '450900',
    'parentids' => '450000,450900,450981',
    'level' => '3',
    'name' => '北流市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2392 => 
  array (
    'id' => '451000',
    'parentid' => '450000',
    'parentids' => '450000,451000',
    'level' => '2',
    'name' => '百色市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2393 => 
  array (
    'id' => '451001',
    'parentid' => '451000',
    'parentids' => '450000,451000,451001',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2394 => 
  array (
    'id' => '451002',
    'parentid' => '451000',
    'parentids' => '450000,451000,451002',
    'level' => '3',
    'name' => '右江区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2395 => 
  array (
    'id' => '451021',
    'parentid' => '451000',
    'parentids' => '450000,451000,451021',
    'level' => '3',
    'name' => '田阳县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2396 => 
  array (
    'id' => '451022',
    'parentid' => '451000',
    'parentids' => '450000,451000,451022',
    'level' => '3',
    'name' => '田东县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2397 => 
  array (
    'id' => '451023',
    'parentid' => '451000',
    'parentids' => '450000,451000,451023',
    'level' => '3',
    'name' => '平果县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2398 => 
  array (
    'id' => '451024',
    'parentid' => '451000',
    'parentids' => '450000,451000,451024',
    'level' => '3',
    'name' => '德保县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2399 => 
  array (
    'id' => '451025',
    'parentid' => '451000',
    'parentids' => '450000,451000,451025',
    'level' => '3',
    'name' => '靖西县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2400 => 
  array (
    'id' => '451026',
    'parentid' => '451000',
    'parentids' => '450000,451000,451026',
    'level' => '3',
    'name' => '那坡县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2401 => 
  array (
    'id' => '451027',
    'parentid' => '451000',
    'parentids' => '450000,451000,451027',
    'level' => '3',
    'name' => '凌云县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2402 => 
  array (
    'id' => '451028',
    'parentid' => '451000',
    'parentids' => '450000,451000,451028',
    'level' => '3',
    'name' => '乐业县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2403 => 
  array (
    'id' => '451029',
    'parentid' => '451000',
    'parentids' => '450000,451000,451029',
    'level' => '3',
    'name' => '田林县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2404 => 
  array (
    'id' => '451030',
    'parentid' => '451000',
    'parentids' => '450000,451000,451030',
    'level' => '3',
    'name' => '西林县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2405 => 
  array (
    'id' => '451031',
    'parentid' => '451000',
    'parentids' => '450000,451000,451031',
    'level' => '3',
    'name' => '隆林各族自治县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2406 => 
  array (
    'id' => '451100',
    'parentid' => '450000',
    'parentids' => '450000,451100',
    'level' => '2',
    'name' => '贺州市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2407 => 
  array (
    'id' => '451101',
    'parentid' => '451100',
    'parentids' => '450000,451100,451101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2408 => 
  array (
    'id' => '451102',
    'parentid' => '451100',
    'parentids' => '450000,451100,451102',
    'level' => '3',
    'name' => '八步区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2409 => 
  array (
    'id' => '451121',
    'parentid' => '451100',
    'parentids' => '450000,451100,451121',
    'level' => '3',
    'name' => '昭平县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2410 => 
  array (
    'id' => '451122',
    'parentid' => '451100',
    'parentids' => '450000,451100,451122',
    'level' => '3',
    'name' => '钟山县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2411 => 
  array (
    'id' => '451123',
    'parentid' => '451100',
    'parentids' => '450000,451100,451123',
    'level' => '3',
    'name' => '富川瑶族自治县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2412 => 
  array (
    'id' => '451200',
    'parentid' => '450000',
    'parentids' => '450000,451200',
    'level' => '2',
    'name' => '河池市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2413 => 
  array (
    'id' => '451201',
    'parentid' => '451200',
    'parentids' => '450000,451200,451201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2414 => 
  array (
    'id' => '451202',
    'parentid' => '451200',
    'parentids' => '450000,451200,451202',
    'level' => '3',
    'name' => '金城江区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2415 => 
  array (
    'id' => '451221',
    'parentid' => '451200',
    'parentids' => '450000,451200,451221',
    'level' => '3',
    'name' => '南丹县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2416 => 
  array (
    'id' => '451222',
    'parentid' => '451200',
    'parentids' => '450000,451200,451222',
    'level' => '3',
    'name' => '天峨县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2417 => 
  array (
    'id' => '451223',
    'parentid' => '451200',
    'parentids' => '450000,451200,451223',
    'level' => '3',
    'name' => '凤山县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2418 => 
  array (
    'id' => '451224',
    'parentid' => '451200',
    'parentids' => '450000,451200,451224',
    'level' => '3',
    'name' => '东兰县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2419 => 
  array (
    'id' => '451225',
    'parentid' => '451200',
    'parentids' => '450000,451200,451225',
    'level' => '3',
    'name' => '罗城仫佬族自治县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2420 => 
  array (
    'id' => '451226',
    'parentid' => '451200',
    'parentids' => '450000,451200,451226',
    'level' => '3',
    'name' => '环江毛南族自治县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2421 => 
  array (
    'id' => '451227',
    'parentid' => '451200',
    'parentids' => '450000,451200,451227',
    'level' => '3',
    'name' => '巴马瑶族自治县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2422 => 
  array (
    'id' => '451228',
    'parentid' => '451200',
    'parentids' => '450000,451200,451228',
    'level' => '3',
    'name' => '都安瑶族自治县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2423 => 
  array (
    'id' => '451229',
    'parentid' => '451200',
    'parentids' => '450000,451200,451229',
    'level' => '3',
    'name' => '大化瑶族自治县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2424 => 
  array (
    'id' => '451281',
    'parentid' => '451200',
    'parentids' => '450000,451200,451281',
    'level' => '3',
    'name' => '宜州市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2425 => 
  array (
    'id' => '451300',
    'parentid' => '450000',
    'parentids' => '450000,451300',
    'level' => '2',
    'name' => '来宾市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2426 => 
  array (
    'id' => '451301',
    'parentid' => '451300',
    'parentids' => '450000,451300,451301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2427 => 
  array (
    'id' => '451302',
    'parentid' => '451300',
    'parentids' => '450000,451300,451302',
    'level' => '3',
    'name' => '兴宾区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2428 => 
  array (
    'id' => '451321',
    'parentid' => '451300',
    'parentids' => '450000,451300,451321',
    'level' => '3',
    'name' => '忻城县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2429 => 
  array (
    'id' => '451322',
    'parentid' => '451300',
    'parentids' => '450000,451300,451322',
    'level' => '3',
    'name' => '象州县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2430 => 
  array (
    'id' => '451323',
    'parentid' => '451300',
    'parentids' => '450000,451300,451323',
    'level' => '3',
    'name' => '武宣县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2431 => 
  array (
    'id' => '451324',
    'parentid' => '451300',
    'parentids' => '450000,451300,451324',
    'level' => '3',
    'name' => '金秀瑶族自治县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2432 => 
  array (
    'id' => '451381',
    'parentid' => '451300',
    'parentids' => '450000,451300,451381',
    'level' => '3',
    'name' => '合山市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2433 => 
  array (
    'id' => '451400',
    'parentid' => '450000',
    'parentids' => '450000,451400',
    'level' => '2',
    'name' => '崇左市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2434 => 
  array (
    'id' => '451401',
    'parentid' => '451400',
    'parentids' => '450000,451400,451401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2435 => 
  array (
    'id' => '451402',
    'parentid' => '451400',
    'parentids' => '450000,451400,451402',
    'level' => '3',
    'name' => '江洲区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2436 => 
  array (
    'id' => '451421',
    'parentid' => '451400',
    'parentids' => '450000,451400,451421',
    'level' => '3',
    'name' => '扶绥县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2437 => 
  array (
    'id' => '451422',
    'parentid' => '451400',
    'parentids' => '450000,451400,451422',
    'level' => '3',
    'name' => '宁明县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2438 => 
  array (
    'id' => '451423',
    'parentid' => '451400',
    'parentids' => '450000,451400,451423',
    'level' => '3',
    'name' => '龙州县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2439 => 
  array (
    'id' => '451424',
    'parentid' => '451400',
    'parentids' => '450000,451400,451424',
    'level' => '3',
    'name' => '大新县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2440 => 
  array (
    'id' => '451425',
    'parentid' => '451400',
    'parentids' => '450000,451400,451425',
    'level' => '3',
    'name' => '天等县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2441 => 
  array (
    'id' => '451481',
    'parentid' => '451400',
    'parentids' => '450000,451400,451481',
    'level' => '3',
    'name' => '凭祥市',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2442 => 
  array (
    'id' => '460000',
    'parentid' => '0',
    'parentids' => '460000',
    'level' => '1',
    'name' => '海南省',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2443 => 
  array (
    'id' => '460100',
    'parentid' => '460000',
    'parentids' => '460000,460100',
    'level' => '2',
    'name' => '海口市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2444 => 
  array (
    'id' => '460101',
    'parentid' => '460100',
    'parentids' => '460000,460100,460101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2445 => 
  array (
    'id' => '460105',
    'parentid' => '460100',
    'parentids' => '460000,460100,460105',
    'level' => '3',
    'name' => '秀英区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2446 => 
  array (
    'id' => '460106',
    'parentid' => '460100',
    'parentids' => '460000,460100,460106',
    'level' => '3',
    'name' => '龙华区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2447 => 
  array (
    'id' => '460107',
    'parentid' => '460100',
    'parentids' => '460000,460100,460107',
    'level' => '3',
    'name' => '琼山区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2448 => 
  array (
    'id' => '460108',
    'parentid' => '460100',
    'parentids' => '460000,460100,460108',
    'level' => '3',
    'name' => '美兰区',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2449 => 
  array (
    'id' => '460200',
    'parentid' => '460000',
    'parentids' => '460000,460200',
    'level' => '2',
    'name' => '三亚市',
    'letter' => 's',
    'listorder' => '0',
  ),
  2450 => 
  array (
    'id' => '460201',
    'parentid' => '460200',
    'parentids' => '460000,460200,460201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2451 => 
  array (
    'id' => '469000',
    'parentid' => '460000',
    'parentids' => '460000,469000',
    'level' => '2',
    'name' => '省直辖县级行政单位',
    'letter' => 's',
    'listorder' => '0',
  ),
  2452 => 
  array (
    'id' => '469001',
    'parentid' => '469000',
    'parentids' => '460000,469000,469001',
    'level' => '3',
    'name' => '五指山市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2453 => 
  array (
    'id' => '469002',
    'parentid' => '469000',
    'parentids' => '460000,469000,469002',
    'level' => '3',
    'name' => '琼海市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2454 => 
  array (
    'id' => '469003',
    'parentid' => '469000',
    'parentids' => '460000,469000,469003',
    'level' => '3',
    'name' => '儋州市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2455 => 
  array (
    'id' => '469005',
    'parentid' => '469000',
    'parentids' => '460000,469000,469005',
    'level' => '3',
    'name' => '文昌市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2456 => 
  array (
    'id' => '469006',
    'parentid' => '469000',
    'parentids' => '460000,469000,469006',
    'level' => '3',
    'name' => '万宁市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2457 => 
  array (
    'id' => '469007',
    'parentid' => '469000',
    'parentids' => '460000,469000,469007',
    'level' => '3',
    'name' => '东方市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2458 => 
  array (
    'id' => '469025',
    'parentid' => '469000',
    'parentids' => '460000,469000,469025',
    'level' => '3',
    'name' => '定安县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2459 => 
  array (
    'id' => '469026',
    'parentid' => '469000',
    'parentids' => '460000,469000,469026',
    'level' => '3',
    'name' => '屯昌县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2460 => 
  array (
    'id' => '469027',
    'parentid' => '469000',
    'parentids' => '460000,469000,469027',
    'level' => '3',
    'name' => '澄迈县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2461 => 
  array (
    'id' => '469028',
    'parentid' => '469000',
    'parentids' => '460000,469000,469028',
    'level' => '3',
    'name' => '临高县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2462 => 
  array (
    'id' => '469030',
    'parentid' => '469000',
    'parentids' => '460000,469000,469030',
    'level' => '3',
    'name' => '白沙黎族自治县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2463 => 
  array (
    'id' => '469031',
    'parentid' => '469000',
    'parentids' => '460000,469000,469031',
    'level' => '3',
    'name' => '昌江黎族自治县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2464 => 
  array (
    'id' => '469033',
    'parentid' => '469000',
    'parentids' => '460000,469000,469033',
    'level' => '3',
    'name' => '乐东黎族自治县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2465 => 
  array (
    'id' => '469034',
    'parentid' => '469000',
    'parentids' => '460000,469000,469034',
    'level' => '3',
    'name' => '陵水黎族自治县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2466 => 
  array (
    'id' => '469035',
    'parentid' => '469000',
    'parentids' => '460000,469000,469035',
    'level' => '3',
    'name' => '保亭黎族苗族自治县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2467 => 
  array (
    'id' => '469036',
    'parentid' => '469000',
    'parentids' => '460000,469000,469036',
    'level' => '3',
    'name' => '琼中黎族苗族自治县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2468 => 
  array (
    'id' => '469037',
    'parentid' => '469000',
    'parentids' => '460000,469000,469037',
    'level' => '3',
    'name' => '西沙群岛',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2469 => 
  array (
    'id' => '469038',
    'parentid' => '469000',
    'parentids' => '460000,469000,469038',
    'level' => '3',
    'name' => '南沙群岛',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2470 => 
  array (
    'id' => '469039',
    'parentid' => '469000',
    'parentids' => '460000,469000,469039',
    'level' => '3',
    'name' => '中沙群岛的岛礁及其海域',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2471 => 
  array (
    'id' => '500000',
    'parentid' => '0',
    'parentids' => '500000',
    'level' => '1',
    'name' => '重庆市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2472 => 
  array (
    'id' => '500100',
    'parentid' => '500000',
    'parentids' => '500000,500100',
    'level' => '2',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2473 => 
  array (
    'id' => '500101',
    'parentid' => '500100',
    'parentids' => '500000,500100,500101',
    'level' => '3',
    'name' => '万州区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2474 => 
  array (
    'id' => '500102',
    'parentid' => '500100',
    'parentids' => '500000,500100,500102',
    'level' => '3',
    'name' => '涪陵区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2475 => 
  array (
    'id' => '500103',
    'parentid' => '500100',
    'parentids' => '500000,500100,500103',
    'level' => '3',
    'name' => '渝中区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2476 => 
  array (
    'id' => '500104',
    'parentid' => '500100',
    'parentids' => '500000,500100,500104',
    'level' => '3',
    'name' => '大渡口区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2477 => 
  array (
    'id' => '500105',
    'parentid' => '500100',
    'parentids' => '500000,500100,500105',
    'level' => '3',
    'name' => '江北区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2478 => 
  array (
    'id' => '500106',
    'parentid' => '500100',
    'parentids' => '500000,500100,500106',
    'level' => '3',
    'name' => '沙坪坝区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2479 => 
  array (
    'id' => '500107',
    'parentid' => '500100',
    'parentids' => '500000,500100,500107',
    'level' => '3',
    'name' => '九龙坡区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2480 => 
  array (
    'id' => '500108',
    'parentid' => '500100',
    'parentids' => '500000,500100,500108',
    'level' => '3',
    'name' => '南岸区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2481 => 
  array (
    'id' => '500109',
    'parentid' => '500100',
    'parentids' => '500000,500100,500109',
    'level' => '3',
    'name' => '北碚区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2482 => 
  array (
    'id' => '500110',
    'parentid' => '500100',
    'parentids' => '500000,500100,500110',
    'level' => '3',
    'name' => '万盛区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2483 => 
  array (
    'id' => '500111',
    'parentid' => '500100',
    'parentids' => '500000,500100,500111',
    'level' => '3',
    'name' => '双桥区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2484 => 
  array (
    'id' => '500112',
    'parentid' => '500100',
    'parentids' => '500000,500100,500112',
    'level' => '3',
    'name' => '渝北区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2485 => 
  array (
    'id' => '500113',
    'parentid' => '500100',
    'parentids' => '500000,500100,500113',
    'level' => '3',
    'name' => '巴南区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2486 => 
  array (
    'id' => '500114',
    'parentid' => '500100',
    'parentids' => '500000,500100,500114',
    'level' => '3',
    'name' => '黔江区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2487 => 
  array (
    'id' => '500115',
    'parentid' => '500100',
    'parentids' => '500000,500100,500115',
    'level' => '3',
    'name' => '长寿区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2488 => 
  array (
    'id' => '500200',
    'parentid' => '500000',
    'parentids' => '500000,500200',
    'level' => '2',
    'name' => '县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2489 => 
  array (
    'id' => '500222',
    'parentid' => '500200',
    'parentids' => '500000,500200,500222',
    'level' => '3',
    'name' => '綦江县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2490 => 
  array (
    'id' => '500223',
    'parentid' => '500200',
    'parentids' => '500000,500200,500223',
    'level' => '3',
    'name' => '潼南县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2491 => 
  array (
    'id' => '500224',
    'parentid' => '500200',
    'parentids' => '500000,500200,500224',
    'level' => '3',
    'name' => '铜梁县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2492 => 
  array (
    'id' => '500225',
    'parentid' => '500200',
    'parentids' => '500000,500200,500225',
    'level' => '3',
    'name' => '大足县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2493 => 
  array (
    'id' => '500226',
    'parentid' => '500200',
    'parentids' => '500000,500200,500226',
    'level' => '3',
    'name' => '荣昌县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  2494 => 
  array (
    'id' => '500227',
    'parentid' => '500200',
    'parentids' => '500000,500200,500227',
    'level' => '3',
    'name' => '璧山县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2495 => 
  array (
    'id' => '500228',
    'parentid' => '500200',
    'parentids' => '500000,500200,500228',
    'level' => '3',
    'name' => '梁平县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2496 => 
  array (
    'id' => '500229',
    'parentid' => '500200',
    'parentids' => '500000,500200,500229',
    'level' => '3',
    'name' => '城口县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2497 => 
  array (
    'id' => '500230',
    'parentid' => '500200',
    'parentids' => '500000,500200,500230',
    'level' => '3',
    'name' => '丰都县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2498 => 
  array (
    'id' => '500231',
    'parentid' => '500200',
    'parentids' => '500000,500200,500231',
    'level' => '3',
    'name' => '垫江县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2499 => 
  array (
    'id' => '500232',
    'parentid' => '500200',
    'parentids' => '500000,500200,500232',
    'level' => '3',
    'name' => '武隆县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2500 => 
  array (
    'id' => '500233',
    'parentid' => '500200',
    'parentids' => '500000,500200,500233',
    'level' => '3',
    'name' => '忠　县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2501 => 
  array (
    'id' => '500234',
    'parentid' => '500200',
    'parentids' => '500000,500200,500234',
    'level' => '3',
    'name' => '开　县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  2502 => 
  array (
    'id' => '500235',
    'parentid' => '500200',
    'parentids' => '500000,500200,500235',
    'level' => '3',
    'name' => '云阳县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2503 => 
  array (
    'id' => '500236',
    'parentid' => '500200',
    'parentids' => '500000,500200,500236',
    'level' => '3',
    'name' => '奉节县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2504 => 
  array (
    'id' => '500237',
    'parentid' => '500200',
    'parentids' => '500000,500200,500237',
    'level' => '3',
    'name' => '巫山县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2505 => 
  array (
    'id' => '500238',
    'parentid' => '500200',
    'parentids' => '500000,500200,500238',
    'level' => '3',
    'name' => '巫溪县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2506 => 
  array (
    'id' => '500240',
    'parentid' => '500200',
    'parentids' => '500000,500200,500240',
    'level' => '3',
    'name' => '石柱土家族自治县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2507 => 
  array (
    'id' => '500241',
    'parentid' => '500200',
    'parentids' => '500000,500200,500241',
    'level' => '3',
    'name' => '秀山土家族苗族自治县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2508 => 
  array (
    'id' => '500242',
    'parentid' => '500200',
    'parentids' => '500000,500200,500242',
    'level' => '3',
    'name' => '酉阳土家族苗族自治县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2509 => 
  array (
    'id' => '500243',
    'parentid' => '500200',
    'parentids' => '500000,500200,500243',
    'level' => '3',
    'name' => '彭水苗族土家族自治县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2510 => 
  array (
    'id' => '500300',
    'parentid' => '500000',
    'parentids' => '500000,500300',
    'level' => '2',
    'name' => '市',
    'letter' => 's',
    'listorder' => '0',
  ),
  2511 => 
  array (
    'id' => '500381',
    'parentid' => '500300',
    'parentids' => '500000,500300,500381',
    'level' => '3',
    'name' => '江津市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2512 => 
  array (
    'id' => '500382',
    'parentid' => '500300',
    'parentids' => '500000,500300,500382',
    'level' => '3',
    'name' => '合川市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2513 => 
  array (
    'id' => '500383',
    'parentid' => '500300',
    'parentids' => '500000,500300,500383',
    'level' => '3',
    'name' => '永川市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2514 => 
  array (
    'id' => '500384',
    'parentid' => '500300',
    'parentids' => '500000,500300,500384',
    'level' => '3',
    'name' => '南川市',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2515 => 
  array (
    'id' => '510000',
    'parentid' => '0',
    'parentids' => '510000',
    'level' => '1',
    'name' => '四川省',
    'letter' => 's',
    'listorder' => '0',
  ),
  2516 => 
  array (
    'id' => '510100',
    'parentid' => '510000',
    'parentids' => '510000,510100',
    'level' => '2',
    'name' => '成都市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2517 => 
  array (
    'id' => '510101',
    'parentid' => '510100',
    'parentids' => '510000,510100,510101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2518 => 
  array (
    'id' => '510104',
    'parentid' => '510100',
    'parentids' => '510000,510100,510104',
    'level' => '3',
    'name' => '锦江区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2519 => 
  array (
    'id' => '510105',
    'parentid' => '510100',
    'parentids' => '510000,510100,510105',
    'level' => '3',
    'name' => '青羊区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2520 => 
  array (
    'id' => '510106',
    'parentid' => '510100',
    'parentids' => '510000,510100,510106',
    'level' => '3',
    'name' => '金牛区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2521 => 
  array (
    'id' => '510107',
    'parentid' => '510100',
    'parentids' => '510000,510100,510107',
    'level' => '3',
    'name' => '武侯区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2522 => 
  array (
    'id' => '510108',
    'parentid' => '510100',
    'parentids' => '510000,510100,510108',
    'level' => '3',
    'name' => '成华区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2523 => 
  array (
    'id' => '510112',
    'parentid' => '510100',
    'parentids' => '510000,510100,510112',
    'level' => '3',
    'name' => '龙泉驿区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2524 => 
  array (
    'id' => '510113',
    'parentid' => '510100',
    'parentids' => '510000,510100,510113',
    'level' => '3',
    'name' => '青白江区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2525 => 
  array (
    'id' => '510114',
    'parentid' => '510100',
    'parentids' => '510000,510100,510114',
    'level' => '3',
    'name' => '新都区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2526 => 
  array (
    'id' => '510115',
    'parentid' => '510100',
    'parentids' => '510000,510100,510115',
    'level' => '3',
    'name' => '温江区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2527 => 
  array (
    'id' => '510121',
    'parentid' => '510100',
    'parentids' => '510000,510100,510121',
    'level' => '3',
    'name' => '金堂县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2528 => 
  array (
    'id' => '510122',
    'parentid' => '510100',
    'parentids' => '510000,510100,510122',
    'level' => '3',
    'name' => '双流县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2529 => 
  array (
    'id' => '510124',
    'parentid' => '510100',
    'parentids' => '510000,510100,510124',
    'level' => '3',
    'name' => '郫　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2530 => 
  array (
    'id' => '510129',
    'parentid' => '510100',
    'parentids' => '510000,510100,510129',
    'level' => '3',
    'name' => '大邑县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2531 => 
  array (
    'id' => '510131',
    'parentid' => '510100',
    'parentids' => '510000,510100,510131',
    'level' => '3',
    'name' => '蒲江县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2532 => 
  array (
    'id' => '510132',
    'parentid' => '510100',
    'parentids' => '510000,510100,510132',
    'level' => '3',
    'name' => '新津县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2533 => 
  array (
    'id' => '510181',
    'parentid' => '510100',
    'parentids' => '510000,510100,510181',
    'level' => '3',
    'name' => '都江堰市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2534 => 
  array (
    'id' => '510182',
    'parentid' => '510100',
    'parentids' => '510000,510100,510182',
    'level' => '3',
    'name' => '彭州市',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2535 => 
  array (
    'id' => '510183',
    'parentid' => '510100',
    'parentids' => '510000,510100,510183',
    'level' => '3',
    'name' => '邛崃市',
    'letter' => 's',
    'listorder' => '0',
  ),
  2536 => 
  array (
    'id' => '510184',
    'parentid' => '510100',
    'parentids' => '510000,510100,510184',
    'level' => '3',
    'name' => '崇州市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2537 => 
  array (
    'id' => '510300',
    'parentid' => '510000',
    'parentids' => '510000,510300',
    'level' => '2',
    'name' => '自贡市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2538 => 
  array (
    'id' => '510301',
    'parentid' => '510300',
    'parentids' => '510000,510300,510301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2539 => 
  array (
    'id' => '510302',
    'parentid' => '510300',
    'parentids' => '510000,510300,510302',
    'level' => '3',
    'name' => '自流井区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2540 => 
  array (
    'id' => '510303',
    'parentid' => '510300',
    'parentids' => '510000,510300,510303',
    'level' => '3',
    'name' => '贡井区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2541 => 
  array (
    'id' => '510304',
    'parentid' => '510300',
    'parentids' => '510000,510300,510304',
    'level' => '3',
    'name' => '大安区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2542 => 
  array (
    'id' => '510311',
    'parentid' => '510300',
    'parentids' => '510000,510300,510311',
    'level' => '3',
    'name' => '沿滩区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2543 => 
  array (
    'id' => '510321',
    'parentid' => '510300',
    'parentids' => '510000,510300,510321',
    'level' => '3',
    'name' => '荣　县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  2544 => 
  array (
    'id' => '510322',
    'parentid' => '510300',
    'parentids' => '510000,510300,510322',
    'level' => '3',
    'name' => '富顺县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2545 => 
  array (
    'id' => '510400',
    'parentid' => '510000',
    'parentids' => '510000,510400',
    'level' => '2',
    'name' => '攀枝花市',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2546 => 
  array (
    'id' => '510401',
    'parentid' => '510400',
    'parentids' => '510000,510400,510401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2547 => 
  array (
    'id' => '510402',
    'parentid' => '510400',
    'parentids' => '510000,510400,510402',
    'level' => '3',
    'name' => '东　区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2548 => 
  array (
    'id' => '510403',
    'parentid' => '510400',
    'parentids' => '510000,510400,510403',
    'level' => '3',
    'name' => '西　区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2549 => 
  array (
    'id' => '510411',
    'parentid' => '510400',
    'parentids' => '510000,510400,510411',
    'level' => '3',
    'name' => '仁和区',
    'letter' => 'r',
    'listorder' => '0',
  ),
  2550 => 
  array (
    'id' => '510421',
    'parentid' => '510400',
    'parentids' => '510000,510400,510421',
    'level' => '3',
    'name' => '米易县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2551 => 
  array (
    'id' => '510422',
    'parentid' => '510400',
    'parentids' => '510000,510400,510422',
    'level' => '3',
    'name' => '盐边县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2552 => 
  array (
    'id' => '510500',
    'parentid' => '510000',
    'parentids' => '510000,510500',
    'level' => '2',
    'name' => '泸州市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2553 => 
  array (
    'id' => '510501',
    'parentid' => '510500',
    'parentids' => '510000,510500,510501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2554 => 
  array (
    'id' => '510502',
    'parentid' => '510500',
    'parentids' => '510000,510500,510502',
    'level' => '3',
    'name' => '江阳区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2555 => 
  array (
    'id' => '510503',
    'parentid' => '510500',
    'parentids' => '510000,510500,510503',
    'level' => '3',
    'name' => '纳溪区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2556 => 
  array (
    'id' => '510504',
    'parentid' => '510500',
    'parentids' => '510000,510500,510504',
    'level' => '3',
    'name' => '龙马潭区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2557 => 
  array (
    'id' => '510521',
    'parentid' => '510500',
    'parentids' => '510000,510500,510521',
    'level' => '3',
    'name' => '泸　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2558 => 
  array (
    'id' => '510522',
    'parentid' => '510500',
    'parentids' => '510000,510500,510522',
    'level' => '3',
    'name' => '合江县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2559 => 
  array (
    'id' => '510524',
    'parentid' => '510500',
    'parentids' => '510000,510500,510524',
    'level' => '3',
    'name' => '叙永县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2560 => 
  array (
    'id' => '510525',
    'parentid' => '510500',
    'parentids' => '510000,510500,510525',
    'level' => '3',
    'name' => '古蔺县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2561 => 
  array (
    'id' => '510600',
    'parentid' => '510000',
    'parentids' => '510000,510600',
    'level' => '2',
    'name' => '德阳市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2562 => 
  array (
    'id' => '510601',
    'parentid' => '510600',
    'parentids' => '510000,510600,510601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2563 => 
  array (
    'id' => '510603',
    'parentid' => '510600',
    'parentids' => '510000,510600,510603',
    'level' => '3',
    'name' => '旌阳区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2564 => 
  array (
    'id' => '510623',
    'parentid' => '510600',
    'parentids' => '510000,510600,510623',
    'level' => '3',
    'name' => '中江县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2565 => 
  array (
    'id' => '510626',
    'parentid' => '510600',
    'parentids' => '510000,510600,510626',
    'level' => '3',
    'name' => '罗江县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2566 => 
  array (
    'id' => '510681',
    'parentid' => '510600',
    'parentids' => '510000,510600,510681',
    'level' => '3',
    'name' => '广汉市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2567 => 
  array (
    'id' => '510682',
    'parentid' => '510600',
    'parentids' => '510000,510600,510682',
    'level' => '3',
    'name' => '什邡市',
    'letter' => 's',
    'listorder' => '0',
  ),
  2568 => 
  array (
    'id' => '510683',
    'parentid' => '510600',
    'parentids' => '510000,510600,510683',
    'level' => '3',
    'name' => '绵竹市',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2569 => 
  array (
    'id' => '510700',
    'parentid' => '510000',
    'parentids' => '510000,510700',
    'level' => '2',
    'name' => '绵阳市',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2570 => 
  array (
    'id' => '510701',
    'parentid' => '510700',
    'parentids' => '510000,510700,510701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2571 => 
  array (
    'id' => '510703',
    'parentid' => '510700',
    'parentids' => '510000,510700,510703',
    'level' => '3',
    'name' => '涪城区',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2572 => 
  array (
    'id' => '510704',
    'parentid' => '510700',
    'parentids' => '510000,510700,510704',
    'level' => '3',
    'name' => '游仙区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2573 => 
  array (
    'id' => '510722',
    'parentid' => '510700',
    'parentids' => '510000,510700,510722',
    'level' => '3',
    'name' => '三台县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2574 => 
  array (
    'id' => '510723',
    'parentid' => '510700',
    'parentids' => '510000,510700,510723',
    'level' => '3',
    'name' => '盐亭县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2575 => 
  array (
    'id' => '510724',
    'parentid' => '510700',
    'parentids' => '510000,510700,510724',
    'level' => '3',
    'name' => '安　县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  2576 => 
  array (
    'id' => '510725',
    'parentid' => '510700',
    'parentids' => '510000,510700,510725',
    'level' => '3',
    'name' => '梓潼县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2577 => 
  array (
    'id' => '510726',
    'parentid' => '510700',
    'parentids' => '510000,510700,510726',
    'level' => '3',
    'name' => '北川羌族自治县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2578 => 
  array (
    'id' => '510727',
    'parentid' => '510700',
    'parentids' => '510000,510700,510727',
    'level' => '3',
    'name' => '平武县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2579 => 
  array (
    'id' => '510781',
    'parentid' => '510700',
    'parentids' => '510000,510700,510781',
    'level' => '3',
    'name' => '江油市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2580 => 
  array (
    'id' => '510800',
    'parentid' => '510000',
    'parentids' => '510000,510800',
    'level' => '2',
    'name' => '广元市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2581 => 
  array (
    'id' => '510801',
    'parentid' => '510800',
    'parentids' => '510000,510800,510801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2582 => 
  array (
    'id' => '510802',
    'parentid' => '510800',
    'parentids' => '510000,510800,510802',
    'level' => '3',
    'name' => '市中区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2583 => 
  array (
    'id' => '510811',
    'parentid' => '510800',
    'parentids' => '510000,510800,510811',
    'level' => '3',
    'name' => '元坝区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2584 => 
  array (
    'id' => '510812',
    'parentid' => '510800',
    'parentids' => '510000,510800,510812',
    'level' => '3',
    'name' => '朝天区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2585 => 
  array (
    'id' => '510821',
    'parentid' => '510800',
    'parentids' => '510000,510800,510821',
    'level' => '3',
    'name' => '旺苍县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2586 => 
  array (
    'id' => '510822',
    'parentid' => '510800',
    'parentids' => '510000,510800,510822',
    'level' => '3',
    'name' => '青川县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2587 => 
  array (
    'id' => '510823',
    'parentid' => '510800',
    'parentids' => '510000,510800,510823',
    'level' => '3',
    'name' => '剑阁县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2588 => 
  array (
    'id' => '510824',
    'parentid' => '510800',
    'parentids' => '510000,510800,510824',
    'level' => '3',
    'name' => '苍溪县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2589 => 
  array (
    'id' => '510900',
    'parentid' => '510000',
    'parentids' => '510000,510900',
    'level' => '2',
    'name' => '遂宁市',
    'letter' => 's',
    'listorder' => '0',
  ),
  2590 => 
  array (
    'id' => '510901',
    'parentid' => '510900',
    'parentids' => '510000,510900,510901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2591 => 
  array (
    'id' => '510903',
    'parentid' => '510900',
    'parentids' => '510000,510900,510903',
    'level' => '3',
    'name' => '船山区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2592 => 
  array (
    'id' => '510904',
    'parentid' => '510900',
    'parentids' => '510000,510900,510904',
    'level' => '3',
    'name' => '安居区',
    'letter' => 'a',
    'listorder' => '0',
  ),
  2593 => 
  array (
    'id' => '510921',
    'parentid' => '510900',
    'parentids' => '510000,510900,510921',
    'level' => '3',
    'name' => '蓬溪县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2594 => 
  array (
    'id' => '510922',
    'parentid' => '510900',
    'parentids' => '510000,510900,510922',
    'level' => '3',
    'name' => '射洪县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2595 => 
  array (
    'id' => '510923',
    'parentid' => '510900',
    'parentids' => '510000,510900,510923',
    'level' => '3',
    'name' => '大英县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2596 => 
  array (
    'id' => '511000',
    'parentid' => '510000',
    'parentids' => '510000,511000',
    'level' => '2',
    'name' => '内江市',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2597 => 
  array (
    'id' => '511001',
    'parentid' => '511000',
    'parentids' => '510000,511000,511001',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2598 => 
  array (
    'id' => '511002',
    'parentid' => '511000',
    'parentids' => '510000,511000,511002',
    'level' => '3',
    'name' => '市中区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2599 => 
  array (
    'id' => '511011',
    'parentid' => '511000',
    'parentids' => '510000,511000,511011',
    'level' => '3',
    'name' => '东兴区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2600 => 
  array (
    'id' => '511024',
    'parentid' => '511000',
    'parentids' => '510000,511000,511024',
    'level' => '3',
    'name' => '威远县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2601 => 
  array (
    'id' => '511025',
    'parentid' => '511000',
    'parentids' => '510000,511000,511025',
    'level' => '3',
    'name' => '资中县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2602 => 
  array (
    'id' => '511028',
    'parentid' => '511000',
    'parentids' => '510000,511000,511028',
    'level' => '3',
    'name' => '隆昌县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2603 => 
  array (
    'id' => '511100',
    'parentid' => '510000',
    'parentids' => '510000,511100',
    'level' => '2',
    'name' => '乐山市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2604 => 
  array (
    'id' => '511101',
    'parentid' => '511100',
    'parentids' => '510000,511100,511101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2605 => 
  array (
    'id' => '511102',
    'parentid' => '511100',
    'parentids' => '510000,511100,511102',
    'level' => '3',
    'name' => '市中区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2606 => 
  array (
    'id' => '511111',
    'parentid' => '511100',
    'parentids' => '510000,511100,511111',
    'level' => '3',
    'name' => '沙湾区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2607 => 
  array (
    'id' => '511112',
    'parentid' => '511100',
    'parentids' => '510000,511100,511112',
    'level' => '3',
    'name' => '五通桥区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2608 => 
  array (
    'id' => '511113',
    'parentid' => '511100',
    'parentids' => '510000,511100,511113',
    'level' => '3',
    'name' => '金口河区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2609 => 
  array (
    'id' => '511123',
    'parentid' => '511100',
    'parentids' => '510000,511100,511123',
    'level' => '3',
    'name' => '犍为县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2610 => 
  array (
    'id' => '511124',
    'parentid' => '511100',
    'parentids' => '510000,511100,511124',
    'level' => '3',
    'name' => '井研县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2611 => 
  array (
    'id' => '511126',
    'parentid' => '511100',
    'parentids' => '510000,511100,511126',
    'level' => '3',
    'name' => '夹江县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2612 => 
  array (
    'id' => '511129',
    'parentid' => '511100',
    'parentids' => '510000,511100,511129',
    'level' => '3',
    'name' => '沐川县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2613 => 
  array (
    'id' => '511132',
    'parentid' => '511100',
    'parentids' => '510000,511100,511132',
    'level' => '3',
    'name' => '峨边彝族自治县',
    'letter' => 'e',
    'listorder' => '0',
  ),
  2614 => 
  array (
    'id' => '511133',
    'parentid' => '511100',
    'parentids' => '510000,511100,511133',
    'level' => '3',
    'name' => '马边彝族自治县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2615 => 
  array (
    'id' => '511181',
    'parentid' => '511100',
    'parentids' => '510000,511100,511181',
    'level' => '3',
    'name' => '峨眉山市',
    'letter' => 'e',
    'listorder' => '0',
  ),
  2616 => 
  array (
    'id' => '511300',
    'parentid' => '510000',
    'parentids' => '510000,511300',
    'level' => '2',
    'name' => '南充市',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2617 => 
  array (
    'id' => '511301',
    'parentid' => '511300',
    'parentids' => '510000,511300,511301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2618 => 
  array (
    'id' => '511302',
    'parentid' => '511300',
    'parentids' => '510000,511300,511302',
    'level' => '3',
    'name' => '顺庆区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2619 => 
  array (
    'id' => '511303',
    'parentid' => '511300',
    'parentids' => '510000,511300,511303',
    'level' => '3',
    'name' => '高坪区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2620 => 
  array (
    'id' => '511304',
    'parentid' => '511300',
    'parentids' => '510000,511300,511304',
    'level' => '3',
    'name' => '嘉陵区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2621 => 
  array (
    'id' => '511321',
    'parentid' => '511300',
    'parentids' => '510000,511300,511321',
    'level' => '3',
    'name' => '南部县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2622 => 
  array (
    'id' => '511322',
    'parentid' => '511300',
    'parentids' => '510000,511300,511322',
    'level' => '3',
    'name' => '营山县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2623 => 
  array (
    'id' => '511323',
    'parentid' => '511300',
    'parentids' => '510000,511300,511323',
    'level' => '3',
    'name' => '蓬安县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2624 => 
  array (
    'id' => '511324',
    'parentid' => '511300',
    'parentids' => '510000,511300,511324',
    'level' => '3',
    'name' => '仪陇县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2625 => 
  array (
    'id' => '511325',
    'parentid' => '511300',
    'parentids' => '510000,511300,511325',
    'level' => '3',
    'name' => '西充县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2626 => 
  array (
    'id' => '511381',
    'parentid' => '511300',
    'parentids' => '510000,511300,511381',
    'level' => '3',
    'name' => '阆中市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2627 => 
  array (
    'id' => '511400',
    'parentid' => '510000',
    'parentids' => '510000,511400',
    'level' => '2',
    'name' => '眉山市',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2628 => 
  array (
    'id' => '511401',
    'parentid' => '511400',
    'parentids' => '510000,511400,511401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2629 => 
  array (
    'id' => '511402',
    'parentid' => '511400',
    'parentids' => '510000,511400,511402',
    'level' => '3',
    'name' => '东坡区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2630 => 
  array (
    'id' => '511421',
    'parentid' => '511400',
    'parentids' => '510000,511400,511421',
    'level' => '3',
    'name' => '仁寿县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  2631 => 
  array (
    'id' => '511422',
    'parentid' => '511400',
    'parentids' => '510000,511400,511422',
    'level' => '3',
    'name' => '彭山县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2632 => 
  array (
    'id' => '511423',
    'parentid' => '511400',
    'parentids' => '510000,511400,511423',
    'level' => '3',
    'name' => '洪雅县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2633 => 
  array (
    'id' => '511424',
    'parentid' => '511400',
    'parentids' => '510000,511400,511424',
    'level' => '3',
    'name' => '丹棱县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2634 => 
  array (
    'id' => '511425',
    'parentid' => '511400',
    'parentids' => '510000,511400,511425',
    'level' => '3',
    'name' => '青神县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2635 => 
  array (
    'id' => '511500',
    'parentid' => '510000',
    'parentids' => '510000,511500',
    'level' => '2',
    'name' => '宜宾市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2636 => 
  array (
    'id' => '511501',
    'parentid' => '511500',
    'parentids' => '510000,511500,511501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2637 => 
  array (
    'id' => '511502',
    'parentid' => '511500',
    'parentids' => '510000,511500,511502',
    'level' => '3',
    'name' => '翠屏区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2638 => 
  array (
    'id' => '511521',
    'parentid' => '511500',
    'parentids' => '510000,511500,511521',
    'level' => '3',
    'name' => '宜宾县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2639 => 
  array (
    'id' => '511522',
    'parentid' => '511500',
    'parentids' => '510000,511500,511522',
    'level' => '3',
    'name' => '南溪县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2640 => 
  array (
    'id' => '511523',
    'parentid' => '511500',
    'parentids' => '510000,511500,511523',
    'level' => '3',
    'name' => '江安县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2641 => 
  array (
    'id' => '511524',
    'parentid' => '511500',
    'parentids' => '510000,511500,511524',
    'level' => '3',
    'name' => '长宁县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2642 => 
  array (
    'id' => '511525',
    'parentid' => '511500',
    'parentids' => '510000,511500,511525',
    'level' => '3',
    'name' => '高　县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2643 => 
  array (
    'id' => '511526',
    'parentid' => '511500',
    'parentids' => '510000,511500,511526',
    'level' => '3',
    'name' => '珙　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2644 => 
  array (
    'id' => '511527',
    'parentid' => '511500',
    'parentids' => '510000,511500,511527',
    'level' => '3',
    'name' => '筠连县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2645 => 
  array (
    'id' => '511528',
    'parentid' => '511500',
    'parentids' => '510000,511500,511528',
    'level' => '3',
    'name' => '兴文县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2646 => 
  array (
    'id' => '511529',
    'parentid' => '511500',
    'parentids' => '510000,511500,511529',
    'level' => '3',
    'name' => '屏山县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2647 => 
  array (
    'id' => '511600',
    'parentid' => '510000',
    'parentids' => '510000,511600',
    'level' => '2',
    'name' => '广安市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2648 => 
  array (
    'id' => '511601',
    'parentid' => '511600',
    'parentids' => '510000,511600,511601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2649 => 
  array (
    'id' => '511602',
    'parentid' => '511600',
    'parentids' => '510000,511600,511602',
    'level' => '3',
    'name' => '广安区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2650 => 
  array (
    'id' => '511621',
    'parentid' => '511600',
    'parentids' => '510000,511600,511621',
    'level' => '3',
    'name' => '岳池县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2651 => 
  array (
    'id' => '511622',
    'parentid' => '511600',
    'parentids' => '510000,511600,511622',
    'level' => '3',
    'name' => '武胜县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2652 => 
  array (
    'id' => '511623',
    'parentid' => '511600',
    'parentids' => '510000,511600,511623',
    'level' => '3',
    'name' => '邻水县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2653 => 
  array (
    'id' => '511681',
    'parentid' => '511600',
    'parentids' => '510000,511600,511681',
    'level' => '3',
    'name' => '华莹市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2654 => 
  array (
    'id' => '511700',
    'parentid' => '510000',
    'parentids' => '510000,511700',
    'level' => '2',
    'name' => '达州市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2655 => 
  array (
    'id' => '511701',
    'parentid' => '511700',
    'parentids' => '510000,511700,511701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2656 => 
  array (
    'id' => '511702',
    'parentid' => '511700',
    'parentids' => '510000,511700,511702',
    'level' => '3',
    'name' => '通川区',
    'letter' => 't',
    'listorder' => '0',
  ),
  2657 => 
  array (
    'id' => '511721',
    'parentid' => '511700',
    'parentids' => '510000,511700,511721',
    'level' => '3',
    'name' => '达　县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2658 => 
  array (
    'id' => '511722',
    'parentid' => '511700',
    'parentids' => '510000,511700,511722',
    'level' => '3',
    'name' => '宣汉县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2659 => 
  array (
    'id' => '511723',
    'parentid' => '511700',
    'parentids' => '510000,511700,511723',
    'level' => '3',
    'name' => '开江县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  2660 => 
  array (
    'id' => '511724',
    'parentid' => '511700',
    'parentids' => '510000,511700,511724',
    'level' => '3',
    'name' => '大竹县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2661 => 
  array (
    'id' => '511725',
    'parentid' => '511700',
    'parentids' => '510000,511700,511725',
    'level' => '3',
    'name' => '渠　县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2662 => 
  array (
    'id' => '511781',
    'parentid' => '511700',
    'parentids' => '510000,511700,511781',
    'level' => '3',
    'name' => '万源市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2663 => 
  array (
    'id' => '511800',
    'parentid' => '510000',
    'parentids' => '510000,511800',
    'level' => '2',
    'name' => '雅安市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2664 => 
  array (
    'id' => '511801',
    'parentid' => '511800',
    'parentids' => '510000,511800,511801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2665 => 
  array (
    'id' => '511802',
    'parentid' => '511800',
    'parentids' => '510000,511800,511802',
    'level' => '3',
    'name' => '雨城区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2666 => 
  array (
    'id' => '511821',
    'parentid' => '511800',
    'parentids' => '510000,511800,511821',
    'level' => '3',
    'name' => '名山县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2667 => 
  array (
    'id' => '511822',
    'parentid' => '511800',
    'parentids' => '510000,511800,511822',
    'level' => '3',
    'name' => '荥经县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2668 => 
  array (
    'id' => '511823',
    'parentid' => '511800',
    'parentids' => '510000,511800,511823',
    'level' => '3',
    'name' => '汉源县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2669 => 
  array (
    'id' => '511824',
    'parentid' => '511800',
    'parentids' => '510000,511800,511824',
    'level' => '3',
    'name' => '石棉县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2670 => 
  array (
    'id' => '511825',
    'parentid' => '511800',
    'parentids' => '510000,511800,511825',
    'level' => '3',
    'name' => '天全县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2671 => 
  array (
    'id' => '511826',
    'parentid' => '511800',
    'parentids' => '510000,511800,511826',
    'level' => '3',
    'name' => '芦山县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2672 => 
  array (
    'id' => '511827',
    'parentid' => '511800',
    'parentids' => '510000,511800,511827',
    'level' => '3',
    'name' => '宝兴县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2673 => 
  array (
    'id' => '511900',
    'parentid' => '510000',
    'parentids' => '510000,511900',
    'level' => '2',
    'name' => '巴中市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2674 => 
  array (
    'id' => '511901',
    'parentid' => '511900',
    'parentids' => '510000,511900,511901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2675 => 
  array (
    'id' => '511902',
    'parentid' => '511900',
    'parentids' => '510000,511900,511902',
    'level' => '3',
    'name' => '巴州区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2676 => 
  array (
    'id' => '511921',
    'parentid' => '511900',
    'parentids' => '510000,511900,511921',
    'level' => '3',
    'name' => '通江县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2677 => 
  array (
    'id' => '511922',
    'parentid' => '511900',
    'parentids' => '510000,511900,511922',
    'level' => '3',
    'name' => '南江县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2678 => 
  array (
    'id' => '511923',
    'parentid' => '511900',
    'parentids' => '510000,511900,511923',
    'level' => '3',
    'name' => '平昌县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2679 => 
  array (
    'id' => '512000',
    'parentid' => '510000',
    'parentids' => '510000,512000',
    'level' => '2',
    'name' => '资阳市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2680 => 
  array (
    'id' => '512001',
    'parentid' => '512000',
    'parentids' => '510000,512000,512001',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2681 => 
  array (
    'id' => '512002',
    'parentid' => '512000',
    'parentids' => '510000,512000,512002',
    'level' => '3',
    'name' => '雁江区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2682 => 
  array (
    'id' => '512021',
    'parentid' => '512000',
    'parentids' => '510000,512000,512021',
    'level' => '3',
    'name' => '安岳县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  2683 => 
  array (
    'id' => '512022',
    'parentid' => '512000',
    'parentids' => '510000,512000,512022',
    'level' => '3',
    'name' => '乐至县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2684 => 
  array (
    'id' => '512081',
    'parentid' => '512000',
    'parentids' => '510000,512000,512081',
    'level' => '3',
    'name' => '简阳市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2685 => 
  array (
    'id' => '513200',
    'parentid' => '510000',
    'parentids' => '510000,513200',
    'level' => '2',
    'name' => '阿坝藏族羌族自治州',
    'letter' => 'a',
    'listorder' => '0',
  ),
  2686 => 
  array (
    'id' => '513221',
    'parentid' => '513200',
    'parentids' => '510000,513200,513221',
    'level' => '3',
    'name' => '汶川县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2687 => 
  array (
    'id' => '513222',
    'parentid' => '513200',
    'parentids' => '510000,513200,513222',
    'level' => '3',
    'name' => '理　县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2688 => 
  array (
    'id' => '513223',
    'parentid' => '513200',
    'parentids' => '510000,513200,513223',
    'level' => '3',
    'name' => '茂　县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2689 => 
  array (
    'id' => '513224',
    'parentid' => '513200',
    'parentids' => '510000,513200,513224',
    'level' => '3',
    'name' => '松潘县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2690 => 
  array (
    'id' => '513225',
    'parentid' => '513200',
    'parentids' => '510000,513200,513225',
    'level' => '3',
    'name' => '九寨沟县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2691 => 
  array (
    'id' => '513226',
    'parentid' => '513200',
    'parentids' => '510000,513200,513226',
    'level' => '3',
    'name' => '金川县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2692 => 
  array (
    'id' => '513227',
    'parentid' => '513200',
    'parentids' => '510000,513200,513227',
    'level' => '3',
    'name' => '小金县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2693 => 
  array (
    'id' => '513228',
    'parentid' => '513200',
    'parentids' => '510000,513200,513228',
    'level' => '3',
    'name' => '黑水县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2694 => 
  array (
    'id' => '513229',
    'parentid' => '513200',
    'parentids' => '510000,513200,513229',
    'level' => '3',
    'name' => '马尔康县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2695 => 
  array (
    'id' => '513230',
    'parentid' => '513200',
    'parentids' => '510000,513200,513230',
    'level' => '3',
    'name' => '壤塘县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  2696 => 
  array (
    'id' => '513231',
    'parentid' => '513200',
    'parentids' => '510000,513200,513231',
    'level' => '3',
    'name' => '阿坝县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  2697 => 
  array (
    'id' => '513232',
    'parentid' => '513200',
    'parentids' => '510000,513200,513232',
    'level' => '3',
    'name' => '若尔盖县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  2698 => 
  array (
    'id' => '513233',
    'parentid' => '513200',
    'parentids' => '510000,513200,513233',
    'level' => '3',
    'name' => '红原县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2699 => 
  array (
    'id' => '513300',
    'parentid' => '510000',
    'parentids' => '510000,513300',
    'level' => '2',
    'name' => '甘孜藏族自治州',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2700 => 
  array (
    'id' => '513321',
    'parentid' => '513300',
    'parentids' => '510000,513300,513321',
    'level' => '3',
    'name' => '康定县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  2701 => 
  array (
    'id' => '513322',
    'parentid' => '513300',
    'parentids' => '510000,513300,513322',
    'level' => '3',
    'name' => '泸定县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2702 => 
  array (
    'id' => '513323',
    'parentid' => '513300',
    'parentids' => '510000,513300,513323',
    'level' => '3',
    'name' => '丹巴县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2703 => 
  array (
    'id' => '513324',
    'parentid' => '513300',
    'parentids' => '510000,513300,513324',
    'level' => '3',
    'name' => '九龙县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2704 => 
  array (
    'id' => '513325',
    'parentid' => '513300',
    'parentids' => '510000,513300,513325',
    'level' => '3',
    'name' => '雅江县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2705 => 
  array (
    'id' => '513326',
    'parentid' => '513300',
    'parentids' => '510000,513300,513326',
    'level' => '3',
    'name' => '道孚县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2706 => 
  array (
    'id' => '513327',
    'parentid' => '513300',
    'parentids' => '510000,513300,513327',
    'level' => '3',
    'name' => '炉霍县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2707 => 
  array (
    'id' => '513328',
    'parentid' => '513300',
    'parentids' => '510000,513300,513328',
    'level' => '3',
    'name' => '甘孜县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2708 => 
  array (
    'id' => '513329',
    'parentid' => '513300',
    'parentids' => '510000,513300,513329',
    'level' => '3',
    'name' => '新龙县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2709 => 
  array (
    'id' => '513330',
    'parentid' => '513300',
    'parentids' => '510000,513300,513330',
    'level' => '3',
    'name' => '德格县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2710 => 
  array (
    'id' => '513331',
    'parentid' => '513300',
    'parentids' => '510000,513300,513331',
    'level' => '3',
    'name' => '白玉县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2711 => 
  array (
    'id' => '513332',
    'parentid' => '513300',
    'parentids' => '510000,513300,513332',
    'level' => '3',
    'name' => '石渠县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2712 => 
  array (
    'id' => '513333',
    'parentid' => '513300',
    'parentids' => '510000,513300,513333',
    'level' => '3',
    'name' => '色达县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2713 => 
  array (
    'id' => '513334',
    'parentid' => '513300',
    'parentids' => '510000,513300,513334',
    'level' => '3',
    'name' => '理塘县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2714 => 
  array (
    'id' => '513335',
    'parentid' => '513300',
    'parentids' => '510000,513300,513335',
    'level' => '3',
    'name' => '巴塘县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2715 => 
  array (
    'id' => '513336',
    'parentid' => '513300',
    'parentids' => '510000,513300,513336',
    'level' => '3',
    'name' => '乡城县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2716 => 
  array (
    'id' => '513337',
    'parentid' => '513300',
    'parentids' => '510000,513300,513337',
    'level' => '3',
    'name' => '稻城县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2717 => 
  array (
    'id' => '513338',
    'parentid' => '513300',
    'parentids' => '510000,513300,513338',
    'level' => '3',
    'name' => '得荣县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2718 => 
  array (
    'id' => '513400',
    'parentid' => '510000',
    'parentids' => '510000,513400',
    'level' => '2',
    'name' => '凉山彝族自治州',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2719 => 
  array (
    'id' => '513401',
    'parentid' => '513400',
    'parentids' => '510000,513400,513401',
    'level' => '3',
    'name' => '西昌市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2720 => 
  array (
    'id' => '513422',
    'parentid' => '513400',
    'parentids' => '510000,513400,513422',
    'level' => '3',
    'name' => '木里藏族自治县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2721 => 
  array (
    'id' => '513423',
    'parentid' => '513400',
    'parentids' => '510000,513400,513423',
    'level' => '3',
    'name' => '盐源县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2722 => 
  array (
    'id' => '513424',
    'parentid' => '513400',
    'parentids' => '510000,513400,513424',
    'level' => '3',
    'name' => '德昌县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2723 => 
  array (
    'id' => '513425',
    'parentid' => '513400',
    'parentids' => '510000,513400,513425',
    'level' => '3',
    'name' => '会理县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2724 => 
  array (
    'id' => '513426',
    'parentid' => '513400',
    'parentids' => '510000,513400,513426',
    'level' => '3',
    'name' => '会东县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2725 => 
  array (
    'id' => '513427',
    'parentid' => '513400',
    'parentids' => '510000,513400,513427',
    'level' => '3',
    'name' => '宁南县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2726 => 
  array (
    'id' => '513428',
    'parentid' => '513400',
    'parentids' => '510000,513400,513428',
    'level' => '3',
    'name' => '普格县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2727 => 
  array (
    'id' => '513429',
    'parentid' => '513400',
    'parentids' => '510000,513400,513429',
    'level' => '3',
    'name' => '布拖县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2728 => 
  array (
    'id' => '513430',
    'parentid' => '513400',
    'parentids' => '510000,513400,513430',
    'level' => '3',
    'name' => '金阳县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2729 => 
  array (
    'id' => '513431',
    'parentid' => '513400',
    'parentids' => '510000,513400,513431',
    'level' => '3',
    'name' => '昭觉县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2730 => 
  array (
    'id' => '513432',
    'parentid' => '513400',
    'parentids' => '510000,513400,513432',
    'level' => '3',
    'name' => '喜德县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2731 => 
  array (
    'id' => '513433',
    'parentid' => '513400',
    'parentids' => '510000,513400,513433',
    'level' => '3',
    'name' => '冕宁县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2732 => 
  array (
    'id' => '513434',
    'parentid' => '513400',
    'parentids' => '510000,513400,513434',
    'level' => '3',
    'name' => '越西县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2733 => 
  array (
    'id' => '513435',
    'parentid' => '513400',
    'parentids' => '510000,513400,513435',
    'level' => '3',
    'name' => '甘洛县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2734 => 
  array (
    'id' => '513436',
    'parentid' => '513400',
    'parentids' => '510000,513400,513436',
    'level' => '3',
    'name' => '美姑县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2735 => 
  array (
    'id' => '513437',
    'parentid' => '513400',
    'parentids' => '510000,513400,513437',
    'level' => '3',
    'name' => '雷波县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2736 => 
  array (
    'id' => '520000',
    'parentid' => '0',
    'parentids' => '520000',
    'level' => '1',
    'name' => '贵州省',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2737 => 
  array (
    'id' => '520100',
    'parentid' => '520000',
    'parentids' => '520000,520100',
    'level' => '2',
    'name' => '贵阳市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2738 => 
  array (
    'id' => '520101',
    'parentid' => '520100',
    'parentids' => '520000,520100,520101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2739 => 
  array (
    'id' => '520102',
    'parentid' => '520100',
    'parentids' => '520000,520100,520102',
    'level' => '3',
    'name' => '南明区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2740 => 
  array (
    'id' => '520103',
    'parentid' => '520100',
    'parentids' => '520000,520100,520103',
    'level' => '3',
    'name' => '云岩区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2741 => 
  array (
    'id' => '520111',
    'parentid' => '520100',
    'parentids' => '520000,520100,520111',
    'level' => '3',
    'name' => '花溪区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2742 => 
  array (
    'id' => '520112',
    'parentid' => '520100',
    'parentids' => '520000,520100,520112',
    'level' => '3',
    'name' => '乌当区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2743 => 
  array (
    'id' => '520113',
    'parentid' => '520100',
    'parentids' => '520000,520100,520113',
    'level' => '3',
    'name' => '白云区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2744 => 
  array (
    'id' => '520114',
    'parentid' => '520100',
    'parentids' => '520000,520100,520114',
    'level' => '3',
    'name' => '小河区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2745 => 
  array (
    'id' => '520121',
    'parentid' => '520100',
    'parentids' => '520000,520100,520121',
    'level' => '3',
    'name' => '开阳县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  2746 => 
  array (
    'id' => '520122',
    'parentid' => '520100',
    'parentids' => '520000,520100,520122',
    'level' => '3',
    'name' => '息烽县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2747 => 
  array (
    'id' => '520123',
    'parentid' => '520100',
    'parentids' => '520000,520100,520123',
    'level' => '3',
    'name' => '修文县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2748 => 
  array (
    'id' => '520181',
    'parentid' => '520100',
    'parentids' => '520000,520100,520181',
    'level' => '3',
    'name' => '清镇市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2749 => 
  array (
    'id' => '520200',
    'parentid' => '520000',
    'parentids' => '520000,520200',
    'level' => '2',
    'name' => '六盘水市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2750 => 
  array (
    'id' => '520201',
    'parentid' => '520200',
    'parentids' => '520000,520200,520201',
    'level' => '3',
    'name' => '钟山区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2751 => 
  array (
    'id' => '520203',
    'parentid' => '520200',
    'parentids' => '520000,520200,520203',
    'level' => '3',
    'name' => '六枝特区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2752 => 
  array (
    'id' => '520221',
    'parentid' => '520200',
    'parentids' => '520000,520200,520221',
    'level' => '3',
    'name' => '水城县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2753 => 
  array (
    'id' => '520222',
    'parentid' => '520200',
    'parentids' => '520000,520200,520222',
    'level' => '3',
    'name' => '盘　县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2754 => 
  array (
    'id' => '520300',
    'parentid' => '520000',
    'parentids' => '520000,520300',
    'level' => '2',
    'name' => '遵义市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2755 => 
  array (
    'id' => '520301',
    'parentid' => '520300',
    'parentids' => '520000,520300,520301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2756 => 
  array (
    'id' => '520302',
    'parentid' => '520300',
    'parentids' => '520000,520300,520302',
    'level' => '3',
    'name' => '红花岗区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2757 => 
  array (
    'id' => '520303',
    'parentid' => '520300',
    'parentids' => '520000,520300,520303',
    'level' => '3',
    'name' => '汇川区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2758 => 
  array (
    'id' => '520321',
    'parentid' => '520300',
    'parentids' => '520000,520300,520321',
    'level' => '3',
    'name' => '遵义县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2759 => 
  array (
    'id' => '520322',
    'parentid' => '520300',
    'parentids' => '520000,520300,520322',
    'level' => '3',
    'name' => '桐梓县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2760 => 
  array (
    'id' => '520323',
    'parentid' => '520300',
    'parentids' => '520000,520300,520323',
    'level' => '3',
    'name' => '绥阳县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2761 => 
  array (
    'id' => '520324',
    'parentid' => '520300',
    'parentids' => '520000,520300,520324',
    'level' => '3',
    'name' => '正安县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2762 => 
  array (
    'id' => '520325',
    'parentid' => '520300',
    'parentids' => '520000,520300,520325',
    'level' => '3',
    'name' => '道真仡佬族苗族自治县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2763 => 
  array (
    'id' => '520326',
    'parentid' => '520300',
    'parentids' => '520000,520300,520326',
    'level' => '3',
    'name' => '务川仡佬族苗族自治县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2764 => 
  array (
    'id' => '520327',
    'parentid' => '520300',
    'parentids' => '520000,520300,520327',
    'level' => '3',
    'name' => '凤冈县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2765 => 
  array (
    'id' => '520328',
    'parentid' => '520300',
    'parentids' => '520000,520300,520328',
    'level' => '3',
    'name' => '湄潭县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2766 => 
  array (
    'id' => '520329',
    'parentid' => '520300',
    'parentids' => '520000,520300,520329',
    'level' => '3',
    'name' => '余庆县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2767 => 
  array (
    'id' => '520330',
    'parentid' => '520300',
    'parentids' => '520000,520300,520330',
    'level' => '3',
    'name' => '习水县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2768 => 
  array (
    'id' => '520381',
    'parentid' => '520300',
    'parentids' => '520000,520300,520381',
    'level' => '3',
    'name' => '赤水市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2769 => 
  array (
    'id' => '520382',
    'parentid' => '520300',
    'parentids' => '520000,520300,520382',
    'level' => '3',
    'name' => '仁怀市',
    'letter' => 'r',
    'listorder' => '0',
  ),
  2770 => 
  array (
    'id' => '520400',
    'parentid' => '520000',
    'parentids' => '520000,520400',
    'level' => '2',
    'name' => '安顺市',
    'letter' => 'a',
    'listorder' => '0',
  ),
  2771 => 
  array (
    'id' => '520401',
    'parentid' => '520400',
    'parentids' => '520000,520400,520401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2772 => 
  array (
    'id' => '520402',
    'parentid' => '520400',
    'parentids' => '520000,520400,520402',
    'level' => '3',
    'name' => '西秀区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2773 => 
  array (
    'id' => '520421',
    'parentid' => '520400',
    'parentids' => '520000,520400,520421',
    'level' => '3',
    'name' => '平坝县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2774 => 
  array (
    'id' => '520422',
    'parentid' => '520400',
    'parentids' => '520000,520400,520422',
    'level' => '3',
    'name' => '普定县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2775 => 
  array (
    'id' => '520423',
    'parentid' => '520400',
    'parentids' => '520000,520400,520423',
    'level' => '3',
    'name' => '镇宁布依族苗族自治县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2776 => 
  array (
    'id' => '520424',
    'parentid' => '520400',
    'parentids' => '520000,520400,520424',
    'level' => '3',
    'name' => '关岭布依族苗族自治县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2777 => 
  array (
    'id' => '520425',
    'parentid' => '520400',
    'parentids' => '520000,520400,520425',
    'level' => '3',
    'name' => '紫云苗族布依族自治县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2778 => 
  array (
    'id' => '522200',
    'parentid' => '520000',
    'parentids' => '520000,522200',
    'level' => '2',
    'name' => '铜仁地区',
    'letter' => 't',
    'listorder' => '0',
  ),
  2779 => 
  array (
    'id' => '522201',
    'parentid' => '522200',
    'parentids' => '520000,522200,522201',
    'level' => '3',
    'name' => '铜仁市',
    'letter' => 't',
    'listorder' => '0',
  ),
  2780 => 
  array (
    'id' => '522222',
    'parentid' => '522200',
    'parentids' => '520000,522200,522222',
    'level' => '3',
    'name' => '江口县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2781 => 
  array (
    'id' => '522223',
    'parentid' => '522200',
    'parentids' => '520000,522200,522223',
    'level' => '3',
    'name' => '玉屏侗族自治县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2782 => 
  array (
    'id' => '522224',
    'parentid' => '522200',
    'parentids' => '520000,522200,522224',
    'level' => '3',
    'name' => '石阡县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2783 => 
  array (
    'id' => '522225',
    'parentid' => '522200',
    'parentids' => '520000,522200,522225',
    'level' => '3',
    'name' => '思南县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2784 => 
  array (
    'id' => '522226',
    'parentid' => '522200',
    'parentids' => '520000,522200,522226',
    'level' => '3',
    'name' => '印江土家族苗族自治县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2785 => 
  array (
    'id' => '522227',
    'parentid' => '522200',
    'parentids' => '520000,522200,522227',
    'level' => '3',
    'name' => '德江县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2786 => 
  array (
    'id' => '522228',
    'parentid' => '522200',
    'parentids' => '520000,522200,522228',
    'level' => '3',
    'name' => '沿河土家族自治县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2787 => 
  array (
    'id' => '522229',
    'parentid' => '522200',
    'parentids' => '520000,522200,522229',
    'level' => '3',
    'name' => '松桃苗族自治县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2788 => 
  array (
    'id' => '522230',
    'parentid' => '522200',
    'parentids' => '520000,522200,522230',
    'level' => '3',
    'name' => '万山特区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2789 => 
  array (
    'id' => '522300',
    'parentid' => '520000',
    'parentids' => '520000,522300',
    'level' => '2',
    'name' => '黔西南布依族苗族自治州',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2790 => 
  array (
    'id' => '522301',
    'parentid' => '522300',
    'parentids' => '520000,522300,522301',
    'level' => '3',
    'name' => '兴义市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2791 => 
  array (
    'id' => '522322',
    'parentid' => '522300',
    'parentids' => '520000,522300,522322',
    'level' => '3',
    'name' => '兴仁县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2792 => 
  array (
    'id' => '522323',
    'parentid' => '522300',
    'parentids' => '520000,522300,522323',
    'level' => '3',
    'name' => '普安县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2793 => 
  array (
    'id' => '522324',
    'parentid' => '522300',
    'parentids' => '520000,522300,522324',
    'level' => '3',
    'name' => '晴隆县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2794 => 
  array (
    'id' => '522325',
    'parentid' => '522300',
    'parentids' => '520000,522300,522325',
    'level' => '3',
    'name' => '贞丰县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2795 => 
  array (
    'id' => '522326',
    'parentid' => '522300',
    'parentids' => '520000,522300,522326',
    'level' => '3',
    'name' => '望谟县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2796 => 
  array (
    'id' => '522327',
    'parentid' => '522300',
    'parentids' => '520000,522300,522327',
    'level' => '3',
    'name' => '册亨县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2797 => 
  array (
    'id' => '522328',
    'parentid' => '522300',
    'parentids' => '520000,522300,522328',
    'level' => '3',
    'name' => '安龙县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  2798 => 
  array (
    'id' => '522400',
    'parentid' => '520000',
    'parentids' => '520000,522400',
    'level' => '2',
    'name' => '毕节地区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2799 => 
  array (
    'id' => '522401',
    'parentid' => '522400',
    'parentids' => '520000,522400,522401',
    'level' => '3',
    'name' => '毕节市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2800 => 
  array (
    'id' => '522422',
    'parentid' => '522400',
    'parentids' => '520000,522400,522422',
    'level' => '3',
    'name' => '大方县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2801 => 
  array (
    'id' => '522423',
    'parentid' => '522400',
    'parentids' => '520000,522400,522423',
    'level' => '3',
    'name' => '黔西县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2802 => 
  array (
    'id' => '522424',
    'parentid' => '522400',
    'parentids' => '520000,522400,522424',
    'level' => '3',
    'name' => '金沙县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2803 => 
  array (
    'id' => '522425',
    'parentid' => '522400',
    'parentids' => '520000,522400,522425',
    'level' => '3',
    'name' => '织金县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2804 => 
  array (
    'id' => '522426',
    'parentid' => '522400',
    'parentids' => '520000,522400,522426',
    'level' => '3',
    'name' => '纳雍县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2805 => 
  array (
    'id' => '522427',
    'parentid' => '522400',
    'parentids' => '520000,522400,522427',
    'level' => '3',
    'name' => '威宁彝族回族苗族自治县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2806 => 
  array (
    'id' => '522428',
    'parentid' => '522400',
    'parentids' => '520000,522400,522428',
    'level' => '3',
    'name' => '赫章县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2807 => 
  array (
    'id' => '522600',
    'parentid' => '520000',
    'parentids' => '520000,522600',
    'level' => '2',
    'name' => '黔东南苗族侗族自治州',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2808 => 
  array (
    'id' => '522601',
    'parentid' => '522600',
    'parentids' => '520000,522600,522601',
    'level' => '3',
    'name' => '凯里市',
    'letter' => 'k',
    'listorder' => '0',
  ),
  2809 => 
  array (
    'id' => '522622',
    'parentid' => '522600',
    'parentids' => '520000,522600,522622',
    'level' => '3',
    'name' => '黄平县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2810 => 
  array (
    'id' => '522623',
    'parentid' => '522600',
    'parentids' => '520000,522600,522623',
    'level' => '3',
    'name' => '施秉县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2811 => 
  array (
    'id' => '522624',
    'parentid' => '522600',
    'parentids' => '520000,522600,522624',
    'level' => '3',
    'name' => '三穗县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2812 => 
  array (
    'id' => '522625',
    'parentid' => '522600',
    'parentids' => '520000,522600,522625',
    'level' => '3',
    'name' => '镇远县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2813 => 
  array (
    'id' => '522626',
    'parentid' => '522600',
    'parentids' => '520000,522600,522626',
    'level' => '3',
    'name' => '岑巩县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2814 => 
  array (
    'id' => '522627',
    'parentid' => '522600',
    'parentids' => '520000,522600,522627',
    'level' => '3',
    'name' => '天柱县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2815 => 
  array (
    'id' => '522628',
    'parentid' => '522600',
    'parentids' => '520000,522600,522628',
    'level' => '3',
    'name' => '锦屏县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2816 => 
  array (
    'id' => '522629',
    'parentid' => '522600',
    'parentids' => '520000,522600,522629',
    'level' => '3',
    'name' => '剑河县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2817 => 
  array (
    'id' => '522630',
    'parentid' => '522600',
    'parentids' => '520000,522600,522630',
    'level' => '3',
    'name' => '台江县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2818 => 
  array (
    'id' => '522631',
    'parentid' => '522600',
    'parentids' => '520000,522600,522631',
    'level' => '3',
    'name' => '黎平县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2819 => 
  array (
    'id' => '522632',
    'parentid' => '522600',
    'parentids' => '520000,522600,522632',
    'level' => '3',
    'name' => '榕江县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2820 => 
  array (
    'id' => '522633',
    'parentid' => '522600',
    'parentids' => '520000,522600,522633',
    'level' => '3',
    'name' => '从江县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2821 => 
  array (
    'id' => '522634',
    'parentid' => '522600',
    'parentids' => '520000,522600,522634',
    'level' => '3',
    'name' => '雷山县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2822 => 
  array (
    'id' => '522635',
    'parentid' => '522600',
    'parentids' => '520000,522600,522635',
    'level' => '3',
    'name' => '麻江县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2823 => 
  array (
    'id' => '522636',
    'parentid' => '522600',
    'parentids' => '520000,522600,522636',
    'level' => '3',
    'name' => '丹寨县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2824 => 
  array (
    'id' => '522700',
    'parentid' => '520000',
    'parentids' => '520000,522700',
    'level' => '2',
    'name' => '黔南布依族苗族自治州',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2825 => 
  array (
    'id' => '522701',
    'parentid' => '522700',
    'parentids' => '520000,522700,522701',
    'level' => '3',
    'name' => '都匀市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2826 => 
  array (
    'id' => '522702',
    'parentid' => '522700',
    'parentids' => '520000,522700,522702',
    'level' => '3',
    'name' => '福泉市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2827 => 
  array (
    'id' => '522722',
    'parentid' => '522700',
    'parentids' => '520000,522700,522722',
    'level' => '3',
    'name' => '荔波县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2828 => 
  array (
    'id' => '522723',
    'parentid' => '522700',
    'parentids' => '520000,522700,522723',
    'level' => '3',
    'name' => '贵定县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2829 => 
  array (
    'id' => '522725',
    'parentid' => '522700',
    'parentids' => '520000,522700,522725',
    'level' => '3',
    'name' => '瓮安县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2830 => 
  array (
    'id' => '522726',
    'parentid' => '522700',
    'parentids' => '520000,522700,522726',
    'level' => '3',
    'name' => '独山县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2831 => 
  array (
    'id' => '522727',
    'parentid' => '522700',
    'parentids' => '520000,522700,522727',
    'level' => '3',
    'name' => '平塘县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2832 => 
  array (
    'id' => '522728',
    'parentid' => '522700',
    'parentids' => '520000,522700,522728',
    'level' => '3',
    'name' => '罗甸县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2833 => 
  array (
    'id' => '522729',
    'parentid' => '522700',
    'parentids' => '520000,522700,522729',
    'level' => '3',
    'name' => '长顺县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2834 => 
  array (
    'id' => '522730',
    'parentid' => '522700',
    'parentids' => '520000,522700,522730',
    'level' => '3',
    'name' => '龙里县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2835 => 
  array (
    'id' => '522731',
    'parentid' => '522700',
    'parentids' => '520000,522700,522731',
    'level' => '3',
    'name' => '惠水县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2836 => 
  array (
    'id' => '522732',
    'parentid' => '522700',
    'parentids' => '520000,522700,522732',
    'level' => '3',
    'name' => '三都水族自治县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2837 => 
  array (
    'id' => '530000',
    'parentid' => '0',
    'parentids' => '530000',
    'level' => '1',
    'name' => '云南省',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2838 => 
  array (
    'id' => '530100',
    'parentid' => '530000',
    'parentids' => '530000,530100',
    'level' => '2',
    'name' => '昆明市',
    'letter' => 'k',
    'listorder' => '0',
  ),
  2839 => 
  array (
    'id' => '530101',
    'parentid' => '530100',
    'parentids' => '530000,530100,530101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2840 => 
  array (
    'id' => '530102',
    'parentid' => '530100',
    'parentids' => '530000,530100,530102',
    'level' => '3',
    'name' => '五华区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2841 => 
  array (
    'id' => '530103',
    'parentid' => '530100',
    'parentids' => '530000,530100,530103',
    'level' => '3',
    'name' => '盘龙区',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2842 => 
  array (
    'id' => '530111',
    'parentid' => '530100',
    'parentids' => '530000,530100,530111',
    'level' => '3',
    'name' => '官渡区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2843 => 
  array (
    'id' => '530112',
    'parentid' => '530100',
    'parentids' => '530000,530100,530112',
    'level' => '3',
    'name' => '西山区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2844 => 
  array (
    'id' => '530113',
    'parentid' => '530100',
    'parentids' => '530000,530100,530113',
    'level' => '3',
    'name' => '东川区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2845 => 
  array (
    'id' => '530121',
    'parentid' => '530100',
    'parentids' => '530000,530100,530121',
    'level' => '3',
    'name' => '呈贡县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2846 => 
  array (
    'id' => '530122',
    'parentid' => '530100',
    'parentids' => '530000,530100,530122',
    'level' => '3',
    'name' => '晋宁县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2847 => 
  array (
    'id' => '530124',
    'parentid' => '530100',
    'parentids' => '530000,530100,530124',
    'level' => '3',
    'name' => '富民县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2848 => 
  array (
    'id' => '530125',
    'parentid' => '530100',
    'parentids' => '530000,530100,530125',
    'level' => '3',
    'name' => '宜良县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2849 => 
  array (
    'id' => '530126',
    'parentid' => '530100',
    'parentids' => '530000,530100,530126',
    'level' => '3',
    'name' => '石林彝族自治县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2850 => 
  array (
    'id' => '530127',
    'parentid' => '530100',
    'parentids' => '530000,530100,530127',
    'level' => '3',
    'name' => '嵩明县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2851 => 
  array (
    'id' => '530128',
    'parentid' => '530100',
    'parentids' => '530000,530100,530128',
    'level' => '3',
    'name' => '禄劝彝族苗族自治县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2852 => 
  array (
    'id' => '530129',
    'parentid' => '530100',
    'parentids' => '530000,530100,530129',
    'level' => '3',
    'name' => '寻甸回族彝族自治县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2853 => 
  array (
    'id' => '530181',
    'parentid' => '530100',
    'parentids' => '530000,530100,530181',
    'level' => '3',
    'name' => '安宁市',
    'letter' => 'a',
    'listorder' => '0',
  ),
  2854 => 
  array (
    'id' => '530300',
    'parentid' => '530000',
    'parentids' => '530000,530300',
    'level' => '2',
    'name' => '曲靖市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2855 => 
  array (
    'id' => '530301',
    'parentid' => '530300',
    'parentids' => '530000,530300,530301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2856 => 
  array (
    'id' => '530302',
    'parentid' => '530300',
    'parentids' => '530000,530300,530302',
    'level' => '3',
    'name' => '麒麟区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2857 => 
  array (
    'id' => '530321',
    'parentid' => '530300',
    'parentids' => '530000,530300,530321',
    'level' => '3',
    'name' => '马龙县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2858 => 
  array (
    'id' => '530322',
    'parentid' => '530300',
    'parentids' => '530000,530300,530322',
    'level' => '3',
    'name' => '陆良县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2859 => 
  array (
    'id' => '530323',
    'parentid' => '530300',
    'parentids' => '530000,530300,530323',
    'level' => '3',
    'name' => '师宗县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2860 => 
  array (
    'id' => '530324',
    'parentid' => '530300',
    'parentids' => '530000,530300,530324',
    'level' => '3',
    'name' => '罗平县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2861 => 
  array (
    'id' => '530325',
    'parentid' => '530300',
    'parentids' => '530000,530300,530325',
    'level' => '3',
    'name' => '富源县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2862 => 
  array (
    'id' => '530326',
    'parentid' => '530300',
    'parentids' => '530000,530300,530326',
    'level' => '3',
    'name' => '会泽县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2863 => 
  array (
    'id' => '530328',
    'parentid' => '530300',
    'parentids' => '530000,530300,530328',
    'level' => '3',
    'name' => '沾益县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2864 => 
  array (
    'id' => '530381',
    'parentid' => '530300',
    'parentids' => '530000,530300,530381',
    'level' => '3',
    'name' => '宣威市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2865 => 
  array (
    'id' => '530400',
    'parentid' => '530000',
    'parentids' => '530000,530400',
    'level' => '2',
    'name' => '玉溪市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2866 => 
  array (
    'id' => '530401',
    'parentid' => '530400',
    'parentids' => '530000,530400,530401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2867 => 
  array (
    'id' => '530402',
    'parentid' => '530400',
    'parentids' => '530000,530400,530402',
    'level' => '3',
    'name' => '红塔区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2868 => 
  array (
    'id' => '530421',
    'parentid' => '530400',
    'parentids' => '530000,530400,530421',
    'level' => '3',
    'name' => '江川县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2869 => 
  array (
    'id' => '530422',
    'parentid' => '530400',
    'parentids' => '530000,530400,530422',
    'level' => '3',
    'name' => '澄江县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2870 => 
  array (
    'id' => '530423',
    'parentid' => '530400',
    'parentids' => '530000,530400,530423',
    'level' => '3',
    'name' => '通海县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2871 => 
  array (
    'id' => '530424',
    'parentid' => '530400',
    'parentids' => '530000,530400,530424',
    'level' => '3',
    'name' => '华宁县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2872 => 
  array (
    'id' => '530425',
    'parentid' => '530400',
    'parentids' => '530000,530400,530425',
    'level' => '3',
    'name' => '易门县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2873 => 
  array (
    'id' => '530426',
    'parentid' => '530400',
    'parentids' => '530000,530400,530426',
    'level' => '3',
    'name' => '峨山彝族自治县',
    'letter' => 'e',
    'listorder' => '0',
  ),
  2874 => 
  array (
    'id' => '530427',
    'parentid' => '530400',
    'parentids' => '530000,530400,530427',
    'level' => '3',
    'name' => '新平彝族傣族自治县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2875 => 
  array (
    'id' => '530428',
    'parentid' => '530400',
    'parentids' => '530000,530400,530428',
    'level' => '3',
    'name' => '元江哈尼族彝族傣族自治县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2876 => 
  array (
    'id' => '530500',
    'parentid' => '530000',
    'parentids' => '530000,530500',
    'level' => '2',
    'name' => '保山市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2877 => 
  array (
    'id' => '530501',
    'parentid' => '530500',
    'parentids' => '530000,530500,530501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2878 => 
  array (
    'id' => '530502',
    'parentid' => '530500',
    'parentids' => '530000,530500,530502',
    'level' => '3',
    'name' => '隆阳区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2879 => 
  array (
    'id' => '530521',
    'parentid' => '530500',
    'parentids' => '530000,530500,530521',
    'level' => '3',
    'name' => '施甸县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2880 => 
  array (
    'id' => '530522',
    'parentid' => '530500',
    'parentids' => '530000,530500,530522',
    'level' => '3',
    'name' => '腾冲县',
    'letter' => 't',
    'listorder' => '0',
  ),
  2881 => 
  array (
    'id' => '530523',
    'parentid' => '530500',
    'parentids' => '530000,530500,530523',
    'level' => '3',
    'name' => '龙陵县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2882 => 
  array (
    'id' => '530524',
    'parentid' => '530500',
    'parentids' => '530000,530500,530524',
    'level' => '3',
    'name' => '昌宁县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2883 => 
  array (
    'id' => '530600',
    'parentid' => '530000',
    'parentids' => '530000,530600',
    'level' => '2',
    'name' => '昭通市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2884 => 
  array (
    'id' => '530601',
    'parentid' => '530600',
    'parentids' => '530000,530600,530601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2885 => 
  array (
    'id' => '530602',
    'parentid' => '530600',
    'parentids' => '530000,530600,530602',
    'level' => '3',
    'name' => '昭阳区',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2886 => 
  array (
    'id' => '530621',
    'parentid' => '530600',
    'parentids' => '530000,530600,530621',
    'level' => '3',
    'name' => '鲁甸县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2887 => 
  array (
    'id' => '530622',
    'parentid' => '530600',
    'parentids' => '530000,530600,530622',
    'level' => '3',
    'name' => '巧家县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2888 => 
  array (
    'id' => '530623',
    'parentid' => '530600',
    'parentids' => '530000,530600,530623',
    'level' => '3',
    'name' => '盐津县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2889 => 
  array (
    'id' => '530624',
    'parentid' => '530600',
    'parentids' => '530000,530600,530624',
    'level' => '3',
    'name' => '大关县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2890 => 
  array (
    'id' => '530625',
    'parentid' => '530600',
    'parentids' => '530000,530600,530625',
    'level' => '3',
    'name' => '永善县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2891 => 
  array (
    'id' => '530626',
    'parentid' => '530600',
    'parentids' => '530000,530600,530626',
    'level' => '3',
    'name' => '绥江县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2892 => 
  array (
    'id' => '530627',
    'parentid' => '530600',
    'parentids' => '530000,530600,530627',
    'level' => '3',
    'name' => '镇雄县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2893 => 
  array (
    'id' => '530628',
    'parentid' => '530600',
    'parentids' => '530000,530600,530628',
    'level' => '3',
    'name' => '彝良县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2894 => 
  array (
    'id' => '530629',
    'parentid' => '530600',
    'parentids' => '530000,530600,530629',
    'level' => '3',
    'name' => '威信县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2895 => 
  array (
    'id' => '530630',
    'parentid' => '530600',
    'parentids' => '530000,530600,530630',
    'level' => '3',
    'name' => '水富县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2896 => 
  array (
    'id' => '530700',
    'parentid' => '530000',
    'parentids' => '530000,530700',
    'level' => '2',
    'name' => '丽江市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2897 => 
  array (
    'id' => '530701',
    'parentid' => '530700',
    'parentids' => '530000,530700,530701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2898 => 
  array (
    'id' => '530702',
    'parentid' => '530700',
    'parentids' => '530000,530700,530702',
    'level' => '3',
    'name' => '古城区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2899 => 
  array (
    'id' => '530721',
    'parentid' => '530700',
    'parentids' => '530000,530700,530721',
    'level' => '3',
    'name' => '玉龙纳西族自治县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2900 => 
  array (
    'id' => '530722',
    'parentid' => '530700',
    'parentids' => '530000,530700,530722',
    'level' => '3',
    'name' => '永胜县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2901 => 
  array (
    'id' => '530723',
    'parentid' => '530700',
    'parentids' => '530000,530700,530723',
    'level' => '3',
    'name' => '华坪县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2902 => 
  array (
    'id' => '530724',
    'parentid' => '530700',
    'parentids' => '530000,530700,530724',
    'level' => '3',
    'name' => '宁蒗彝族自治县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2903 => 
  array (
    'id' => '530800',
    'parentid' => '530000',
    'parentids' => '530000,530800',
    'level' => '2',
    'name' => '思茅市',
    'letter' => 's',
    'listorder' => '0',
  ),
  2904 => 
  array (
    'id' => '530801',
    'parentid' => '530800',
    'parentids' => '530000,530800,530801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2905 => 
  array (
    'id' => '530802',
    'parentid' => '530800',
    'parentids' => '530000,530800,530802',
    'level' => '3',
    'name' => '翠云区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2906 => 
  array (
    'id' => '530821',
    'parentid' => '530800',
    'parentids' => '530000,530800,530821',
    'level' => '3',
    'name' => '普洱哈尼族彝族自治县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2907 => 
  array (
    'id' => '530822',
    'parentid' => '530800',
    'parentids' => '530000,530800,530822',
    'level' => '3',
    'name' => '墨江哈尼族自治县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2908 => 
  array (
    'id' => '530823',
    'parentid' => '530800',
    'parentids' => '530000,530800,530823',
    'level' => '3',
    'name' => '景东彝族自治县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2909 => 
  array (
    'id' => '530824',
    'parentid' => '530800',
    'parentids' => '530000,530800,530824',
    'level' => '3',
    'name' => '景谷傣族彝族自治县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2910 => 
  array (
    'id' => '530825',
    'parentid' => '530800',
    'parentids' => '530000,530800,530825',
    'level' => '3',
    'name' => '镇沅彝族哈尼族拉祜族自治县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2911 => 
  array (
    'id' => '530826',
    'parentid' => '530800',
    'parentids' => '530000,530800,530826',
    'level' => '3',
    'name' => '江城哈尼族彝族自治县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2912 => 
  array (
    'id' => '530827',
    'parentid' => '530800',
    'parentids' => '530000,530800,530827',
    'level' => '3',
    'name' => '孟连傣族拉祜族佤族自治县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2913 => 
  array (
    'id' => '530828',
    'parentid' => '530800',
    'parentids' => '530000,530800,530828',
    'level' => '3',
    'name' => '澜沧拉祜族自治县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2914 => 
  array (
    'id' => '530829',
    'parentid' => '530800',
    'parentids' => '530000,530800,530829',
    'level' => '3',
    'name' => '西盟佤族自治县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2915 => 
  array (
    'id' => '530900',
    'parentid' => '530000',
    'parentids' => '530000,530900',
    'level' => '2',
    'name' => '临沧市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2916 => 
  array (
    'id' => '530901',
    'parentid' => '530900',
    'parentids' => '530000,530900,530901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2917 => 
  array (
    'id' => '530902',
    'parentid' => '530900',
    'parentids' => '530000,530900,530902',
    'level' => '3',
    'name' => '临翔区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2918 => 
  array (
    'id' => '530921',
    'parentid' => '530900',
    'parentids' => '530000,530900,530921',
    'level' => '3',
    'name' => '凤庆县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2919 => 
  array (
    'id' => '530922',
    'parentid' => '530900',
    'parentids' => '530000,530900,530922',
    'level' => '3',
    'name' => '云　县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2920 => 
  array (
    'id' => '530923',
    'parentid' => '530900',
    'parentids' => '530000,530900,530923',
    'level' => '3',
    'name' => '永德县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2921 => 
  array (
    'id' => '530924',
    'parentid' => '530900',
    'parentids' => '530000,530900,530924',
    'level' => '3',
    'name' => '镇康县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  2922 => 
  array (
    'id' => '530925',
    'parentid' => '530900',
    'parentids' => '530000,530900,530925',
    'level' => '3',
    'name' => '双江拉祜族佤族布朗族傣族自治县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2923 => 
  array (
    'id' => '530926',
    'parentid' => '530900',
    'parentids' => '530000,530900,530926',
    'level' => '3',
    'name' => '耿马傣族佤族自治县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2924 => 
  array (
    'id' => '530927',
    'parentid' => '530900',
    'parentids' => '530000,530900,530927',
    'level' => '3',
    'name' => '沧源佤族自治县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2925 => 
  array (
    'id' => '532300',
    'parentid' => '530000',
    'parentids' => '530000,532300',
    'level' => '2',
    'name' => '楚雄彝族自治州',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2926 => 
  array (
    'id' => '532301',
    'parentid' => '532300',
    'parentids' => '530000,532300,532301',
    'level' => '3',
    'name' => '楚雄市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2927 => 
  array (
    'id' => '532322',
    'parentid' => '532300',
    'parentids' => '530000,532300,532322',
    'level' => '3',
    'name' => '双柏县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2928 => 
  array (
    'id' => '532323',
    'parentid' => '532300',
    'parentids' => '530000,532300,532323',
    'level' => '3',
    'name' => '牟定县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2929 => 
  array (
    'id' => '532324',
    'parentid' => '532300',
    'parentids' => '530000,532300,532324',
    'level' => '3',
    'name' => '南华县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2930 => 
  array (
    'id' => '532325',
    'parentid' => '532300',
    'parentids' => '530000,532300,532325',
    'level' => '3',
    'name' => '姚安县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2931 => 
  array (
    'id' => '532326',
    'parentid' => '532300',
    'parentids' => '530000,532300,532326',
    'level' => '3',
    'name' => '大姚县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2932 => 
  array (
    'id' => '532327',
    'parentid' => '532300',
    'parentids' => '530000,532300,532327',
    'level' => '3',
    'name' => '永仁县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2933 => 
  array (
    'id' => '532328',
    'parentid' => '532300',
    'parentids' => '530000,532300,532328',
    'level' => '3',
    'name' => '元谋县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2934 => 
  array (
    'id' => '532329',
    'parentid' => '532300',
    'parentids' => '530000,532300,532329',
    'level' => '3',
    'name' => '武定县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2935 => 
  array (
    'id' => '532331',
    'parentid' => '532300',
    'parentids' => '530000,532300,532331',
    'level' => '3',
    'name' => '禄丰县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2936 => 
  array (
    'id' => '532500',
    'parentid' => '530000',
    'parentids' => '530000,532500',
    'level' => '2',
    'name' => '红河哈尼族彝族自治州',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2937 => 
  array (
    'id' => '532501',
    'parentid' => '532500',
    'parentids' => '530000,532500,532501',
    'level' => '3',
    'name' => '个旧市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2938 => 
  array (
    'id' => '532502',
    'parentid' => '532500',
    'parentids' => '530000,532500,532502',
    'level' => '3',
    'name' => '开远市',
    'letter' => 'k',
    'listorder' => '0',
  ),
  2939 => 
  array (
    'id' => '532522',
    'parentid' => '532500',
    'parentids' => '530000,532500,532522',
    'level' => '3',
    'name' => '蒙自县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2940 => 
  array (
    'id' => '532523',
    'parentid' => '532500',
    'parentids' => '530000,532500,532523',
    'level' => '3',
    'name' => '屏边苗族自治县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  2941 => 
  array (
    'id' => '532524',
    'parentid' => '532500',
    'parentids' => '530000,532500,532524',
    'level' => '3',
    'name' => '建水县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2942 => 
  array (
    'id' => '532525',
    'parentid' => '532500',
    'parentids' => '530000,532500,532525',
    'level' => '3',
    'name' => '石屏县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2943 => 
  array (
    'id' => '532526',
    'parentid' => '532500',
    'parentids' => '530000,532500,532526',
    'level' => '3',
    'name' => '弥勒县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2944 => 
  array (
    'id' => '532527',
    'parentid' => '532500',
    'parentids' => '530000,532500,532527',
    'level' => '3',
    'name' => '泸西县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2945 => 
  array (
    'id' => '532528',
    'parentid' => '532500',
    'parentids' => '530000,532500,532528',
    'level' => '3',
    'name' => '元阳县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2946 => 
  array (
    'id' => '532529',
    'parentid' => '532500',
    'parentids' => '530000,532500,532529',
    'level' => '3',
    'name' => '红河县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2947 => 
  array (
    'id' => '532530',
    'parentid' => '532500',
    'parentids' => '530000,532500,532530',
    'level' => '3',
    'name' => '金平苗族瑶族傣族自治县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2948 => 
  array (
    'id' => '532531',
    'parentid' => '532500',
    'parentids' => '530000,532500,532531',
    'level' => '3',
    'name' => '绿春县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2949 => 
  array (
    'id' => '532532',
    'parentid' => '532500',
    'parentids' => '530000,532500,532532',
    'level' => '3',
    'name' => '河口瑶族自治县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2950 => 
  array (
    'id' => '532600',
    'parentid' => '530000',
    'parentids' => '530000,532600',
    'level' => '2',
    'name' => '文山壮族苗族自治州',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2951 => 
  array (
    'id' => '532621',
    'parentid' => '532600',
    'parentids' => '530000,532600,532621',
    'level' => '3',
    'name' => '文山县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2952 => 
  array (
    'id' => '532622',
    'parentid' => '532600',
    'parentids' => '530000,532600,532622',
    'level' => '3',
    'name' => '砚山县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2953 => 
  array (
    'id' => '532623',
    'parentid' => '532600',
    'parentids' => '530000,532600,532623',
    'level' => '3',
    'name' => '西畴县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2954 => 
  array (
    'id' => '532624',
    'parentid' => '532600',
    'parentids' => '530000,532600,532624',
    'level' => '3',
    'name' => '麻栗坡县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2955 => 
  array (
    'id' => '532625',
    'parentid' => '532600',
    'parentids' => '530000,532600,532625',
    'level' => '3',
    'name' => '马关县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2956 => 
  array (
    'id' => '532626',
    'parentid' => '532600',
    'parentids' => '530000,532600,532626',
    'level' => '3',
    'name' => '丘北县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2957 => 
  array (
    'id' => '532627',
    'parentid' => '532600',
    'parentids' => '530000,532600,532627',
    'level' => '3',
    'name' => '广南县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2958 => 
  array (
    'id' => '532628',
    'parentid' => '532600',
    'parentids' => '530000,532600,532628',
    'level' => '3',
    'name' => '富宁县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2959 => 
  array (
    'id' => '532800',
    'parentid' => '530000',
    'parentids' => '530000,532800',
    'level' => '2',
    'name' => '西双版纳傣族自治州',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2960 => 
  array (
    'id' => '532801',
    'parentid' => '532800',
    'parentids' => '530000,532800,532801',
    'level' => '3',
    'name' => '景洪市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2961 => 
  array (
    'id' => '532822',
    'parentid' => '532800',
    'parentids' => '530000,532800,532822',
    'level' => '3',
    'name' => '勐海县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2962 => 
  array (
    'id' => '532823',
    'parentid' => '532800',
    'parentids' => '530000,532800,532823',
    'level' => '3',
    'name' => '勐腊县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2963 => 
  array (
    'id' => '532900',
    'parentid' => '530000',
    'parentids' => '530000,532900',
    'level' => '2',
    'name' => '大理白族自治州',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2964 => 
  array (
    'id' => '532901',
    'parentid' => '532900',
    'parentids' => '530000,532900,532901',
    'level' => '3',
    'name' => '大理市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2965 => 
  array (
    'id' => '532922',
    'parentid' => '532900',
    'parentids' => '530000,532900,532922',
    'level' => '3',
    'name' => '漾濞彝族自治县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2966 => 
  array (
    'id' => '532923',
    'parentid' => '532900',
    'parentids' => '530000,532900,532923',
    'level' => '3',
    'name' => '祥云县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2967 => 
  array (
    'id' => '532924',
    'parentid' => '532900',
    'parentids' => '530000,532900,532924',
    'level' => '3',
    'name' => '宾川县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  2968 => 
  array (
    'id' => '532925',
    'parentid' => '532900',
    'parentids' => '530000,532900,532925',
    'level' => '3',
    'name' => '弥渡县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  2969 => 
  array (
    'id' => '532926',
    'parentid' => '532900',
    'parentids' => '530000,532900,532926',
    'level' => '3',
    'name' => '南涧彝族自治县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2970 => 
  array (
    'id' => '532927',
    'parentid' => '532900',
    'parentids' => '530000,532900,532927',
    'level' => '3',
    'name' => '巍山彝族回族自治县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2971 => 
  array (
    'id' => '532928',
    'parentid' => '532900',
    'parentids' => '530000,532900,532928',
    'level' => '3',
    'name' => '永平县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2972 => 
  array (
    'id' => '532929',
    'parentid' => '532900',
    'parentids' => '530000,532900,532929',
    'level' => '3',
    'name' => '云龙县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2973 => 
  array (
    'id' => '532930',
    'parentid' => '532900',
    'parentids' => '530000,532900,532930',
    'level' => '3',
    'name' => '洱源县',
    'letter' => 'e',
    'listorder' => '0',
  ),
  2974 => 
  array (
    'id' => '532931',
    'parentid' => '532900',
    'parentids' => '530000,532900,532931',
    'level' => '3',
    'name' => '剑川县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  2975 => 
  array (
    'id' => '532932',
    'parentid' => '532900',
    'parentids' => '530000,532900,532932',
    'level' => '3',
    'name' => '鹤庆县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  2976 => 
  array (
    'id' => '533100',
    'parentid' => '530000',
    'parentids' => '530000,533100',
    'level' => '2',
    'name' => '德宏傣族景颇族自治州',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2977 => 
  array (
    'id' => '533102',
    'parentid' => '533100',
    'parentids' => '530000,533100,533102',
    'level' => '3',
    'name' => '瑞丽市',
    'letter' => 'r',
    'listorder' => '0',
  ),
  2978 => 
  array (
    'id' => '533103',
    'parentid' => '533100',
    'parentids' => '530000,533100,533103',
    'level' => '3',
    'name' => '潞西市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2979 => 
  array (
    'id' => '533122',
    'parentid' => '533100',
    'parentids' => '530000,533100,533122',
    'level' => '3',
    'name' => '梁河县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2980 => 
  array (
    'id' => '533123',
    'parentid' => '533100',
    'parentids' => '530000,533100,533123',
    'level' => '3',
    'name' => '盈江县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  2981 => 
  array (
    'id' => '533124',
    'parentid' => '533100',
    'parentids' => '530000,533100,533124',
    'level' => '3',
    'name' => '陇川县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2982 => 
  array (
    'id' => '533300',
    'parentid' => '530000',
    'parentids' => '530000,533300',
    'level' => '2',
    'name' => '怒江傈僳族自治州',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2983 => 
  array (
    'id' => '533321',
    'parentid' => '533300',
    'parentids' => '530000,533300,533321',
    'level' => '3',
    'name' => '泸水县',
    'letter' => 's',
    'listorder' => '0',
  ),
  2984 => 
  array (
    'id' => '533323',
    'parentid' => '533300',
    'parentids' => '530000,533300,533323',
    'level' => '3',
    'name' => '福贡县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  2985 => 
  array (
    'id' => '533324',
    'parentid' => '533300',
    'parentids' => '530000,533300,533324',
    'level' => '3',
    'name' => '贡山独龙族怒族自治县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  2986 => 
  array (
    'id' => '533325',
    'parentid' => '533300',
    'parentids' => '530000,533300,533325',
    'level' => '3',
    'name' => '兰坪白族普米族自治县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2987 => 
  array (
    'id' => '533400',
    'parentid' => '530000',
    'parentids' => '530000,533400',
    'level' => '2',
    'name' => '迪庆藏族自治州',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2988 => 
  array (
    'id' => '533421',
    'parentid' => '533400',
    'parentids' => '530000,533400,533421',
    'level' => '3',
    'name' => '香格里拉县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2989 => 
  array (
    'id' => '533422',
    'parentid' => '533400',
    'parentids' => '530000,533400,533422',
    'level' => '3',
    'name' => '德钦县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2990 => 
  array (
    'id' => '533423',
    'parentid' => '533400',
    'parentids' => '530000,533400,533423',
    'level' => '3',
    'name' => '维西傈僳族自治县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  2991 => 
  array (
    'id' => '540000',
    'parentid' => '0',
    'parentids' => '540000',
    'level' => '1',
    'name' => '西藏自治区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  2992 => 
  array (
    'id' => '540100',
    'parentid' => '540000',
    'parentids' => '540000,540100',
    'level' => '2',
    'name' => '拉萨市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2993 => 
  array (
    'id' => '540101',
    'parentid' => '540100',
    'parentids' => '540000,540100,540101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  2994 => 
  array (
    'id' => '540102',
    'parentid' => '540100',
    'parentids' => '540000,540100,540102',
    'level' => '3',
    'name' => '城关区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  2995 => 
  array (
    'id' => '540121',
    'parentid' => '540100',
    'parentids' => '540000,540100,540121',
    'level' => '3',
    'name' => '林周县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  2996 => 
  array (
    'id' => '540122',
    'parentid' => '540100',
    'parentids' => '540000,540100,540122',
    'level' => '3',
    'name' => '当雄县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  2997 => 
  array (
    'id' => '540123',
    'parentid' => '540100',
    'parentids' => '540000,540100,540123',
    'level' => '3',
    'name' => '尼木县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  2998 => 
  array (
    'id' => '540124',
    'parentid' => '540100',
    'parentids' => '540000,540100,540124',
    'level' => '3',
    'name' => '曲水县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  2999 => 
  array (
    'id' => '540125',
    'parentid' => '540100',
    'parentids' => '540000,540100,540125',
    'level' => '3',
    'name' => '堆龙德庆县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3000 => 
  array (
    'id' => '540126',
    'parentid' => '540100',
    'parentids' => '540000,540100,540126',
    'level' => '3',
    'name' => '达孜县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3001 => 
  array (
    'id' => '540127',
    'parentid' => '540100',
    'parentids' => '540000,540100,540127',
    'level' => '3',
    'name' => '墨竹工卡县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3002 => 
  array (
    'id' => '542100',
    'parentid' => '540000',
    'parentids' => '540000,542100',
    'level' => '2',
    'name' => '昌都地区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3003 => 
  array (
    'id' => '542121',
    'parentid' => '542100',
    'parentids' => '540000,542100,542121',
    'level' => '3',
    'name' => '昌都县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3004 => 
  array (
    'id' => '542122',
    'parentid' => '542100',
    'parentids' => '540000,542100,542122',
    'level' => '3',
    'name' => '江达县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3005 => 
  array (
    'id' => '542123',
    'parentid' => '542100',
    'parentids' => '540000,542100,542123',
    'level' => '3',
    'name' => '贡觉县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3006 => 
  array (
    'id' => '542124',
    'parentid' => '542100',
    'parentids' => '540000,542100,542124',
    'level' => '3',
    'name' => '类乌齐县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3007 => 
  array (
    'id' => '542125',
    'parentid' => '542100',
    'parentids' => '540000,542100,542125',
    'level' => '3',
    'name' => '丁青县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3008 => 
  array (
    'id' => '542126',
    'parentid' => '542100',
    'parentids' => '540000,542100,542126',
    'level' => '3',
    'name' => '察雅县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3009 => 
  array (
    'id' => '542127',
    'parentid' => '542100',
    'parentids' => '540000,542100,542127',
    'level' => '3',
    'name' => '八宿县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3010 => 
  array (
    'id' => '542128',
    'parentid' => '542100',
    'parentids' => '540000,542100,542128',
    'level' => '3',
    'name' => '左贡县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3011 => 
  array (
    'id' => '542129',
    'parentid' => '542100',
    'parentids' => '540000,542100,542129',
    'level' => '3',
    'name' => '芒康县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3012 => 
  array (
    'id' => '542132',
    'parentid' => '542100',
    'parentids' => '540000,542100,542132',
    'level' => '3',
    'name' => '洛隆县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3013 => 
  array (
    'id' => '542133',
    'parentid' => '542100',
    'parentids' => '540000,542100,542133',
    'level' => '3',
    'name' => '边坝县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3014 => 
  array (
    'id' => '542200',
    'parentid' => '540000',
    'parentids' => '540000,542200',
    'level' => '2',
    'name' => '山南地区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3015 => 
  array (
    'id' => '542221',
    'parentid' => '542200',
    'parentids' => '540000,542200,542221',
    'level' => '3',
    'name' => '乃东县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  3016 => 
  array (
    'id' => '542222',
    'parentid' => '542200',
    'parentids' => '540000,542200,542222',
    'level' => '3',
    'name' => '扎囊县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3017 => 
  array (
    'id' => '542223',
    'parentid' => '542200',
    'parentids' => '540000,542200,542223',
    'level' => '3',
    'name' => '贡嘎县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3018 => 
  array (
    'id' => '542224',
    'parentid' => '542200',
    'parentids' => '540000,542200,542224',
    'level' => '3',
    'name' => '桑日县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3019 => 
  array (
    'id' => '542225',
    'parentid' => '542200',
    'parentids' => '540000,542200,542225',
    'level' => '3',
    'name' => '琼结县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3020 => 
  array (
    'id' => '542226',
    'parentid' => '542200',
    'parentids' => '540000,542200,542226',
    'level' => '3',
    'name' => '曲松县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3021 => 
  array (
    'id' => '542227',
    'parentid' => '542200',
    'parentids' => '540000,542200,542227',
    'level' => '3',
    'name' => '措美县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3022 => 
  array (
    'id' => '542228',
    'parentid' => '542200',
    'parentids' => '540000,542200,542228',
    'level' => '3',
    'name' => '洛扎县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3023 => 
  array (
    'id' => '542229',
    'parentid' => '542200',
    'parentids' => '540000,542200,542229',
    'level' => '3',
    'name' => '加查县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3024 => 
  array (
    'id' => '542231',
    'parentid' => '542200',
    'parentids' => '540000,542200,542231',
    'level' => '3',
    'name' => '隆子县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3025 => 
  array (
    'id' => '542232',
    'parentid' => '542200',
    'parentids' => '540000,542200,542232',
    'level' => '3',
    'name' => '错那县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3026 => 
  array (
    'id' => '542233',
    'parentid' => '542200',
    'parentids' => '540000,542200,542233',
    'level' => '3',
    'name' => '浪卡子县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3027 => 
  array (
    'id' => '542300',
    'parentid' => '540000',
    'parentids' => '540000,542300',
    'level' => '2',
    'name' => '日喀则地区',
    'letter' => 'r',
    'listorder' => '0',
  ),
  3028 => 
  array (
    'id' => '542301',
    'parentid' => '542300',
    'parentids' => '540000,542300,542301',
    'level' => '3',
    'name' => '日喀则市',
    'letter' => 'r',
    'listorder' => '0',
  ),
  3029 => 
  array (
    'id' => '542322',
    'parentid' => '542300',
    'parentids' => '540000,542300,542322',
    'level' => '3',
    'name' => '南木林县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  3030 => 
  array (
    'id' => '542323',
    'parentid' => '542300',
    'parentids' => '540000,542300,542323',
    'level' => '3',
    'name' => '江孜县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3031 => 
  array (
    'id' => '542324',
    'parentid' => '542300',
    'parentids' => '540000,542300,542324',
    'level' => '3',
    'name' => '定日县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3032 => 
  array (
    'id' => '542325',
    'parentid' => '542300',
    'parentids' => '540000,542300,542325',
    'level' => '3',
    'name' => '萨迦县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3033 => 
  array (
    'id' => '542326',
    'parentid' => '542300',
    'parentids' => '540000,542300,542326',
    'level' => '3',
    'name' => '拉孜县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3034 => 
  array (
    'id' => '542327',
    'parentid' => '542300',
    'parentids' => '540000,542300,542327',
    'level' => '3',
    'name' => '昂仁县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  3035 => 
  array (
    'id' => '542328',
    'parentid' => '542300',
    'parentids' => '540000,542300,542328',
    'level' => '3',
    'name' => '谢通门县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3036 => 
  array (
    'id' => '542329',
    'parentid' => '542300',
    'parentids' => '540000,542300,542329',
    'level' => '3',
    'name' => '白朗县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3037 => 
  array (
    'id' => '542330',
    'parentid' => '542300',
    'parentids' => '540000,542300,542330',
    'level' => '3',
    'name' => '仁布县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  3038 => 
  array (
    'id' => '542331',
    'parentid' => '542300',
    'parentids' => '540000,542300,542331',
    'level' => '3',
    'name' => '康马县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  3039 => 
  array (
    'id' => '542332',
    'parentid' => '542300',
    'parentids' => '540000,542300,542332',
    'level' => '3',
    'name' => '定结县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3040 => 
  array (
    'id' => '542333',
    'parentid' => '542300',
    'parentids' => '540000,542300,542333',
    'level' => '3',
    'name' => '仲巴县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3041 => 
  array (
    'id' => '542334',
    'parentid' => '542300',
    'parentids' => '540000,542300,542334',
    'level' => '3',
    'name' => '亚东县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3042 => 
  array (
    'id' => '542335',
    'parentid' => '542300',
    'parentids' => '540000,542300,542335',
    'level' => '3',
    'name' => '吉隆县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3043 => 
  array (
    'id' => '542336',
    'parentid' => '542300',
    'parentids' => '540000,542300,542336',
    'level' => '3',
    'name' => '聂拉木县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  3044 => 
  array (
    'id' => '542337',
    'parentid' => '542300',
    'parentids' => '540000,542300,542337',
    'level' => '3',
    'name' => '萨嘎县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3045 => 
  array (
    'id' => '542338',
    'parentid' => '542300',
    'parentids' => '540000,542300,542338',
    'level' => '3',
    'name' => '岗巴县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3046 => 
  array (
    'id' => '542400',
    'parentid' => '540000',
    'parentids' => '540000,542400',
    'level' => '2',
    'name' => '那曲地区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  3047 => 
  array (
    'id' => '542421',
    'parentid' => '542400',
    'parentids' => '540000,542400,542421',
    'level' => '3',
    'name' => '那曲县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  3048 => 
  array (
    'id' => '542422',
    'parentid' => '542400',
    'parentids' => '540000,542400,542422',
    'level' => '3',
    'name' => '嘉黎县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3049 => 
  array (
    'id' => '542423',
    'parentid' => '542400',
    'parentids' => '540000,542400,542423',
    'level' => '3',
    'name' => '比如县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3050 => 
  array (
    'id' => '542424',
    'parentid' => '542400',
    'parentids' => '540000,542400,542424',
    'level' => '3',
    'name' => '聂荣县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  3051 => 
  array (
    'id' => '542425',
    'parentid' => '542400',
    'parentids' => '540000,542400,542425',
    'level' => '3',
    'name' => '安多县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  3052 => 
  array (
    'id' => '542426',
    'parentid' => '542400',
    'parentids' => '540000,542400,542426',
    'level' => '3',
    'name' => '申扎县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3053 => 
  array (
    'id' => '542427',
    'parentid' => '542400',
    'parentids' => '540000,542400,542427',
    'level' => '3',
    'name' => '索　县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3054 => 
  array (
    'id' => '542428',
    'parentid' => '542400',
    'parentids' => '540000,542400,542428',
    'level' => '3',
    'name' => '班戈县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3055 => 
  array (
    'id' => '542429',
    'parentid' => '542400',
    'parentids' => '540000,542400,542429',
    'level' => '3',
    'name' => '巴青县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3056 => 
  array (
    'id' => '542430',
    'parentid' => '542400',
    'parentids' => '540000,542400,542430',
    'level' => '3',
    'name' => '尼玛县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  3057 => 
  array (
    'id' => '542500',
    'parentid' => '540000',
    'parentids' => '540000,542500',
    'level' => '2',
    'name' => '阿里地区',
    'letter' => 'a',
    'listorder' => '0',
  ),
  3058 => 
  array (
    'id' => '542521',
    'parentid' => '542500',
    'parentids' => '540000,542500,542521',
    'level' => '3',
    'name' => '普兰县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  3059 => 
  array (
    'id' => '542522',
    'parentid' => '542500',
    'parentids' => '540000,542500,542522',
    'level' => '3',
    'name' => '札达县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3060 => 
  array (
    'id' => '542523',
    'parentid' => '542500',
    'parentids' => '540000,542500,542523',
    'level' => '3',
    'name' => '噶尔县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3061 => 
  array (
    'id' => '542524',
    'parentid' => '542500',
    'parentids' => '540000,542500,542524',
    'level' => '3',
    'name' => '日土县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  3062 => 
  array (
    'id' => '542525',
    'parentid' => '542500',
    'parentids' => '540000,542500,542525',
    'level' => '3',
    'name' => '革吉县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3063 => 
  array (
    'id' => '542526',
    'parentid' => '542500',
    'parentids' => '540000,542500,542526',
    'level' => '3',
    'name' => '改则县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3064 => 
  array (
    'id' => '542527',
    'parentid' => '542500',
    'parentids' => '540000,542500,542527',
    'level' => '3',
    'name' => '措勤县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3065 => 
  array (
    'id' => '542600',
    'parentid' => '540000',
    'parentids' => '540000,542600',
    'level' => '2',
    'name' => '林芝地区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3066 => 
  array (
    'id' => '542621',
    'parentid' => '542600',
    'parentids' => '540000,542600,542621',
    'level' => '3',
    'name' => '林芝县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3067 => 
  array (
    'id' => '542622',
    'parentid' => '542600',
    'parentids' => '540000,542600,542622',
    'level' => '3',
    'name' => '工布江达县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3068 => 
  array (
    'id' => '542623',
    'parentid' => '542600',
    'parentids' => '540000,542600,542623',
    'level' => '3',
    'name' => '米林县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3069 => 
  array (
    'id' => '542624',
    'parentid' => '542600',
    'parentids' => '540000,542600,542624',
    'level' => '3',
    'name' => '墨脱县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3070 => 
  array (
    'id' => '542625',
    'parentid' => '542600',
    'parentids' => '540000,542600,542625',
    'level' => '3',
    'name' => '波密县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3071 => 
  array (
    'id' => '542626',
    'parentid' => '542600',
    'parentids' => '540000,542600,542626',
    'level' => '3',
    'name' => '察隅县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3072 => 
  array (
    'id' => '542627',
    'parentid' => '542600',
    'parentids' => '540000,542600,542627',
    'level' => '3',
    'name' => '朗　县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3073 => 
  array (
    'id' => '610000',
    'parentid' => '0',
    'parentids' => '610000',
    'level' => '1',
    'name' => '陕西省',
    'letter' => 's',
    'listorder' => '0',
  ),
  3074 => 
  array (
    'id' => '610100',
    'parentid' => '610000',
    'parentids' => '610000,610100',
    'level' => '2',
    'name' => '西安市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3075 => 
  array (
    'id' => '610101',
    'parentid' => '610100',
    'parentids' => '610000,610100,610101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3076 => 
  array (
    'id' => '610102',
    'parentid' => '610100',
    'parentids' => '610000,610100,610102',
    'level' => '3',
    'name' => '新城区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3077 => 
  array (
    'id' => '610103',
    'parentid' => '610100',
    'parentids' => '610000,610100,610103',
    'level' => '3',
    'name' => '碑林区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3078 => 
  array (
    'id' => '610104',
    'parentid' => '610100',
    'parentids' => '610000,610100,610104',
    'level' => '3',
    'name' => '莲湖区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3079 => 
  array (
    'id' => '610111',
    'parentid' => '610100',
    'parentids' => '610000,610100,610111',
    'level' => '3',
    'name' => '灞桥区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3080 => 
  array (
    'id' => '610112',
    'parentid' => '610100',
    'parentids' => '610000,610100,610112',
    'level' => '3',
    'name' => '未央区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3081 => 
  array (
    'id' => '610113',
    'parentid' => '610100',
    'parentids' => '610000,610100,610113',
    'level' => '3',
    'name' => '雁塔区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3082 => 
  array (
    'id' => '610114',
    'parentid' => '610100',
    'parentids' => '610000,610100,610114',
    'level' => '3',
    'name' => '阎良区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3083 => 
  array (
    'id' => '610115',
    'parentid' => '610100',
    'parentids' => '610000,610100,610115',
    'level' => '3',
    'name' => '临潼区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3084 => 
  array (
    'id' => '610116',
    'parentid' => '610100',
    'parentids' => '610000,610100,610116',
    'level' => '3',
    'name' => '长安区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3085 => 
  array (
    'id' => '610122',
    'parentid' => '610100',
    'parentids' => '610000,610100,610122',
    'level' => '3',
    'name' => '蓝田县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3086 => 
  array (
    'id' => '610124',
    'parentid' => '610100',
    'parentids' => '610000,610100,610124',
    'level' => '3',
    'name' => '周至县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3087 => 
  array (
    'id' => '610125',
    'parentid' => '610100',
    'parentids' => '610000,610100,610125',
    'level' => '3',
    'name' => '户　县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3088 => 
  array (
    'id' => '610126',
    'parentid' => '610100',
    'parentids' => '610000,610100,610126',
    'level' => '3',
    'name' => '高陵县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3089 => 
  array (
    'id' => '610200',
    'parentid' => '610000',
    'parentids' => '610000,610200',
    'level' => '2',
    'name' => '铜川市',
    'letter' => 't',
    'listorder' => '0',
  ),
  3090 => 
  array (
    'id' => '610201',
    'parentid' => '610200',
    'parentids' => '610000,610200,610201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3091 => 
  array (
    'id' => '610202',
    'parentid' => '610200',
    'parentids' => '610000,610200,610202',
    'level' => '3',
    'name' => '王益区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3092 => 
  array (
    'id' => '610203',
    'parentid' => '610200',
    'parentids' => '610000,610200,610203',
    'level' => '3',
    'name' => '印台区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3093 => 
  array (
    'id' => '610204',
    'parentid' => '610200',
    'parentids' => '610000,610200,610204',
    'level' => '3',
    'name' => '耀州区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3094 => 
  array (
    'id' => '610222',
    'parentid' => '610200',
    'parentids' => '610000,610200,610222',
    'level' => '3',
    'name' => '宜君县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3095 => 
  array (
    'id' => '610300',
    'parentid' => '610000',
    'parentids' => '610000,610300',
    'level' => '2',
    'name' => '宝鸡市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3096 => 
  array (
    'id' => '610301',
    'parentid' => '610300',
    'parentids' => '610000,610300,610301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3097 => 
  array (
    'id' => '610302',
    'parentid' => '610300',
    'parentids' => '610000,610300,610302',
    'level' => '3',
    'name' => '渭滨区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3098 => 
  array (
    'id' => '610303',
    'parentid' => '610300',
    'parentids' => '610000,610300,610303',
    'level' => '3',
    'name' => '金台区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3099 => 
  array (
    'id' => '610304',
    'parentid' => '610300',
    'parentids' => '610000,610300,610304',
    'level' => '3',
    'name' => '陈仓区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3100 => 
  array (
    'id' => '610322',
    'parentid' => '610300',
    'parentids' => '610000,610300,610322',
    'level' => '3',
    'name' => '凤翔县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  3101 => 
  array (
    'id' => '610323',
    'parentid' => '610300',
    'parentids' => '610000,610300,610323',
    'level' => '3',
    'name' => '岐山县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3102 => 
  array (
    'id' => '610324',
    'parentid' => '610300',
    'parentids' => '610000,610300,610324',
    'level' => '3',
    'name' => '扶风县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  3103 => 
  array (
    'id' => '610326',
    'parentid' => '610300',
    'parentids' => '610000,610300,610326',
    'level' => '3',
    'name' => '眉　县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3104 => 
  array (
    'id' => '610327',
    'parentid' => '610300',
    'parentids' => '610000,610300,610327',
    'level' => '3',
    'name' => '陇　县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3105 => 
  array (
    'id' => '610328',
    'parentid' => '610300',
    'parentids' => '610000,610300,610328',
    'level' => '3',
    'name' => '千阳县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3106 => 
  array (
    'id' => '610329',
    'parentid' => '610300',
    'parentids' => '610000,610300,610329',
    'level' => '3',
    'name' => '麟游县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3107 => 
  array (
    'id' => '610330',
    'parentid' => '610300',
    'parentids' => '610000,610300,610330',
    'level' => '3',
    'name' => '凤　县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  3108 => 
  array (
    'id' => '610331',
    'parentid' => '610300',
    'parentids' => '610000,610300,610331',
    'level' => '3',
    'name' => '太白县',
    'letter' => 't',
    'listorder' => '0',
  ),
  3109 => 
  array (
    'id' => '610400',
    'parentid' => '610000',
    'parentids' => '610000,610400',
    'level' => '2',
    'name' => '咸阳市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3110 => 
  array (
    'id' => '610401',
    'parentid' => '610400',
    'parentids' => '610000,610400,610401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3111 => 
  array (
    'id' => '610402',
    'parentid' => '610400',
    'parentids' => '610000,610400,610402',
    'level' => '3',
    'name' => '秦都区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3112 => 
  array (
    'id' => '610403',
    'parentid' => '610400',
    'parentids' => '610000,610400,610403',
    'level' => '3',
    'name' => '杨凌区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3113 => 
  array (
    'id' => '610404',
    'parentid' => '610400',
    'parentids' => '610000,610400,610404',
    'level' => '3',
    'name' => '渭城区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3114 => 
  array (
    'id' => '610422',
    'parentid' => '610400',
    'parentids' => '610000,610400,610422',
    'level' => '3',
    'name' => '三原县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3115 => 
  array (
    'id' => '610423',
    'parentid' => '610400',
    'parentids' => '610000,610400,610423',
    'level' => '3',
    'name' => '泾阳县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3116 => 
  array (
    'id' => '610424',
    'parentid' => '610400',
    'parentids' => '610000,610400,610424',
    'level' => '3',
    'name' => '乾　县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3117 => 
  array (
    'id' => '610425',
    'parentid' => '610400',
    'parentids' => '610000,610400,610425',
    'level' => '3',
    'name' => '礼泉县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3118 => 
  array (
    'id' => '610426',
    'parentid' => '610400',
    'parentids' => '610000,610400,610426',
    'level' => '3',
    'name' => '永寿县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3119 => 
  array (
    'id' => '610427',
    'parentid' => '610400',
    'parentids' => '610000,610400,610427',
    'level' => '3',
    'name' => '彬　县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3120 => 
  array (
    'id' => '610428',
    'parentid' => '610400',
    'parentids' => '610000,610400,610428',
    'level' => '3',
    'name' => '长武县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3121 => 
  array (
    'id' => '610429',
    'parentid' => '610400',
    'parentids' => '610000,610400,610429',
    'level' => '3',
    'name' => '旬邑县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3122 => 
  array (
    'id' => '610430',
    'parentid' => '610400',
    'parentids' => '610000,610400,610430',
    'level' => '3',
    'name' => '淳化县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3123 => 
  array (
    'id' => '610431',
    'parentid' => '610400',
    'parentids' => '610000,610400,610431',
    'level' => '3',
    'name' => '武功县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3124 => 
  array (
    'id' => '610481',
    'parentid' => '610400',
    'parentids' => '610000,610400,610481',
    'level' => '3',
    'name' => '兴平市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3125 => 
  array (
    'id' => '610500',
    'parentid' => '610000',
    'parentids' => '610000,610500',
    'level' => '2',
    'name' => '渭南市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3126 => 
  array (
    'id' => '610501',
    'parentid' => '610500',
    'parentids' => '610000,610500,610501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3127 => 
  array (
    'id' => '610502',
    'parentid' => '610500',
    'parentids' => '610000,610500,610502',
    'level' => '3',
    'name' => '临渭区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3128 => 
  array (
    'id' => '610521',
    'parentid' => '610500',
    'parentids' => '610000,610500,610521',
    'level' => '3',
    'name' => '华　县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3129 => 
  array (
    'id' => '610522',
    'parentid' => '610500',
    'parentids' => '610000,610500,610522',
    'level' => '3',
    'name' => '潼关县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3130 => 
  array (
    'id' => '610523',
    'parentid' => '610500',
    'parentids' => '610000,610500,610523',
    'level' => '3',
    'name' => '大荔县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3131 => 
  array (
    'id' => '610524',
    'parentid' => '610500',
    'parentids' => '610000,610500,610524',
    'level' => '3',
    'name' => '合阳县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3132 => 
  array (
    'id' => '610525',
    'parentid' => '610500',
    'parentids' => '610000,610500,610525',
    'level' => '3',
    'name' => '澄城县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3133 => 
  array (
    'id' => '610526',
    'parentid' => '610500',
    'parentids' => '610000,610500,610526',
    'level' => '3',
    'name' => '蒲城县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  3134 => 
  array (
    'id' => '610527',
    'parentid' => '610500',
    'parentids' => '610000,610500,610527',
    'level' => '3',
    'name' => '白水县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3135 => 
  array (
    'id' => '610528',
    'parentid' => '610500',
    'parentids' => '610000,610500,610528',
    'level' => '3',
    'name' => '富平县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  3136 => 
  array (
    'id' => '610581',
    'parentid' => '610500',
    'parentids' => '610000,610500,610581',
    'level' => '3',
    'name' => '韩城市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3137 => 
  array (
    'id' => '610582',
    'parentid' => '610500',
    'parentids' => '610000,610500,610582',
    'level' => '3',
    'name' => '华阴市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3138 => 
  array (
    'id' => '610600',
    'parentid' => '610000',
    'parentids' => '610000,610600',
    'level' => '2',
    'name' => '延安市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3139 => 
  array (
    'id' => '610601',
    'parentid' => '610600',
    'parentids' => '610000,610600,610601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3140 => 
  array (
    'id' => '610602',
    'parentid' => '610600',
    'parentids' => '610000,610600,610602',
    'level' => '3',
    'name' => '宝塔区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3141 => 
  array (
    'id' => '610621',
    'parentid' => '610600',
    'parentids' => '610000,610600,610621',
    'level' => '3',
    'name' => '延长县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3142 => 
  array (
    'id' => '610622',
    'parentid' => '610600',
    'parentids' => '610000,610600,610622',
    'level' => '3',
    'name' => '延川县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3143 => 
  array (
    'id' => '610623',
    'parentid' => '610600',
    'parentids' => '610000,610600,610623',
    'level' => '3',
    'name' => '子长县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3144 => 
  array (
    'id' => '610624',
    'parentid' => '610600',
    'parentids' => '610000,610600,610624',
    'level' => '3',
    'name' => '安塞县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  3145 => 
  array (
    'id' => '610625',
    'parentid' => '610600',
    'parentids' => '610000,610600,610625',
    'level' => '3',
    'name' => '志丹县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3146 => 
  array (
    'id' => '610626',
    'parentid' => '610600',
    'parentids' => '610000,610600,610626',
    'level' => '3',
    'name' => '吴旗县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3147 => 
  array (
    'id' => '610627',
    'parentid' => '610600',
    'parentids' => '610000,610600,610627',
    'level' => '3',
    'name' => '甘泉县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3148 => 
  array (
    'id' => '610628',
    'parentid' => '610600',
    'parentids' => '610000,610600,610628',
    'level' => '3',
    'name' => '富　县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  3149 => 
  array (
    'id' => '610629',
    'parentid' => '610600',
    'parentids' => '610000,610600,610629',
    'level' => '3',
    'name' => '洛川县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3150 => 
  array (
    'id' => '610630',
    'parentid' => '610600',
    'parentids' => '610000,610600,610630',
    'level' => '3',
    'name' => '宜川县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3151 => 
  array (
    'id' => '610631',
    'parentid' => '610600',
    'parentids' => '610000,610600,610631',
    'level' => '3',
    'name' => '黄龙县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3152 => 
  array (
    'id' => '610632',
    'parentid' => '610600',
    'parentids' => '610000,610600,610632',
    'level' => '3',
    'name' => '黄陵县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3153 => 
  array (
    'id' => '610700',
    'parentid' => '610000',
    'parentids' => '610000,610700',
    'level' => '2',
    'name' => '汉中市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3154 => 
  array (
    'id' => '610701',
    'parentid' => '610700',
    'parentids' => '610000,610700,610701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3155 => 
  array (
    'id' => '610702',
    'parentid' => '610700',
    'parentids' => '610000,610700,610702',
    'level' => '3',
    'name' => '汉台区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3156 => 
  array (
    'id' => '610721',
    'parentid' => '610700',
    'parentids' => '610000,610700,610721',
    'level' => '3',
    'name' => '南郑县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  3157 => 
  array (
    'id' => '610722',
    'parentid' => '610700',
    'parentids' => '610000,610700,610722',
    'level' => '3',
    'name' => '城固县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3158 => 
  array (
    'id' => '610723',
    'parentid' => '610700',
    'parentids' => '610000,610700,610723',
    'level' => '3',
    'name' => '洋　县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3159 => 
  array (
    'id' => '610724',
    'parentid' => '610700',
    'parentids' => '610000,610700,610724',
    'level' => '3',
    'name' => '西乡县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3160 => 
  array (
    'id' => '610725',
    'parentid' => '610700',
    'parentids' => '610000,610700,610725',
    'level' => '3',
    'name' => '勉　县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3161 => 
  array (
    'id' => '610726',
    'parentid' => '610700',
    'parentids' => '610000,610700,610726',
    'level' => '3',
    'name' => '宁强县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  3162 => 
  array (
    'id' => '610727',
    'parentid' => '610700',
    'parentids' => '610000,610700,610727',
    'level' => '3',
    'name' => '略阳县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3163 => 
  array (
    'id' => '610728',
    'parentid' => '610700',
    'parentids' => '610000,610700,610728',
    'level' => '3',
    'name' => '镇巴县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3164 => 
  array (
    'id' => '610729',
    'parentid' => '610700',
    'parentids' => '610000,610700,610729',
    'level' => '3',
    'name' => '留坝县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3165 => 
  array (
    'id' => '610730',
    'parentid' => '610700',
    'parentids' => '610000,610700,610730',
    'level' => '3',
    'name' => '佛坪县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  3166 => 
  array (
    'id' => '610800',
    'parentid' => '610000',
    'parentids' => '610000,610800',
    'level' => '2',
    'name' => '榆林市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3167 => 
  array (
    'id' => '610801',
    'parentid' => '610800',
    'parentids' => '610000,610800,610801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3168 => 
  array (
    'id' => '610802',
    'parentid' => '610800',
    'parentids' => '610000,610800,610802',
    'level' => '3',
    'name' => '榆阳区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3169 => 
  array (
    'id' => '610821',
    'parentid' => '610800',
    'parentids' => '610000,610800,610821',
    'level' => '3',
    'name' => '神木县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3170 => 
  array (
    'id' => '610822',
    'parentid' => '610800',
    'parentids' => '610000,610800,610822',
    'level' => '3',
    'name' => '府谷县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  3171 => 
  array (
    'id' => '610823',
    'parentid' => '610800',
    'parentids' => '610000,610800,610823',
    'level' => '3',
    'name' => '横山县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3172 => 
  array (
    'id' => '610824',
    'parentid' => '610800',
    'parentids' => '610000,610800,610824',
    'level' => '3',
    'name' => '靖边县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3173 => 
  array (
    'id' => '610825',
    'parentid' => '610800',
    'parentids' => '610000,610800,610825',
    'level' => '3',
    'name' => '定边县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3174 => 
  array (
    'id' => '610826',
    'parentid' => '610800',
    'parentids' => '610000,610800,610826',
    'level' => '3',
    'name' => '绥德县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3175 => 
  array (
    'id' => '610827',
    'parentid' => '610800',
    'parentids' => '610000,610800,610827',
    'level' => '3',
    'name' => '米脂县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3176 => 
  array (
    'id' => '610828',
    'parentid' => '610800',
    'parentids' => '610000,610800,610828',
    'level' => '3',
    'name' => '佳　县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3177 => 
  array (
    'id' => '610829',
    'parentid' => '610800',
    'parentids' => '610000,610800,610829',
    'level' => '3',
    'name' => '吴堡县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3178 => 
  array (
    'id' => '610830',
    'parentid' => '610800',
    'parentids' => '610000,610800,610830',
    'level' => '3',
    'name' => '清涧县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3179 => 
  array (
    'id' => '610831',
    'parentid' => '610800',
    'parentids' => '610000,610800,610831',
    'level' => '3',
    'name' => '子洲县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3180 => 
  array (
    'id' => '610900',
    'parentid' => '610000',
    'parentids' => '610000,610900',
    'level' => '2',
    'name' => '安康市',
    'letter' => 'a',
    'listorder' => '0',
  ),
  3181 => 
  array (
    'id' => '610901',
    'parentid' => '610900',
    'parentids' => '610000,610900,610901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3182 => 
  array (
    'id' => '610902',
    'parentid' => '610900',
    'parentids' => '610000,610900,610902',
    'level' => '3',
    'name' => '汉滨区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3183 => 
  array (
    'id' => '610921',
    'parentid' => '610900',
    'parentids' => '610000,610900,610921',
    'level' => '3',
    'name' => '汉阴县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3184 => 
  array (
    'id' => '610922',
    'parentid' => '610900',
    'parentids' => '610000,610900,610922',
    'level' => '3',
    'name' => '石泉县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3185 => 
  array (
    'id' => '610923',
    'parentid' => '610900',
    'parentids' => '610000,610900,610923',
    'level' => '3',
    'name' => '宁陕县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  3186 => 
  array (
    'id' => '610924',
    'parentid' => '610900',
    'parentids' => '610000,610900,610924',
    'level' => '3',
    'name' => '紫阳县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3187 => 
  array (
    'id' => '610925',
    'parentid' => '610900',
    'parentids' => '610000,610900,610925',
    'level' => '3',
    'name' => '岚皋县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3188 => 
  array (
    'id' => '610926',
    'parentid' => '610900',
    'parentids' => '610000,610900,610926',
    'level' => '3',
    'name' => '平利县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  3189 => 
  array (
    'id' => '610927',
    'parentid' => '610900',
    'parentids' => '610000,610900,610927',
    'level' => '3',
    'name' => '镇坪县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3190 => 
  array (
    'id' => '610928',
    'parentid' => '610900',
    'parentids' => '610000,610900,610928',
    'level' => '3',
    'name' => '旬阳县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3191 => 
  array (
    'id' => '610929',
    'parentid' => '610900',
    'parentids' => '610000,610900,610929',
    'level' => '3',
    'name' => '白河县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3192 => 
  array (
    'id' => '611000',
    'parentid' => '610000',
    'parentids' => '610000,611000',
    'level' => '2',
    'name' => '商洛市',
    'letter' => 's',
    'listorder' => '0',
  ),
  3193 => 
  array (
    'id' => '611001',
    'parentid' => '611000',
    'parentids' => '610000,611000,611001',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3194 => 
  array (
    'id' => '611002',
    'parentid' => '611000',
    'parentids' => '610000,611000,611002',
    'level' => '3',
    'name' => '商州区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3195 => 
  array (
    'id' => '611021',
    'parentid' => '611000',
    'parentids' => '610000,611000,611021',
    'level' => '3',
    'name' => '洛南县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3196 => 
  array (
    'id' => '611022',
    'parentid' => '611000',
    'parentids' => '610000,611000,611022',
    'level' => '3',
    'name' => '丹凤县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3197 => 
  array (
    'id' => '611023',
    'parentid' => '611000',
    'parentids' => '610000,611000,611023',
    'level' => '3',
    'name' => '商南县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3198 => 
  array (
    'id' => '611024',
    'parentid' => '611000',
    'parentids' => '610000,611000,611024',
    'level' => '3',
    'name' => '山阳县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3199 => 
  array (
    'id' => '611025',
    'parentid' => '611000',
    'parentids' => '610000,611000,611025',
    'level' => '3',
    'name' => '镇安县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3200 => 
  array (
    'id' => '611026',
    'parentid' => '611000',
    'parentids' => '610000,611000,611026',
    'level' => '3',
    'name' => '柞水县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3201 => 
  array (
    'id' => '620000',
    'parentid' => '0',
    'parentids' => '620000',
    'level' => '1',
    'name' => '甘肃省',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3202 => 
  array (
    'id' => '620100',
    'parentid' => '620000',
    'parentids' => '620000,620100',
    'level' => '2',
    'name' => '兰州市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3203 => 
  array (
    'id' => '620101',
    'parentid' => '620100',
    'parentids' => '620000,620100,620101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3204 => 
  array (
    'id' => '620102',
    'parentid' => '620100',
    'parentids' => '620000,620100,620102',
    'level' => '3',
    'name' => '城关区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3205 => 
  array (
    'id' => '620103',
    'parentid' => '620100',
    'parentids' => '620000,620100,620103',
    'level' => '3',
    'name' => '七里河区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3206 => 
  array (
    'id' => '620104',
    'parentid' => '620100',
    'parentids' => '620000,620100,620104',
    'level' => '3',
    'name' => '西固区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3207 => 
  array (
    'id' => '620105',
    'parentid' => '620100',
    'parentids' => '620000,620100,620105',
    'level' => '3',
    'name' => '安宁区',
    'letter' => 'a',
    'listorder' => '0',
  ),
  3208 => 
  array (
    'id' => '620111',
    'parentid' => '620100',
    'parentids' => '620000,620100,620111',
    'level' => '3',
    'name' => '红古区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3209 => 
  array (
    'id' => '620121',
    'parentid' => '620100',
    'parentids' => '620000,620100,620121',
    'level' => '3',
    'name' => '永登县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3210 => 
  array (
    'id' => '620122',
    'parentid' => '620100',
    'parentids' => '620000,620100,620122',
    'level' => '3',
    'name' => '皋兰县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3211 => 
  array (
    'id' => '620123',
    'parentid' => '620100',
    'parentids' => '620000,620100,620123',
    'level' => '3',
    'name' => '榆中县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3212 => 
  array (
    'id' => '620200',
    'parentid' => '620000',
    'parentids' => '620000,620200',
    'level' => '2',
    'name' => '嘉峪关市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3213 => 
  array (
    'id' => '620201',
    'parentid' => '620200',
    'parentids' => '620000,620200,620201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3214 => 
  array (
    'id' => '620300',
    'parentid' => '620000',
    'parentids' => '620000,620300',
    'level' => '2',
    'name' => '金昌市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3215 => 
  array (
    'id' => '620301',
    'parentid' => '620300',
    'parentids' => '620000,620300,620301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3216 => 
  array (
    'id' => '620302',
    'parentid' => '620300',
    'parentids' => '620000,620300,620302',
    'level' => '3',
    'name' => '金川区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3217 => 
  array (
    'id' => '620321',
    'parentid' => '620300',
    'parentids' => '620000,620300,620321',
    'level' => '3',
    'name' => '永昌县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3218 => 
  array (
    'id' => '620400',
    'parentid' => '620000',
    'parentids' => '620000,620400',
    'level' => '2',
    'name' => '白银市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3219 => 
  array (
    'id' => '620401',
    'parentid' => '620400',
    'parentids' => '620000,620400,620401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3220 => 
  array (
    'id' => '620402',
    'parentid' => '620400',
    'parentids' => '620000,620400,620402',
    'level' => '3',
    'name' => '白银区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3221 => 
  array (
    'id' => '620403',
    'parentid' => '620400',
    'parentids' => '620000,620400,620403',
    'level' => '3',
    'name' => '平川区',
    'letter' => 'p',
    'listorder' => '0',
  ),
  3222 => 
  array (
    'id' => '620421',
    'parentid' => '620400',
    'parentids' => '620000,620400,620421',
    'level' => '3',
    'name' => '靖远县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3223 => 
  array (
    'id' => '620422',
    'parentid' => '620400',
    'parentids' => '620000,620400,620422',
    'level' => '3',
    'name' => '会宁县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3224 => 
  array (
    'id' => '620423',
    'parentid' => '620400',
    'parentids' => '620000,620400,620423',
    'level' => '3',
    'name' => '景泰县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3225 => 
  array (
    'id' => '620500',
    'parentid' => '620000',
    'parentids' => '620000,620500',
    'level' => '2',
    'name' => '天水市',
    'letter' => 't',
    'listorder' => '0',
  ),
  3226 => 
  array (
    'id' => '620501',
    'parentid' => '620500',
    'parentids' => '620000,620500,620501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3227 => 
  array (
    'id' => '620502',
    'parentid' => '620500',
    'parentids' => '620000,620500,620502',
    'level' => '3',
    'name' => '秦城区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3228 => 
  array (
    'id' => '620503',
    'parentid' => '620500',
    'parentids' => '620000,620500,620503',
    'level' => '3',
    'name' => '北道区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3229 => 
  array (
    'id' => '620521',
    'parentid' => '620500',
    'parentids' => '620000,620500,620521',
    'level' => '3',
    'name' => '清水县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3230 => 
  array (
    'id' => '620522',
    'parentid' => '620500',
    'parentids' => '620000,620500,620522',
    'level' => '3',
    'name' => '秦安县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3231 => 
  array (
    'id' => '620523',
    'parentid' => '620500',
    'parentids' => '620000,620500,620523',
    'level' => '3',
    'name' => '甘谷县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3232 => 
  array (
    'id' => '620524',
    'parentid' => '620500',
    'parentids' => '620000,620500,620524',
    'level' => '3',
    'name' => '武山县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3233 => 
  array (
    'id' => '620525',
    'parentid' => '620500',
    'parentids' => '620000,620500,620525',
    'level' => '3',
    'name' => '张家川回族自治县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3234 => 
  array (
    'id' => '620600',
    'parentid' => '620000',
    'parentids' => '620000,620600',
    'level' => '2',
    'name' => '武威市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3235 => 
  array (
    'id' => '620601',
    'parentid' => '620600',
    'parentids' => '620000,620600,620601',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3236 => 
  array (
    'id' => '620602',
    'parentid' => '620600',
    'parentids' => '620000,620600,620602',
    'level' => '3',
    'name' => '凉州区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3237 => 
  array (
    'id' => '620621',
    'parentid' => '620600',
    'parentids' => '620000,620600,620621',
    'level' => '3',
    'name' => '民勤县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3238 => 
  array (
    'id' => '620622',
    'parentid' => '620600',
    'parentids' => '620000,620600,620622',
    'level' => '3',
    'name' => '古浪县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3239 => 
  array (
    'id' => '620623',
    'parentid' => '620600',
    'parentids' => '620000,620600,620623',
    'level' => '3',
    'name' => '天祝藏族自治县',
    'letter' => 't',
    'listorder' => '0',
  ),
  3240 => 
  array (
    'id' => '620700',
    'parentid' => '620000',
    'parentids' => '620000,620700',
    'level' => '2',
    'name' => '张掖市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3241 => 
  array (
    'id' => '620701',
    'parentid' => '620700',
    'parentids' => '620000,620700,620701',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3242 => 
  array (
    'id' => '620702',
    'parentid' => '620700',
    'parentids' => '620000,620700,620702',
    'level' => '3',
    'name' => '甘州区',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3243 => 
  array (
    'id' => '620721',
    'parentid' => '620700',
    'parentids' => '620000,620700,620721',
    'level' => '3',
    'name' => '肃南裕固族自治县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3244 => 
  array (
    'id' => '620722',
    'parentid' => '620700',
    'parentids' => '620000,620700,620722',
    'level' => '3',
    'name' => '民乐县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3245 => 
  array (
    'id' => '620723',
    'parentid' => '620700',
    'parentids' => '620000,620700,620723',
    'level' => '3',
    'name' => '临泽县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3246 => 
  array (
    'id' => '620724',
    'parentid' => '620700',
    'parentids' => '620000,620700,620724',
    'level' => '3',
    'name' => '高台县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3247 => 
  array (
    'id' => '620725',
    'parentid' => '620700',
    'parentids' => '620000,620700,620725',
    'level' => '3',
    'name' => '山丹县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3248 => 
  array (
    'id' => '620800',
    'parentid' => '620000',
    'parentids' => '620000,620800',
    'level' => '2',
    'name' => '平凉市',
    'letter' => 'p',
    'listorder' => '0',
  ),
  3249 => 
  array (
    'id' => '620801',
    'parentid' => '620800',
    'parentids' => '620000,620800,620801',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3250 => 
  array (
    'id' => '620802',
    'parentid' => '620800',
    'parentids' => '620000,620800,620802',
    'level' => '3',
    'name' => '崆峒区',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3251 => 
  array (
    'id' => '620821',
    'parentid' => '620800',
    'parentids' => '620000,620800,620821',
    'level' => '3',
    'name' => '泾川县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3252 => 
  array (
    'id' => '620822',
    'parentid' => '620800',
    'parentids' => '620000,620800,620822',
    'level' => '3',
    'name' => '灵台县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3253 => 
  array (
    'id' => '620823',
    'parentid' => '620800',
    'parentids' => '620000,620800,620823',
    'level' => '3',
    'name' => '崇信县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3254 => 
  array (
    'id' => '620824',
    'parentid' => '620800',
    'parentids' => '620000,620800,620824',
    'level' => '3',
    'name' => '华亭县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3255 => 
  array (
    'id' => '620825',
    'parentid' => '620800',
    'parentids' => '620000,620800,620825',
    'level' => '3',
    'name' => '庄浪县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3256 => 
  array (
    'id' => '620826',
    'parentid' => '620800',
    'parentids' => '620000,620800,620826',
    'level' => '3',
    'name' => '静宁县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3257 => 
  array (
    'id' => '620900',
    'parentid' => '620000',
    'parentids' => '620000,620900',
    'level' => '2',
    'name' => '酒泉市',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3258 => 
  array (
    'id' => '620901',
    'parentid' => '620900',
    'parentids' => '620000,620900,620901',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3259 => 
  array (
    'id' => '620902',
    'parentid' => '620900',
    'parentids' => '620000,620900,620902',
    'level' => '3',
    'name' => '肃州区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3260 => 
  array (
    'id' => '620921',
    'parentid' => '620900',
    'parentids' => '620000,620900,620921',
    'level' => '3',
    'name' => '金塔县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3261 => 
  array (
    'id' => '620922',
    'parentid' => '620900',
    'parentids' => '620000,620900,620922',
    'level' => '3',
    'name' => '安西县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  3262 => 
  array (
    'id' => '620923',
    'parentid' => '620900',
    'parentids' => '620000,620900,620923',
    'level' => '3',
    'name' => '肃北蒙古族自治县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3263 => 
  array (
    'id' => '620924',
    'parentid' => '620900',
    'parentids' => '620000,620900,620924',
    'level' => '3',
    'name' => '阿克塞哈萨克族自治县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  3264 => 
  array (
    'id' => '620981',
    'parentid' => '620900',
    'parentids' => '620000,620900,620981',
    'level' => '3',
    'name' => '玉门市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3265 => 
  array (
    'id' => '620982',
    'parentid' => '620900',
    'parentids' => '620000,620900,620982',
    'level' => '3',
    'name' => '敦煌市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3266 => 
  array (
    'id' => '621000',
    'parentid' => '620000',
    'parentids' => '620000,621000',
    'level' => '2',
    'name' => '庆阳市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3267 => 
  array (
    'id' => '621001',
    'parentid' => '621000',
    'parentids' => '620000,621000,621001',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3268 => 
  array (
    'id' => '621002',
    'parentid' => '621000',
    'parentids' => '620000,621000,621002',
    'level' => '3',
    'name' => '西峰区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3269 => 
  array (
    'id' => '621021',
    'parentid' => '621000',
    'parentids' => '620000,621000,621021',
    'level' => '3',
    'name' => '庆城县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3270 => 
  array (
    'id' => '621022',
    'parentid' => '621000',
    'parentids' => '620000,621000,621022',
    'level' => '3',
    'name' => '环　县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3271 => 
  array (
    'id' => '621023',
    'parentid' => '621000',
    'parentids' => '620000,621000,621023',
    'level' => '3',
    'name' => '华池县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3272 => 
  array (
    'id' => '621024',
    'parentid' => '621000',
    'parentids' => '620000,621000,621024',
    'level' => '3',
    'name' => '合水县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3273 => 
  array (
    'id' => '621025',
    'parentid' => '621000',
    'parentids' => '620000,621000,621025',
    'level' => '3',
    'name' => '正宁县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3274 => 
  array (
    'id' => '621026',
    'parentid' => '621000',
    'parentids' => '620000,621000,621026',
    'level' => '3',
    'name' => '宁　县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  3275 => 
  array (
    'id' => '621027',
    'parentid' => '621000',
    'parentids' => '620000,621000,621027',
    'level' => '3',
    'name' => '镇原县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3276 => 
  array (
    'id' => '621100',
    'parentid' => '620000',
    'parentids' => '620000,621100',
    'level' => '2',
    'name' => '定西市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3277 => 
  array (
    'id' => '621101',
    'parentid' => '621100',
    'parentids' => '620000,621100,621101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3278 => 
  array (
    'id' => '621102',
    'parentid' => '621100',
    'parentids' => '620000,621100,621102',
    'level' => '3',
    'name' => '安定区',
    'letter' => 'a',
    'listorder' => '0',
  ),
  3279 => 
  array (
    'id' => '621121',
    'parentid' => '621100',
    'parentids' => '620000,621100,621121',
    'level' => '3',
    'name' => '通渭县',
    'letter' => 't',
    'listorder' => '0',
  ),
  3280 => 
  array (
    'id' => '621122',
    'parentid' => '621100',
    'parentids' => '620000,621100,621122',
    'level' => '3',
    'name' => '陇西县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3281 => 
  array (
    'id' => '621123',
    'parentid' => '621100',
    'parentids' => '620000,621100,621123',
    'level' => '3',
    'name' => '渭源县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3282 => 
  array (
    'id' => '621124',
    'parentid' => '621100',
    'parentids' => '620000,621100,621124',
    'level' => '3',
    'name' => '临洮县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3283 => 
  array (
    'id' => '621125',
    'parentid' => '621100',
    'parentids' => '620000,621100,621125',
    'level' => '3',
    'name' => '漳　县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3284 => 
  array (
    'id' => '621126',
    'parentid' => '621100',
    'parentids' => '620000,621100,621126',
    'level' => '3',
    'name' => '岷　县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3285 => 
  array (
    'id' => '621200',
    'parentid' => '620000',
    'parentids' => '620000,621200',
    'level' => '2',
    'name' => '陇南市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3286 => 
  array (
    'id' => '621201',
    'parentid' => '621200',
    'parentids' => '620000,621200,621201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3287 => 
  array (
    'id' => '621202',
    'parentid' => '621200',
    'parentids' => '620000,621200,621202',
    'level' => '3',
    'name' => '武都区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3288 => 
  array (
    'id' => '621221',
    'parentid' => '621200',
    'parentids' => '620000,621200,621221',
    'level' => '3',
    'name' => '成　县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3289 => 
  array (
    'id' => '621222',
    'parentid' => '621200',
    'parentids' => '620000,621200,621222',
    'level' => '3',
    'name' => '文　县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3290 => 
  array (
    'id' => '621223',
    'parentid' => '621200',
    'parentids' => '620000,621200,621223',
    'level' => '3',
    'name' => '宕昌县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3291 => 
  array (
    'id' => '621224',
    'parentid' => '621200',
    'parentids' => '620000,621200,621224',
    'level' => '3',
    'name' => '康　县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  3292 => 
  array (
    'id' => '621225',
    'parentid' => '621200',
    'parentids' => '620000,621200,621225',
    'level' => '3',
    'name' => '西和县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3293 => 
  array (
    'id' => '621226',
    'parentid' => '621200',
    'parentids' => '620000,621200,621226',
    'level' => '3',
    'name' => '礼　县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3294 => 
  array (
    'id' => '621227',
    'parentid' => '621200',
    'parentids' => '620000,621200,621227',
    'level' => '3',
    'name' => '徽　县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3295 => 
  array (
    'id' => '621228',
    'parentid' => '621200',
    'parentids' => '620000,621200,621228',
    'level' => '3',
    'name' => '两当县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3296 => 
  array (
    'id' => '622900',
    'parentid' => '620000',
    'parentids' => '620000,622900',
    'level' => '2',
    'name' => '临夏回族自治州',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3297 => 
  array (
    'id' => '622901',
    'parentid' => '622900',
    'parentids' => '620000,622900,622901',
    'level' => '3',
    'name' => '临夏市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3298 => 
  array (
    'id' => '622921',
    'parentid' => '622900',
    'parentids' => '620000,622900,622921',
    'level' => '3',
    'name' => '临夏县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3299 => 
  array (
    'id' => '622922',
    'parentid' => '622900',
    'parentids' => '620000,622900,622922',
    'level' => '3',
    'name' => '康乐县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  3300 => 
  array (
    'id' => '622923',
    'parentid' => '622900',
    'parentids' => '620000,622900,622923',
    'level' => '3',
    'name' => '永靖县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3301 => 
  array (
    'id' => '622924',
    'parentid' => '622900',
    'parentids' => '620000,622900,622924',
    'level' => '3',
    'name' => '广河县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3302 => 
  array (
    'id' => '622925',
    'parentid' => '622900',
    'parentids' => '620000,622900,622925',
    'level' => '3',
    'name' => '和政县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3303 => 
  array (
    'id' => '622926',
    'parentid' => '622900',
    'parentids' => '620000,622900,622926',
    'level' => '3',
    'name' => '东乡族自治县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3304 => 
  array (
    'id' => '622927',
    'parentid' => '622900',
    'parentids' => '620000,622900,622927',
    'level' => '3',
    'name' => '积石山保安族东乡族撒拉族自治县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3305 => 
  array (
    'id' => '623000',
    'parentid' => '620000',
    'parentids' => '620000,623000',
    'level' => '2',
    'name' => '甘南藏族自治州',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3306 => 
  array (
    'id' => '623001',
    'parentid' => '623000',
    'parentids' => '620000,623000,623001',
    'level' => '3',
    'name' => '合作市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3307 => 
  array (
    'id' => '623021',
    'parentid' => '623000',
    'parentids' => '620000,623000,623021',
    'level' => '3',
    'name' => '临潭县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3308 => 
  array (
    'id' => '623022',
    'parentid' => '623000',
    'parentids' => '620000,623000,623022',
    'level' => '3',
    'name' => '卓尼县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3309 => 
  array (
    'id' => '623023',
    'parentid' => '623000',
    'parentids' => '620000,623000,623023',
    'level' => '3',
    'name' => '舟曲县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3310 => 
  array (
    'id' => '623024',
    'parentid' => '623000',
    'parentids' => '620000,623000,623024',
    'level' => '3',
    'name' => '迭部县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3311 => 
  array (
    'id' => '623025',
    'parentid' => '623000',
    'parentids' => '620000,623000,623025',
    'level' => '3',
    'name' => '玛曲县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3312 => 
  array (
    'id' => '623026',
    'parentid' => '623000',
    'parentids' => '620000,623000,623026',
    'level' => '3',
    'name' => '碌曲县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3313 => 
  array (
    'id' => '623027',
    'parentid' => '623000',
    'parentids' => '620000,623000,623027',
    'level' => '3',
    'name' => '夏河县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3314 => 
  array (
    'id' => '630000',
    'parentid' => '0',
    'parentids' => '630000',
    'level' => '1',
    'name' => '青海省',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3315 => 
  array (
    'id' => '630100',
    'parentid' => '630000',
    'parentids' => '630000,630100',
    'level' => '2',
    'name' => '西宁市',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3316 => 
  array (
    'id' => '630101',
    'parentid' => '630100',
    'parentids' => '630000,630100,630101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3317 => 
  array (
    'id' => '630102',
    'parentid' => '630100',
    'parentids' => '630000,630100,630102',
    'level' => '3',
    'name' => '城东区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3318 => 
  array (
    'id' => '630103',
    'parentid' => '630100',
    'parentids' => '630000,630100,630103',
    'level' => '3',
    'name' => '城中区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3319 => 
  array (
    'id' => '630104',
    'parentid' => '630100',
    'parentids' => '630000,630100,630104',
    'level' => '3',
    'name' => '城西区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3320 => 
  array (
    'id' => '630105',
    'parentid' => '630100',
    'parentids' => '630000,630100,630105',
    'level' => '3',
    'name' => '城北区',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3321 => 
  array (
    'id' => '630121',
    'parentid' => '630100',
    'parentids' => '630000,630100,630121',
    'level' => '3',
    'name' => '大通回族土族自治县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3322 => 
  array (
    'id' => '630122',
    'parentid' => '630100',
    'parentids' => '630000,630100,630122',
    'level' => '3',
    'name' => '湟中县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3323 => 
  array (
    'id' => '630123',
    'parentid' => '630100',
    'parentids' => '630000,630100,630123',
    'level' => '3',
    'name' => '湟源县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3324 => 
  array (
    'id' => '632100',
    'parentid' => '630000',
    'parentids' => '630000,632100',
    'level' => '2',
    'name' => '海东地区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3325 => 
  array (
    'id' => '632121',
    'parentid' => '632100',
    'parentids' => '630000,632100,632121',
    'level' => '3',
    'name' => '平安县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  3326 => 
  array (
    'id' => '632122',
    'parentid' => '632100',
    'parentids' => '630000,632100,632122',
    'level' => '3',
    'name' => '民和回族土族自治县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3327 => 
  array (
    'id' => '632123',
    'parentid' => '632100',
    'parentids' => '630000,632100,632123',
    'level' => '3',
    'name' => '乐都县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3328 => 
  array (
    'id' => '632126',
    'parentid' => '632100',
    'parentids' => '630000,632100,632126',
    'level' => '3',
    'name' => '互助土族自治县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3329 => 
  array (
    'id' => '632127',
    'parentid' => '632100',
    'parentids' => '630000,632100,632127',
    'level' => '3',
    'name' => '化隆回族自治县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3330 => 
  array (
    'id' => '632128',
    'parentid' => '632100',
    'parentids' => '630000,632100,632128',
    'level' => '3',
    'name' => '循化撒拉族自治县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3331 => 
  array (
    'id' => '632200',
    'parentid' => '630000',
    'parentids' => '630000,632200',
    'level' => '2',
    'name' => '海北藏族自治州',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3332 => 
  array (
    'id' => '632221',
    'parentid' => '632200',
    'parentids' => '630000,632200,632221',
    'level' => '3',
    'name' => '门源回族自治县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3333 => 
  array (
    'id' => '632222',
    'parentid' => '632200',
    'parentids' => '630000,632200,632222',
    'level' => '3',
    'name' => '祁连县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3334 => 
  array (
    'id' => '632223',
    'parentid' => '632200',
    'parentids' => '630000,632200,632223',
    'level' => '3',
    'name' => '海晏县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3335 => 
  array (
    'id' => '632224',
    'parentid' => '632200',
    'parentids' => '630000,632200,632224',
    'level' => '3',
    'name' => '刚察县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3336 => 
  array (
    'id' => '632300',
    'parentid' => '630000',
    'parentids' => '630000,632300',
    'level' => '2',
    'name' => '黄南藏族自治州',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3337 => 
  array (
    'id' => '632321',
    'parentid' => '632300',
    'parentids' => '630000,632300,632321',
    'level' => '3',
    'name' => '同仁县',
    'letter' => 't',
    'listorder' => '0',
  ),
  3338 => 
  array (
    'id' => '632322',
    'parentid' => '632300',
    'parentids' => '630000,632300,632322',
    'level' => '3',
    'name' => '尖扎县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3339 => 
  array (
    'id' => '632323',
    'parentid' => '632300',
    'parentids' => '630000,632300,632323',
    'level' => '3',
    'name' => '泽库县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3340 => 
  array (
    'id' => '632324',
    'parentid' => '632300',
    'parentids' => '630000,632300,632324',
    'level' => '3',
    'name' => '河南蒙古族自治县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3341 => 
  array (
    'id' => '632500',
    'parentid' => '630000',
    'parentids' => '630000,632500',
    'level' => '2',
    'name' => '海南藏族自治州',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3342 => 
  array (
    'id' => '632521',
    'parentid' => '632500',
    'parentids' => '630000,632500,632521',
    'level' => '3',
    'name' => '共和县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3343 => 
  array (
    'id' => '632522',
    'parentid' => '632500',
    'parentids' => '630000,632500,632522',
    'level' => '3',
    'name' => '同德县',
    'letter' => 't',
    'listorder' => '0',
  ),
  3344 => 
  array (
    'id' => '632523',
    'parentid' => '632500',
    'parentids' => '630000,632500,632523',
    'level' => '3',
    'name' => '贵德县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3345 => 
  array (
    'id' => '632524',
    'parentid' => '632500',
    'parentids' => '630000,632500,632524',
    'level' => '3',
    'name' => '兴海县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3346 => 
  array (
    'id' => '632525',
    'parentid' => '632500',
    'parentids' => '630000,632500,632525',
    'level' => '3',
    'name' => '贵南县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3347 => 
  array (
    'id' => '632600',
    'parentid' => '630000',
    'parentids' => '630000,632600',
    'level' => '2',
    'name' => '果洛藏族自治州',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3348 => 
  array (
    'id' => '632621',
    'parentid' => '632600',
    'parentids' => '630000,632600,632621',
    'level' => '3',
    'name' => '玛沁县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3349 => 
  array (
    'id' => '632622',
    'parentid' => '632600',
    'parentids' => '630000,632600,632622',
    'level' => '3',
    'name' => '班玛县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3350 => 
  array (
    'id' => '632623',
    'parentid' => '632600',
    'parentids' => '630000,632600,632623',
    'level' => '3',
    'name' => '甘德县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3351 => 
  array (
    'id' => '632624',
    'parentid' => '632600',
    'parentids' => '630000,632600,632624',
    'level' => '3',
    'name' => '达日县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3352 => 
  array (
    'id' => '632625',
    'parentid' => '632600',
    'parentids' => '630000,632600,632625',
    'level' => '3',
    'name' => '久治县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3353 => 
  array (
    'id' => '632626',
    'parentid' => '632600',
    'parentids' => '630000,632600,632626',
    'level' => '3',
    'name' => '玛多县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3354 => 
  array (
    'id' => '632700',
    'parentid' => '630000',
    'parentids' => '630000,632700',
    'level' => '2',
    'name' => '玉树藏族自治州',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3355 => 
  array (
    'id' => '632721',
    'parentid' => '632700',
    'parentids' => '630000,632700,632721',
    'level' => '3',
    'name' => '玉树县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3356 => 
  array (
    'id' => '632722',
    'parentid' => '632700',
    'parentids' => '630000,632700,632722',
    'level' => '3',
    'name' => '杂多县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3357 => 
  array (
    'id' => '632723',
    'parentid' => '632700',
    'parentids' => '630000,632700,632723',
    'level' => '3',
    'name' => '称多县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3358 => 
  array (
    'id' => '632724',
    'parentid' => '632700',
    'parentids' => '630000,632700,632724',
    'level' => '3',
    'name' => '治多县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3359 => 
  array (
    'id' => '632725',
    'parentid' => '632700',
    'parentids' => '630000,632700,632725',
    'level' => '3',
    'name' => '囊谦县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  3360 => 
  array (
    'id' => '632726',
    'parentid' => '632700',
    'parentids' => '630000,632700,632726',
    'level' => '3',
    'name' => '曲麻莱县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3361 => 
  array (
    'id' => '632800',
    'parentid' => '630000',
    'parentids' => '630000,632800',
    'level' => '2',
    'name' => '海西蒙古族藏族自治州',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3362 => 
  array (
    'id' => '632801',
    'parentid' => '632800',
    'parentids' => '630000,632800,632801',
    'level' => '3',
    'name' => '格尔木市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3363 => 
  array (
    'id' => '632802',
    'parentid' => '632800',
    'parentids' => '630000,632800,632802',
    'level' => '3',
    'name' => '德令哈市',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3364 => 
  array (
    'id' => '632821',
    'parentid' => '632800',
    'parentids' => '630000,632800,632821',
    'level' => '3',
    'name' => '乌兰县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3365 => 
  array (
    'id' => '632822',
    'parentid' => '632800',
    'parentids' => '630000,632800,632822',
    'level' => '3',
    'name' => '都兰县',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3366 => 
  array (
    'id' => '632823',
    'parentid' => '632800',
    'parentids' => '630000,632800,632823',
    'level' => '3',
    'name' => '天峻县',
    'letter' => 't',
    'listorder' => '0',
  ),
  3367 => 
  array (
    'id' => '640000',
    'parentid' => '0',
    'parentids' => '640000',
    'level' => '1',
    'name' => '宁夏回族自治区',
    'letter' => 'n',
    'listorder' => '0',
  ),
  3368 => 
  array (
    'id' => '640100',
    'parentid' => '640000',
    'parentids' => '640000,640100',
    'level' => '2',
    'name' => '银川市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3369 => 
  array (
    'id' => '640101',
    'parentid' => '640100',
    'parentids' => '640000,640100,640101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3370 => 
  array (
    'id' => '640104',
    'parentid' => '640100',
    'parentids' => '640000,640100,640104',
    'level' => '3',
    'name' => '兴庆区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3371 => 
  array (
    'id' => '640105',
    'parentid' => '640100',
    'parentids' => '640000,640100,640105',
    'level' => '3',
    'name' => '西夏区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3372 => 
  array (
    'id' => '640106',
    'parentid' => '640100',
    'parentids' => '640000,640100,640106',
    'level' => '3',
    'name' => '金凤区',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3373 => 
  array (
    'id' => '640121',
    'parentid' => '640100',
    'parentids' => '640000,640100,640121',
    'level' => '3',
    'name' => '永宁县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3374 => 
  array (
    'id' => '640122',
    'parentid' => '640100',
    'parentids' => '640000,640100,640122',
    'level' => '3',
    'name' => '贺兰县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3375 => 
  array (
    'id' => '640181',
    'parentid' => '640100',
    'parentids' => '640000,640100,640181',
    'level' => '3',
    'name' => '灵武市',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3376 => 
  array (
    'id' => '640200',
    'parentid' => '640000',
    'parentids' => '640000,640200',
    'level' => '2',
    'name' => '石嘴山市',
    'letter' => 's',
    'listorder' => '0',
  ),
  3377 => 
  array (
    'id' => '640201',
    'parentid' => '640200',
    'parentids' => '640000,640200,640201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3378 => 
  array (
    'id' => '640202',
    'parentid' => '640200',
    'parentids' => '640000,640200,640202',
    'level' => '3',
    'name' => '大武口区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3379 => 
  array (
    'id' => '640205',
    'parentid' => '640200',
    'parentids' => '640000,640200,640205',
    'level' => '3',
    'name' => '惠农区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3380 => 
  array (
    'id' => '640221',
    'parentid' => '640200',
    'parentids' => '640000,640200,640221',
    'level' => '3',
    'name' => '平罗县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  3381 => 
  array (
    'id' => '640300',
    'parentid' => '640000',
    'parentids' => '640000,640300',
    'level' => '2',
    'name' => '吴忠市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3382 => 
  array (
    'id' => '640301',
    'parentid' => '640300',
    'parentids' => '640000,640300,640301',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3383 => 
  array (
    'id' => '640302',
    'parentid' => '640300',
    'parentids' => '640000,640300,640302',
    'level' => '3',
    'name' => '利通区',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3384 => 
  array (
    'id' => '640323',
    'parentid' => '640300',
    'parentids' => '640000,640300,640323',
    'level' => '3',
    'name' => '盐池县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3385 => 
  array (
    'id' => '640324',
    'parentid' => '640300',
    'parentids' => '640000,640300,640324',
    'level' => '3',
    'name' => '同心县',
    'letter' => 't',
    'listorder' => '0',
  ),
  3386 => 
  array (
    'id' => '640381',
    'parentid' => '640300',
    'parentids' => '640000,640300,640381',
    'level' => '3',
    'name' => '青铜峡市',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3387 => 
  array (
    'id' => '640400',
    'parentid' => '640000',
    'parentids' => '640000,640400',
    'level' => '2',
    'name' => '固原市',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3388 => 
  array (
    'id' => '640401',
    'parentid' => '640400',
    'parentids' => '640000,640400,640401',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3389 => 
  array (
    'id' => '640402',
    'parentid' => '640400',
    'parentids' => '640000,640400,640402',
    'level' => '3',
    'name' => '原州区',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3390 => 
  array (
    'id' => '640422',
    'parentid' => '640400',
    'parentids' => '640000,640400,640422',
    'level' => '3',
    'name' => '西吉县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3391 => 
  array (
    'id' => '640423',
    'parentid' => '640400',
    'parentids' => '640000,640400,640423',
    'level' => '3',
    'name' => '隆德县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3392 => 
  array (
    'id' => '640424',
    'parentid' => '640400',
    'parentids' => '640000,640400,640424',
    'level' => '3',
    'name' => '泾源县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3393 => 
  array (
    'id' => '640425',
    'parentid' => '640400',
    'parentids' => '640000,640400,640425',
    'level' => '3',
    'name' => '彭阳县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  3394 => 
  array (
    'id' => '640500',
    'parentid' => '640000',
    'parentids' => '640000,640500',
    'level' => '2',
    'name' => '中卫市',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3395 => 
  array (
    'id' => '640501',
    'parentid' => '640500',
    'parentids' => '640000,640500,640501',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3396 => 
  array (
    'id' => '640502',
    'parentid' => '640500',
    'parentids' => '640000,640500,640502',
    'level' => '3',
    'name' => '沙坡头区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3397 => 
  array (
    'id' => '640521',
    'parentid' => '640500',
    'parentids' => '640000,640500,640521',
    'level' => '3',
    'name' => '中宁县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3398 => 
  array (
    'id' => '640522',
    'parentid' => '640500',
    'parentids' => '640000,640500,640522',
    'level' => '3',
    'name' => '海原县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3399 => 
  array (
    'id' => '650000',
    'parentid' => '0',
    'parentids' => '650000',
    'level' => '1',
    'name' => '新疆维吾尔自治区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3400 => 
  array (
    'id' => '650100',
    'parentid' => '650000',
    'parentids' => '650000,650100',
    'level' => '2',
    'name' => '乌鲁木齐市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3401 => 
  array (
    'id' => '650101',
    'parentid' => '650100',
    'parentids' => '650000,650100,650101',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3402 => 
  array (
    'id' => '650102',
    'parentid' => '650100',
    'parentids' => '650000,650100,650102',
    'level' => '3',
    'name' => '天山区',
    'letter' => 't',
    'listorder' => '0',
  ),
  3403 => 
  array (
    'id' => '650103',
    'parentid' => '650100',
    'parentids' => '650000,650100,650103',
    'level' => '3',
    'name' => '沙依巴克区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3404 => 
  array (
    'id' => '650104',
    'parentid' => '650100',
    'parentids' => '650000,650100,650104',
    'level' => '3',
    'name' => '新市区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3405 => 
  array (
    'id' => '650105',
    'parentid' => '650100',
    'parentids' => '650000,650100,650105',
    'level' => '3',
    'name' => '水磨沟区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3406 => 
  array (
    'id' => '650106',
    'parentid' => '650100',
    'parentids' => '650000,650100,650106',
    'level' => '3',
    'name' => '头屯河区',
    'letter' => 't',
    'listorder' => '0',
  ),
  3407 => 
  array (
    'id' => '650107',
    'parentid' => '650100',
    'parentids' => '650000,650100,650107',
    'level' => '3',
    'name' => '达坂城区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3408 => 
  array (
    'id' => '650108',
    'parentid' => '650100',
    'parentids' => '650000,650100,650108',
    'level' => '3',
    'name' => '东山区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3409 => 
  array (
    'id' => '650121',
    'parentid' => '650100',
    'parentids' => '650000,650100,650121',
    'level' => '3',
    'name' => '乌鲁木齐县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3410 => 
  array (
    'id' => '650200',
    'parentid' => '650000',
    'parentids' => '650000,650200',
    'level' => '2',
    'name' => '克拉玛依市',
    'letter' => 'k',
    'listorder' => '0',
  ),
  3411 => 
  array (
    'id' => '650201',
    'parentid' => '650200',
    'parentids' => '650000,650200,650201',
    'level' => '3',
    'name' => '市辖区',
    'letter' => 's',
    'listorder' => '0',
  ),
  3412 => 
  array (
    'id' => '650202',
    'parentid' => '650200',
    'parentids' => '650000,650200,650202',
    'level' => '3',
    'name' => '独山子区',
    'letter' => 'd',
    'listorder' => '0',
  ),
  3413 => 
  array (
    'id' => '650203',
    'parentid' => '650200',
    'parentids' => '650000,650200,650203',
    'level' => '3',
    'name' => '克拉玛依区',
    'letter' => 'k',
    'listorder' => '0',
  ),
  3414 => 
  array (
    'id' => '650204',
    'parentid' => '650200',
    'parentids' => '650000,650200,650204',
    'level' => '3',
    'name' => '白碱滩区',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3415 => 
  array (
    'id' => '650205',
    'parentid' => '650200',
    'parentids' => '650000,650200,650205',
    'level' => '3',
    'name' => '乌尔禾区',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3416 => 
  array (
    'id' => '652100',
    'parentid' => '650000',
    'parentids' => '650000,652100',
    'level' => '2',
    'name' => '吐鲁番地区',
    'letter' => 't',
    'listorder' => '0',
  ),
  3417 => 
  array (
    'id' => '652101',
    'parentid' => '652100',
    'parentids' => '650000,652100,652101',
    'level' => '3',
    'name' => '吐鲁番市',
    'letter' => 't',
    'listorder' => '0',
  ),
  3418 => 
  array (
    'id' => '652122',
    'parentid' => '652100',
    'parentids' => '650000,652100,652122',
    'level' => '3',
    'name' => '鄯善县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3419 => 
  array (
    'id' => '652123',
    'parentid' => '652100',
    'parentids' => '650000,652100,652123',
    'level' => '3',
    'name' => '托克逊县',
    'letter' => 't',
    'listorder' => '0',
  ),
  3420 => 
  array (
    'id' => '652200',
    'parentid' => '650000',
    'parentids' => '650000,652200',
    'level' => '2',
    'name' => '哈密地区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3421 => 
  array (
    'id' => '652201',
    'parentid' => '652200',
    'parentids' => '650000,652200,652201',
    'level' => '3',
    'name' => '哈密市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3422 => 
  array (
    'id' => '652222',
    'parentid' => '652200',
    'parentids' => '650000,652200,652222',
    'level' => '3',
    'name' => '巴里坤哈萨克自治县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3423 => 
  array (
    'id' => '652223',
    'parentid' => '652200',
    'parentids' => '650000,652200,652223',
    'level' => '3',
    'name' => '伊吾县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3424 => 
  array (
    'id' => '652300',
    'parentid' => '650000',
    'parentids' => '650000,652300',
    'level' => '2',
    'name' => '昌吉回族自治州',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3425 => 
  array (
    'id' => '652301',
    'parentid' => '652300',
    'parentids' => '650000,652300,652301',
    'level' => '3',
    'name' => '昌吉市',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3426 => 
  array (
    'id' => '652302',
    'parentid' => '652300',
    'parentids' => '650000,652300,652302',
    'level' => '3',
    'name' => '阜康市',
    'letter' => 'f',
    'listorder' => '0',
  ),
  3427 => 
  array (
    'id' => '652303',
    'parentid' => '652300',
    'parentids' => '650000,652300,652303',
    'level' => '3',
    'name' => '米泉市',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3428 => 
  array (
    'id' => '652323',
    'parentid' => '652300',
    'parentids' => '650000,652300,652323',
    'level' => '3',
    'name' => '呼图壁县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3429 => 
  array (
    'id' => '652324',
    'parentid' => '652300',
    'parentids' => '650000,652300,652324',
    'level' => '3',
    'name' => '玛纳斯县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3430 => 
  array (
    'id' => '652325',
    'parentid' => '652300',
    'parentids' => '650000,652300,652325',
    'level' => '3',
    'name' => '奇台县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3431 => 
  array (
    'id' => '652327',
    'parentid' => '652300',
    'parentids' => '650000,652300,652327',
    'level' => '3',
    'name' => '吉木萨尔县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3432 => 
  array (
    'id' => '652328',
    'parentid' => '652300',
    'parentids' => '650000,652300,652328',
    'level' => '3',
    'name' => '木垒哈萨克自治县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3433 => 
  array (
    'id' => '652700',
    'parentid' => '650000',
    'parentids' => '650000,652700',
    'level' => '2',
    'name' => '博尔塔拉蒙古自治州',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3434 => 
  array (
    'id' => '652701',
    'parentid' => '652700',
    'parentids' => '650000,652700,652701',
    'level' => '3',
    'name' => '博乐市',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3435 => 
  array (
    'id' => '652722',
    'parentid' => '652700',
    'parentids' => '650000,652700,652722',
    'level' => '3',
    'name' => '精河县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3436 => 
  array (
    'id' => '652723',
    'parentid' => '652700',
    'parentids' => '650000,652700,652723',
    'level' => '3',
    'name' => '温泉县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3437 => 
  array (
    'id' => '652800',
    'parentid' => '650000',
    'parentids' => '650000,652800',
    'level' => '2',
    'name' => '巴音郭楞蒙古自治州',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3438 => 
  array (
    'id' => '652801',
    'parentid' => '652800',
    'parentids' => '650000,652800,652801',
    'level' => '3',
    'name' => '库尔勒市',
    'letter' => 'k',
    'listorder' => '0',
  ),
  3439 => 
  array (
    'id' => '652822',
    'parentid' => '652800',
    'parentids' => '650000,652800,652822',
    'level' => '3',
    'name' => '轮台县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3440 => 
  array (
    'id' => '652823',
    'parentid' => '652800',
    'parentids' => '650000,652800,652823',
    'level' => '3',
    'name' => '尉犁县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3441 => 
  array (
    'id' => '652824',
    'parentid' => '652800',
    'parentids' => '650000,652800,652824',
    'level' => '3',
    'name' => '若羌县',
    'letter' => 'r',
    'listorder' => '0',
  ),
  3442 => 
  array (
    'id' => '652825',
    'parentid' => '652800',
    'parentids' => '650000,652800,652825',
    'level' => '3',
    'name' => '且末县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3443 => 
  array (
    'id' => '652826',
    'parentid' => '652800',
    'parentids' => '650000,652800,652826',
    'level' => '3',
    'name' => '焉耆回族自治县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3444 => 
  array (
    'id' => '652827',
    'parentid' => '652800',
    'parentids' => '650000,652800,652827',
    'level' => '3',
    'name' => '和静县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3445 => 
  array (
    'id' => '652828',
    'parentid' => '652800',
    'parentids' => '650000,652800,652828',
    'level' => '3',
    'name' => '和硕县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3446 => 
  array (
    'id' => '652829',
    'parentid' => '652800',
    'parentids' => '650000,652800,652829',
    'level' => '3',
    'name' => '博湖县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3447 => 
  array (
    'id' => '652900',
    'parentid' => '650000',
    'parentids' => '650000,652900',
    'level' => '2',
    'name' => '阿克苏地区',
    'letter' => 'a',
    'listorder' => '0',
  ),
  3448 => 
  array (
    'id' => '652901',
    'parentid' => '652900',
    'parentids' => '650000,652900,652901',
    'level' => '3',
    'name' => '阿克苏市',
    'letter' => 'a',
    'listorder' => '0',
  ),
  3449 => 
  array (
    'id' => '652922',
    'parentid' => '652900',
    'parentids' => '650000,652900,652922',
    'level' => '3',
    'name' => '温宿县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3450 => 
  array (
    'id' => '652923',
    'parentid' => '652900',
    'parentids' => '650000,652900,652923',
    'level' => '3',
    'name' => '库车县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  3451 => 
  array (
    'id' => '652924',
    'parentid' => '652900',
    'parentids' => '650000,652900,652924',
    'level' => '3',
    'name' => '沙雅县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3452 => 
  array (
    'id' => '652925',
    'parentid' => '652900',
    'parentids' => '650000,652900,652925',
    'level' => '3',
    'name' => '新和县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3453 => 
  array (
    'id' => '652926',
    'parentid' => '652900',
    'parentids' => '650000,652900,652926',
    'level' => '3',
    'name' => '拜城县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3454 => 
  array (
    'id' => '652927',
    'parentid' => '652900',
    'parentids' => '650000,652900,652927',
    'level' => '3',
    'name' => '乌什县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3455 => 
  array (
    'id' => '652928',
    'parentid' => '652900',
    'parentids' => '650000,652900,652928',
    'level' => '3',
    'name' => '阿瓦提县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  3456 => 
  array (
    'id' => '652929',
    'parentid' => '652900',
    'parentids' => '650000,652900,652929',
    'level' => '3',
    'name' => '柯坪县',
    'letter' => 'k',
    'listorder' => '0',
  ),
  3457 => 
  array (
    'id' => '653000',
    'parentid' => '650000',
    'parentids' => '650000,653000',
    'level' => '2',
    'name' => '克孜勒苏柯尔克孜自治州',
    'letter' => 'k',
    'listorder' => '0',
  ),
  3458 => 
  array (
    'id' => '653001',
    'parentid' => '653000',
    'parentids' => '650000,653000,653001',
    'level' => '3',
    'name' => '阿图什市',
    'letter' => 'a',
    'listorder' => '0',
  ),
  3459 => 
  array (
    'id' => '653022',
    'parentid' => '653000',
    'parentids' => '650000,653000,653022',
    'level' => '3',
    'name' => '阿克陶县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  3460 => 
  array (
    'id' => '653023',
    'parentid' => '653000',
    'parentids' => '650000,653000,653023',
    'level' => '3',
    'name' => '阿合奇县',
    'letter' => 'a',
    'listorder' => '0',
  ),
  3461 => 
  array (
    'id' => '653024',
    'parentid' => '653000',
    'parentids' => '650000,653000,653024',
    'level' => '3',
    'name' => '乌恰县',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3462 => 
  array (
    'id' => '653100',
    'parentid' => '650000',
    'parentids' => '650000,653100',
    'level' => '2',
    'name' => '喀什地区',
    'letter' => 'k',
    'listorder' => '0',
  ),
  3463 => 
  array (
    'id' => '653101',
    'parentid' => '653100',
    'parentids' => '650000,653100,653101',
    'level' => '3',
    'name' => '喀什市',
    'letter' => 'k',
    'listorder' => '0',
  ),
  3464 => 
  array (
    'id' => '653121',
    'parentid' => '653100',
    'parentids' => '650000,653100,653121',
    'level' => '3',
    'name' => '疏附县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3465 => 
  array (
    'id' => '653122',
    'parentid' => '653100',
    'parentids' => '650000,653100,653122',
    'level' => '3',
    'name' => '疏勒县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3466 => 
  array (
    'id' => '653123',
    'parentid' => '653100',
    'parentids' => '650000,653100,653123',
    'level' => '3',
    'name' => '英吉沙县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3467 => 
  array (
    'id' => '653124',
    'parentid' => '653100',
    'parentids' => '650000,653100,653124',
    'level' => '3',
    'name' => '泽普县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3468 => 
  array (
    'id' => '653125',
    'parentid' => '653100',
    'parentids' => '650000,653100,653125',
    'level' => '3',
    'name' => '莎车县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3469 => 
  array (
    'id' => '653126',
    'parentid' => '653100',
    'parentids' => '650000,653100,653126',
    'level' => '3',
    'name' => '叶城县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3470 => 
  array (
    'id' => '653127',
    'parentid' => '653100',
    'parentids' => '650000,653100,653127',
    'level' => '3',
    'name' => '麦盖提县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3471 => 
  array (
    'id' => '653128',
    'parentid' => '653100',
    'parentids' => '650000,653100,653128',
    'level' => '3',
    'name' => '岳普湖县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3472 => 
  array (
    'id' => '653129',
    'parentid' => '653100',
    'parentids' => '650000,653100,653129',
    'level' => '3',
    'name' => '伽师县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3473 => 
  array (
    'id' => '653130',
    'parentid' => '653100',
    'parentids' => '650000,653100,653130',
    'level' => '3',
    'name' => '巴楚县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3474 => 
  array (
    'id' => '653131',
    'parentid' => '653100',
    'parentids' => '650000,653100,653131',
    'level' => '3',
    'name' => '塔什库尔干塔吉克自治县',
    'letter' => 't',
    'listorder' => '0',
  ),
  3475 => 
  array (
    'id' => '653200',
    'parentid' => '650000',
    'parentids' => '650000,653200',
    'level' => '2',
    'name' => '和田地区',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3476 => 
  array (
    'id' => '653201',
    'parentid' => '653200',
    'parentids' => '650000,653200,653201',
    'level' => '3',
    'name' => '和田市',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3477 => 
  array (
    'id' => '653221',
    'parentid' => '653200',
    'parentids' => '650000,653200,653221',
    'level' => '3',
    'name' => '和田县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3478 => 
  array (
    'id' => '653222',
    'parentid' => '653200',
    'parentids' => '650000,653200,653222',
    'level' => '3',
    'name' => '墨玉县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3479 => 
  array (
    'id' => '653223',
    'parentid' => '653200',
    'parentids' => '650000,653200,653223',
    'level' => '3',
    'name' => '皮山县',
    'letter' => 'p',
    'listorder' => '0',
  ),
  3480 => 
  array (
    'id' => '653224',
    'parentid' => '653200',
    'parentids' => '650000,653200,653224',
    'level' => '3',
    'name' => '洛浦县',
    'letter' => 'l',
    'listorder' => '0',
  ),
  3481 => 
  array (
    'id' => '653225',
    'parentid' => '653200',
    'parentids' => '650000,653200,653225',
    'level' => '3',
    'name' => '策勒县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3482 => 
  array (
    'id' => '653226',
    'parentid' => '653200',
    'parentids' => '650000,653200,653226',
    'level' => '3',
    'name' => '于田县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3483 => 
  array (
    'id' => '653227',
    'parentid' => '653200',
    'parentids' => '650000,653200,653227',
    'level' => '3',
    'name' => '民丰县',
    'letter' => 'm',
    'listorder' => '0',
  ),
  3484 => 
  array (
    'id' => '654000',
    'parentid' => '650000',
    'parentids' => '650000,654000',
    'level' => '2',
    'name' => '伊犁哈萨克自治州',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3485 => 
  array (
    'id' => '654002',
    'parentid' => '654000',
    'parentids' => '650000,654000,654002',
    'level' => '3',
    'name' => '伊宁市',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3486 => 
  array (
    'id' => '654003',
    'parentid' => '654000',
    'parentids' => '650000,654000,654003',
    'level' => '3',
    'name' => '奎屯市',
    'letter' => 'k',
    'listorder' => '0',
  ),
  3487 => 
  array (
    'id' => '654021',
    'parentid' => '654000',
    'parentids' => '650000,654000,654021',
    'level' => '3',
    'name' => '伊宁县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3488 => 
  array (
    'id' => '654022',
    'parentid' => '654000',
    'parentids' => '650000,654000,654022',
    'level' => '3',
    'name' => '察布查尔锡伯自治县',
    'letter' => 'c',
    'listorder' => '0',
  ),
  3489 => 
  array (
    'id' => '654023',
    'parentid' => '654000',
    'parentids' => '650000,654000,654023',
    'level' => '3',
    'name' => '霍城县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3490 => 
  array (
    'id' => '654024',
    'parentid' => '654000',
    'parentids' => '650000,654000,654024',
    'level' => '3',
    'name' => '巩留县',
    'letter' => 'g',
    'listorder' => '0',
  ),
  3491 => 
  array (
    'id' => '654025',
    'parentid' => '654000',
    'parentids' => '650000,654000,654025',
    'level' => '3',
    'name' => '新源县',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3492 => 
  array (
    'id' => '654026',
    'parentid' => '654000',
    'parentids' => '650000,654000,654026',
    'level' => '3',
    'name' => '昭苏县',
    'letter' => 'z',
    'listorder' => '0',
  ),
  3493 => 
  array (
    'id' => '654027',
    'parentid' => '654000',
    'parentids' => '650000,654000,654027',
    'level' => '3',
    'name' => '特克斯县',
    'letter' => 't',
    'listorder' => '0',
  ),
  3494 => 
  array (
    'id' => '654028',
    'parentid' => '654000',
    'parentids' => '650000,654000,654028',
    'level' => '3',
    'name' => '尼勒克县',
    'letter' => 'n',
    'listorder' => '0',
  ),
  3495 => 
  array (
    'id' => '654200',
    'parentid' => '650000',
    'parentids' => '650000,654200',
    'level' => '2',
    'name' => '塔城地区',
    'letter' => 't',
    'listorder' => '0',
  ),
  3496 => 
  array (
    'id' => '654201',
    'parentid' => '654200',
    'parentids' => '650000,654200,654201',
    'level' => '3',
    'name' => '塔城市',
    'letter' => 't',
    'listorder' => '0',
  ),
  3497 => 
  array (
    'id' => '654202',
    'parentid' => '654200',
    'parentids' => '650000,654200,654202',
    'level' => '3',
    'name' => '乌苏市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3498 => 
  array (
    'id' => '654221',
    'parentid' => '654200',
    'parentids' => '650000,654200,654221',
    'level' => '3',
    'name' => '额敏县',
    'letter' => 'e',
    'listorder' => '0',
  ),
  3499 => 
  array (
    'id' => '654223',
    'parentid' => '654200',
    'parentids' => '650000,654200,654223',
    'level' => '3',
    'name' => '沙湾县',
    'letter' => 's',
    'listorder' => '0',
  ),
  3500 => 
  array (
    'id' => '654224',
    'parentid' => '654200',
    'parentids' => '650000,654200,654224',
    'level' => '3',
    'name' => '托里县',
    'letter' => 't',
    'listorder' => '0',
  ),
  3501 => 
  array (
    'id' => '654225',
    'parentid' => '654200',
    'parentids' => '650000,654200,654225',
    'level' => '3',
    'name' => '裕民县',
    'letter' => 'y',
    'listorder' => '0',
  ),
  3502 => 
  array (
    'id' => '654226',
    'parentid' => '654200',
    'parentids' => '650000,654200,654226',
    'level' => '3',
    'name' => '和布克赛尔蒙古自治县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3503 => 
  array (
    'id' => '654300',
    'parentid' => '650000',
    'parentids' => '650000,654300',
    'level' => '2',
    'name' => '阿勒泰地区',
    'letter' => 'a',
    'listorder' => '0',
  ),
  3504 => 
  array (
    'id' => '654301',
    'parentid' => '654300',
    'parentids' => '650000,654300,654301',
    'level' => '3',
    'name' => '阿勒泰市',
    'letter' => 'a',
    'listorder' => '0',
  ),
  3505 => 
  array (
    'id' => '654321',
    'parentid' => '654300',
    'parentids' => '650000,654300,654321',
    'level' => '3',
    'name' => '布尔津县',
    'letter' => 'b',
    'listorder' => '0',
  ),
  3506 => 
  array (
    'id' => '654322',
    'parentid' => '654300',
    'parentids' => '650000,654300,654322',
    'level' => '3',
    'name' => '富蕴县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  3507 => 
  array (
    'id' => '654323',
    'parentid' => '654300',
    'parentids' => '650000,654300,654323',
    'level' => '3',
    'name' => '福海县',
    'letter' => 'f',
    'listorder' => '0',
  ),
  3508 => 
  array (
    'id' => '654324',
    'parentid' => '654300',
    'parentids' => '650000,654300,654324',
    'level' => '3',
    'name' => '哈巴河县',
    'letter' => 'h',
    'listorder' => '0',
  ),
  3509 => 
  array (
    'id' => '654325',
    'parentid' => '654300',
    'parentids' => '650000,654300,654325',
    'level' => '3',
    'name' => '青河县',
    'letter' => 'q',
    'listorder' => '0',
  ),
  3510 => 
  array (
    'id' => '654326',
    'parentid' => '654300',
    'parentids' => '650000,654300,654326',
    'level' => '3',
    'name' => '吉木乃县',
    'letter' => 'j',
    'listorder' => '0',
  ),
  3511 => 
  array (
    'id' => '659000',
    'parentid' => '650000',
    'parentids' => '650000,659000',
    'level' => '2',
    'name' => '省直辖行政单位',
    'letter' => 's',
    'listorder' => '0',
  ),
  3512 => 
  array (
    'id' => '659001',
    'parentid' => '659000',
    'parentids' => '650000,659000,659001',
    'level' => '3',
    'name' => '石河子市',
    'letter' => 's',
    'listorder' => '0',
  ),
  3513 => 
  array (
    'id' => '659002',
    'parentid' => '659000',
    'parentids' => '650000,659000,659002',
    'level' => '3',
    'name' => '阿拉尔市',
    'letter' => 'a',
    'listorder' => '0',
  ),
  3514 => 
  array (
    'id' => '659003',
    'parentid' => '659000',
    'parentids' => '650000,659000,659003',
    'level' => '3',
    'name' => '图木舒克市',
    'letter' => 't',
    'listorder' => '0',
  ),
  3515 => 
  array (
    'id' => '659004',
    'parentid' => '659000',
    'parentids' => '650000,659000,659004',
    'level' => '3',
    'name' => '五家渠市',
    'letter' => 'w',
    'listorder' => '0',
  ),
  3516 => 
  array (
    'id' => '710000',
    'parentid' => '0',
    'parentids' => '710000',
    'level' => '1',
    'name' => '台湾省',
    'letter' => 't',
    'listorder' => '0',
  ),
  3517 => 
  array (
    'id' => '810000',
    'parentid' => '0',
    'parentids' => '810000',
    'level' => '1',
    'name' => '香港特别行政区',
    'letter' => 'x',
    'listorder' => '0',
  ),
  3518 => 
  array (
    'id' => '820000',
    'parentid' => '0',
    'parentids' => '820000',
    'level' => '1',
    'name' => '澳门特别行政区',
    'letter' => 'a',
    'listorder' => '0',
  ),
);
?>