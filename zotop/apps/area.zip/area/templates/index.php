{template 'header.php'}

首页模板

{template 'footer.php'}