<?php
return array (
  'id' => 'area',
  'dir' => 'area',
  'name' => '地区',
  'description' => '省、市、县三级城市数据，默认数据采用国标行政区划代码',
  'type'=>'module',
  'version' => '1.1',
  'author' => 'zotop team',
  'email' => 'hankx_chen@qq.com',
  'homepage' => 'http://zotop.com',
);
?>